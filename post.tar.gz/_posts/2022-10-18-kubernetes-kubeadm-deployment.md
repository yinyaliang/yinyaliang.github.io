---
title: "Deployment"
tags:
  - Kubernetes
toc: true
---

deployment

### 创建及删除deployment

利用deployment提高pod的健壮性,deployment是一个控制器,保证环境中有一定数量的pod

#### 通过yaml方式创建

不建议使用命令行创建,从1.8之后不了--image之外,不再支持其他选项

kubectl create deplyment 名字 --image=镜像 --dry-run=client -o yaml > d1.yaml

#### 创建目录

```bash
mkdir deploy
cd deploy
```

#### 创建命名空间

```bash
kubectl create ns nsdeploy
kubens nsdeploy
```

#### 生成文件

```bash
kubectl create deployment test1 --image=nginx --dry-run=client -o yaml > d1.yaml
```

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  creationTimestamp: null
  labels:                             # deploy 标签,可以和后面的pod的标签不一直
    app: test1
  name: test1                         # deployment 名字
spec:
  replicas: 3                         # 副本数量
  selector:
    matchLabels:
      app: test1                      # 两个APP的名字必须一致
  strategy: {}
  template:
    metadata:                         # 至 resources 都是pod的设置
      creationTimestamp: null
      labels:
        app: test1                    # 两个APP的名字必须一致
    spec:
      containers:
      - image: nginx
        imagePullPolicy:  IfNotPresent
        name: nginx
        resources: {}
status: {}
```

#### 创建

```bash
[root@master deploy]# kubectl apply -f d1.yaml
deployment.apps/test1 created
```

```bash
[root@master deploy]# kubectl get pods -o wide --no-headers
test1-78747d7d6c-gpgwc   1/1   Running   0     2s    10.244.166.156   node1   <none>   <none>
test1-78747d7d6c-j4ttk   1/1   Running   0     2s    10.244.104.30    node2   <none>   <none>
test1-78747d7d6c-k7tcx   1/1   Running   0     2s    10.244.104.31    node2   <none>   <none>
```

#### 验证

删除一个pod

```bash
[root@master deploy]# kubectl delete pods test1-78747d7d6c-gpgwc
pod "test1-78747d7d6c-gpgwc" deleted
[root@master deploy]# kubectl get pods -o wide --no-headers
test1-78747d7d6c-htwnb   1/1   Running   0     14s   10.244.104.32   node2   <none>   <none>
test1-78747d7d6c-j4ttk   1/1   Running   0     34s   10.244.104.30   node2   <none>   <none>
test1-78747d7d6c-k7tcx   1/1   Running   0     34s   10.244.104.31   node2   <none>   <none>
```

#### 健壮测试

关闭一个pod

```bash
[root@node2 ~]# poweroff 
```

故障的几分钟内master仍会等待pod恢复.若等几分钟还没恢复，会执行删除，删除完毕后.master会重新调度新的pod替代

node2开机后被标记的pod会被删除

```bash
[root@master deploy]# kubectl get pods -o wide --no-headers
test1-78747d7d6c-8fmxt   1/1   Running       0     60s     10.244.166.157   node1   <none>   <none>
test1-78747d7d6c-hnq47   1/1   Running       0     60s     10.244.166.158   node1   <none>   <none>
test1-78747d7d6c-htwnb   1/1   Terminating   0     8m11s   10.244.104.32    node2   <none>   <none>
test1-78747d7d6c-j4ttk   1/1   Terminating   0     8m31s   10.244.104.30    node2   <none>   <none>
test1-78747d7d6c-k7tcx   1/1   Terminating   0     8m31s   10.244.104.31    node2   <none>   <none>
test1-78747d7d6c-kqh9x   1/1   Running       0     60s     10.244.166.159   node1   <none>   <none>
```

#### 删除deployment的方法

```
kubectl delete -f d1.yaml
kubectl delete deploy 名字
```



### 伸缩pod副本数

#### 通过命令行修改

kubectl scale deplyment 名称 --replicas=新的副本数量

```bash
kubectl scale deployment test1 --replicas=5
```

```bash
[root@master deploy]# kubectl scale deployment test1 --replicas=5
deployment.apps/test1 scaled
[root@master deploy]# kubectl get pods -o wide --no-headers
test1-78747d7d6c-8fmxt   1/1   Running   0     4m28s   10.244.166.157   node1   <none>   <none>
test1-78747d7d6c-8lvwv   1/1   Running   0     3s      10.244.104.34    node2   <none>   <none>
test1-78747d7d6c-hnq47   1/1   Running   0     4m28s   10.244.166.158   node1   <none>   <none>
test1-78747d7d6c-kqh9x   1/1   Running   0     4m28s   10.244.166.159   node1   <none>   <none>
test1-78747d7d6c-z7ww4   1/1   Running   0     3s      10.244.104.33    node2   <none>   <none>
```

#### 编辑deployment的方式

```
kubectl edit deployments test1
```

```bash
[root@master deploy]# kubectl get pods -o wide --no-headers
test1-78747d7d6c-8lvwv   1/1   Running   0     98s    10.244.104.34    node2   <none>   <none>
test1-78747d7d6c-kqh9x   1/1   Running   0     6m3s   10.244.166.159   node1   <none>   <none>
test1-78747d7d6c-z7ww4   1/1   Running   0     98s    10.244.104.33    node2   <none>   <none>
```

#### 修改yaml

```bash
[root@master deploy]# kubectl apply -f d1.yaml
deployment.apps/test1 configured
[root@master deploy]# kubectl get pods -o wide --no-headers
test1-78747d7d6c-8lvwv   1/1   Running   0     2m3s    10.244.104.34    node2   <none>   <none>
test1-78747d7d6c-fdd4c   1/1   Running   0     3s      10.244.104.36    node2   <none>   <none>
test1-78747d7d6c-kqh9x   1/1   Running   0     6m28s   10.244.166.159   node1   <none>   <none>
test1-78747d7d6c-wxk76   1/1   Running   0     3s      10.244.104.35    node2   <none>   <none>
test1-78747d7d6c-z7ww4   1/1   Running   0     2m3s    10.244.104.33    node2   <none>   <none>
```

### 更新及回滚容器所使用的镜像

水平自动更新HPA,可以根据CPU负载通知deployment,让其更新pod数目以减轻pod的负载

kubectl autoscale deployment 名字 --min=M --max=N --cpu-percent=X

最少运行M个Pod，确保CPU不超过X%, 否则就扩展pod的副本数量,最大扩展到N，cou默认是80

#### 查看当前是否有HPA配置

```bash
[root@master deploy]# kubectl get hpa
No resources found in nsdeploy namespace.
```

#### 创建hpa,这是最多运行5个,最少运行2个pod

```bash
kubectl autoscale deployment test1 --min=2 --max=5
```

```bash
[root@master deploy]# kubectl get hpa
NAME    REFERENCE          TARGETS         MINPODS   MAXPODS   REPLICAS   AGE
test1   Deployment/test1   <unknown>/80%   2         5         0          11s
```

#### 把副本数量设置为1 

```bash
[root@master deploy]# kubectl scale deployment test1 --replicas=1
deployment.apps/test1 scaled
```

最用运行数量为2个

```bash
[root@master deploy]# kubectl get pods
NAME                     READY   STATUS    RESTARTS   AGE
test1-78747d7d6c-kqh9x   1/1     Running   0          13m
test1-78747d7d6c-vm2kf   1/1     Running   0          10s
```

#### 删除 hpa

```bash
[root@master deploy]# kubectl scale deployment test1 --replicas=0
deployment.apps/test1 scaled
```

#### 创建HPA，cpu不可以超过80

```bash
[root@master deploy]# kubectl edit deployment test1
deployment.apps/test1 edited
```

```yaml
    spec:
      containers:
      - image: nginx
        imagePullPolicy: IfNotPresent
        name: nginx
        resources: 
          requests:
            cpu:  400m
```

#### 把deplyment的副本数量设置1

```bash
[root@master deploy]# kubectl scale deployment test1 --replicas=1
deployment.apps/test1 scaled
```



### 回滚和升级

#### 升级

```bash
[root@master deploy]# kubectl get deployments -o wide
NAME    READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES   SELECTOR
test1   2/2     2            2           31m   nginx        nginx    app=test1
```

三种方法

1、kubectl edit deploy

2、修改deployment的yaml文件

3、命令行修改

#### 命令行语法

```bash
kubectl set image deploy 名字 容器名=镜像 < --record>
```

record可选

#### 把 test1的镜像更换为nginx:latest

```bash
[root@master deploy]# kubectl set image deploy test1 nginx=nginx:latest
deployment.apps/test1 image updated
```

```bash
[root@master deploy]# kubectl get deployment -o wide
NAME    READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES         SELECTOR
test1   2/2     2            2           35m   nginx        nginx:latest   app=test1
```

#### 换成1.7.9

```bash
[root@master deploy]# kubectl set image deploy test1 nginx=nginx:1.7.9
deployment.apps/test1 image updated
[root@master deploy]# kubectl get deployment -o wide
NAME    READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES        SELECTOR
test1   2/2     2            2           35m   nginx        nginx:1.7.9   app=test1
```

#### 查看变化过程

```bash
[root@master deploy]# kubectl rollout history deployment test1
deployment.apps/test1 
REVISION  CHANGE-CAUSE
1         <none>
2         <none>
3         <none>
4         <none>
```

#### 切换增加record

```bash
[root@master deploy]# kubectl set image deploy test1 nginx=nginx:1.9 --record
deployment.apps/test1 image updated
[root@master deploy]# kubectl set image deploy test1 nginx=nginx:1.7.9 --record
deployment.apps/test1 image updated
[root@master deploy]# kubectl rollout history deployment test1
deployment.apps/test1 
REVISION  CHANGE-CAUSE
1         <none>
2         <none>
3         <none>
5         kubectl set image deploy test1 nginx=nginx:1.9 --record=true
6         kubectl set image deploy test1 nginx=nginx:1.7.9 --record=true
```

### 回滚

kubectl rollout undo deployment 名字

```bash
kubectl rollout undo deployment 名字 --to-revision=版本
```

版本指的是编号为5的变更记录

```bash
[root@master deploy]# kubectl rollout undo deployment/test1 --to-revision=5
deployment.apps/test1 rolled back
```

```bash
[root@master deploy]# kubectl get deployments. -o wide
NAME    READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES      SELECTOR
test1   2/2     2            2           41m   nginx        nginx:1.9   app=test1
```



### 滚动升级

两个参数:

maxSurge:   用来指定最多一次创建几个pod,可以是百分比,也可以是具体数目

maxUnavailable: 用来指定最多删除几个pid,可以是数字或者百分比

#### 设置deployment

```bash
kubectl edit deployment test1
```

```yaml
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
```

修改为1

```
  strategy:
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 1
    type: RollingUpdate
```

删一个，建一个

```bash
[root@master deploy]# kubectl set image deploy test1 nginx=nginx:1.7.9 --record
deployment.apps/test1 image updated
[root@master deploy]# kubectl get pods
NAME                     READY   STATUS              RESTARTS   AGE
test1-5545c6d5df-c4bbz   0/1     ContainerCreating   0          1s
test1-5545c6d5df-mhs78   0/1     ContainerCreating   0          1s
test1-5f75995b7b-drr4f   0/1     Terminating         0          11m
test1-5f75995b7b-lt5xs   1/1     Running             0          11m
[root@master deploy]# kubectl get pods
NAME                     READY   STATUS        RESTARTS   AGE
test1-5545c6d5df-c4bbz   1/1     Running       0          5s
test1-5545c6d5df-mhs78   1/1     Running       0          5s
test1-5f75995b7b-drr4f   0/1     Terminating   0          11m
test1-5f75995b7b-lt5xs   0/1     Terminating   0          11m
```
