---
title: "Terraform 安装使用"
tags:
  - Application
toc: true
---

Terraform创建腾讯CVM

####  什么是terraform

 HashiCorp Terraform 是一种基础架构即代码工具，可让在可读的配置文件中定义云和本地资源，可以对其进行版本控制、重用和共享。可以使用一致的工作流程在整个生命周期内配置和管理所有基础架构。Terraform 可以管理计算、存储和网络资源等低级组件，以及DNS 条目和 SaaS 功能等高级组件。

#### 使用

- 以_configurations_的形式获取凭证和输入，在目标云上创建一个资源,
- 配置以Terraform的语法进行资源的描述。基本上是声明式的语法。
- Terraform使用云服务商提供的API来创建资源，社区提供了1700多个provider来提供管理（https://registry.terraform.io/）,支持扩展

#### 优势

- 可以管理多个云平台上的基础架构
- 时间优化，可以在短时间内编写配置，几分钟就可以创建云资源
- 变更更容易了和改代码一样了
- Terraform 的状态允许在整个部署过程中跟踪资源更改
- 支持版本控制

#### 工作流程

<img src="/assets/images/application/1.png">

#### 安装

##### 安装

```bash
sudo yum install -y yum-utils
sudo yum-config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
sudo yum -y install terraform 
```

##### 验证

```bash
# terraform -help
Usage: terraform [global options] <subcommand> [args]

The available commands for execution are listed below.
The primary workflow commands are given first, followed by
less common or more advanced commands.

Main commands:
  init          Prepare your working directory for other commands
  validate      Check whether the configuration is valid
  plan          Show changes required by the current configuration
  apply         Create or update infrastructure
  destroy       Destroy previously-created infrastructure

All other commands:
  console       Try Terraform expressions at an interactive command prompt
  fmt           Reformat your configuration in the standard style
  force-unlock  Release a stuck lock on the current workspace
  get           Install or upgrade remote Terraform modules
  graph         Generate a Graphviz graph of the steps in an operation
  import        Associate existing infrastructure with a Terraform resource
  login         Obtain and save credentials for a remote host
  logout        Remove locally-stored credentials for a remote host
  output        Show output values from your root module
  providers     Show the providers required for this configuration
  refresh       Update the state to match remote systems
  show          Show the current state or a saved plan
  state         Advanced state management
  taint         Mark a resource instance as not fully functional
  test          Experimental support for module integration testing
  untaint       Remove the 'tainted' state from a resource instance
  version       Show the current Terraform version
  workspace     Workspace management

Global options (use these before the subcommand, if any):
  -chdir=DIR    Switch to a different working directory before executing the
                given subcommand.
  -help         Show this help output, or the help for a specified subcommand.
  -version      An alias for the "version" subcommand.
```

#####  补全

```bash
touch ~/.bashrc
terraform -install-autocomplete
```

#### 简单测试

```
mkdir learn-terraform-docker-container
cd learn-terraform-docker-container
```

```bash
cat > main.tf << EOF
terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 2.13.0"
    }
  }
}

provider "docker" {}

resource "docker_image" "nginx" {
  name         = "nginx:latest"
  keep_locally = false
}

resource "docker_container" "nginx" {
  image = docker_image.nginx.latest
  name  = "tutorial"
  ports {
    internal = 80
    external = 8000
  }
}
EOF
```

```bash
 terraform init
 terraform apply
```



```
# curl localhost:8000
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
<style>
html { color-scheme: light dark; }
body { width: 35em; margin: 0 auto;
font-family: Tahoma, Verdana, Arial, sans-serif; }
</style>
</head>
<body>
<h1>Welcome to nginx!</h1>
<p>If you see this page, the nginx web server is successfully installed and
working. Further configuration is required.</p>

<p>For online documentation and support please refer to
<a href="http://nginx.org/">nginx.org</a>.<br/>
Commercial support is available at
<a href="http://nginx.com/">nginx.com</a>.</p>

<p><em>Thank you for using nginx.</em></p>
</body>
</html>
```

```bash
# docker ps
CONTAINER ID   IMAGE          COMMAND                  CREATED              STATUS              PORTS                  NAMES
8fde98406749   5d58c024174d   "/docker-entrypoint.…"   About a minute ago   Up About a minute   0.0.0.0:8000->80/tcp   tutorial
```

```
terraform destroy
```

#### 构建腾讯基础设施

```
mkdir tencent
cd tencent
```

##### 初始化环境

```
cat > provider.tf << EOF
terraform {
  required_providers {
    tencentcloud = {
      source = "tencentcloudstack/tencentcloud"
    }
  }
}

# Configure the TencentCloud Provider
provider "tencentcloud" {
  secret_id  = "my-secret-id"
  secret_key = "my-secret-key"
  region     = "ap-guangzhou"
}
EOF
```

##### 创建一台CVM

```
resource "tencentcloud_instance" "web" {
  instance_name              = "test web server"
  availability_zone          = "ap-beijing-6"
  image_id                   = "img-hbbgxy7f"
  instance_type              = "S6.MEDIUM2"
  system_disk_type           = "CLOUD_PREMIUM"
  system_disk_size           = 50
  security_groups            = ["sg-4m6i7s6v"]
  count                      = 1
}
```

##### 测试执行

```bash
# terraform plan
Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the
following symbols:
  + create

Terraform will perform the following actions:

  # tencentcloud_instance.web[0] will be created
  + resource "tencentcloud_instance" "web" {
      + allocate_public_ip                      = false
      + availability_zone                       = "ap-beijing-6"
      + create_time                             = (known after apply)
      + disable_monitor_service                 = false
      + disable_security_service                = false
      + expired_time                            = (known after apply)
      + force_delete                            = false
      + id                                      = (known after apply)
      + image_id                                = "img-hbbgxy7f"
      + instance_charge_type                    = "POSTPAID_BY_HOUR"
      + instance_charge_type_prepaid_renew_flag = (known after apply)
      + instance_name                           = "test web server"
      + instance_status                         = (known after apply)
      + instance_type                           = "S6.MEDIUM2"
      + internet_charge_type                    = (known after apply)
      + internet_max_bandwidth_out              = (known after apply)
      + key_ids                                 = (known after apply)
      + key_name                                = (known after apply)
      + private_ip                              = (known after apply)
      + project_id                              = 0
      + public_ip                               = (known after apply)
      + running_flag                            = true
      + security_groups                         = [
          + "sg-4m6i7s6v",
        ]
      + subnet_id                               = (known after apply)
      + system_disk_id                          = (known after apply)
      + system_disk_size                        = 50
      + system_disk_type                        = "CLOUD_PREMIUM"
      + vpc_id                                  = (known after apply)

      + data_disks {
          + data_disk_id           = (known after apply)
          + data_disk_size         = (known after apply)
          + data_disk_snapshot_id  = (known after apply)
          + data_disk_type         = (known after apply)
          + delete_with_instance   = (known after apply)
          + encrypt                = (known after apply)
          + throughput_performance = (known after apply)
        }
    }

Plan: 1 to add, 0 to change, 0 to destroy.
```

##### 执行创建

```bash
# terraform apply

Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the
following symbols:
  + create

Terraform will perform the following actions:

  # tencentcloud_instance.web[0] will be created
  + resource "tencentcloud_instance" "web" {
      + allocate_public_ip                      = false
      + availability_zone                       = "ap-beijing-6"
      + create_time                             = (known after apply)
      + disable_monitor_service                 = false
      + disable_security_service                = false
      + expired_time                            = (known after apply)
      + force_delete                            = false
      + id                                      = (known after apply)
      + image_id                                = "img-hbbgxy7f"
      + instance_charge_type                    = "POSTPAID_BY_HOUR"
      + instance_charge_type_prepaid_renew_flag = (known after apply)
      + instance_name                           = "test web server"
      + instance_status                         = (known after apply)
      + instance_type                           = "S6.MEDIUM2"
      + internet_charge_type                    = (known after apply)
      + internet_max_bandwidth_out              = (known after apply)
      + key_ids                                 = (known after apply)
      + key_name                                = (known after apply)
      + private_ip                              = (known after apply)
      + project_id                              = 0
      + public_ip                               = (known after apply)
      + running_flag                            = true
      + security_groups                         = [
          + "sg-4m6i7s6v",
        ]
      + subnet_id                               = (known after apply)
      + system_disk_id                          = (known after apply)
      + system_disk_size                        = 50
      + system_disk_type                        = "CLOUD_PREMIUM"
      + vpc_id                                  = (known after apply)

      + data_disks {
          + data_disk_id           = (known after apply)
          + data_disk_size         = (known after apply)
          + data_disk_snapshot_id  = (known after apply)
          + data_disk_type         = (known after apply)
          + delete_with_instance   = (known after apply)
          + encrypt                = (known after apply)
          + throughput_performance = (known after apply)
        }
    }

Plan: 1 to add, 0 to change, 0 to destroy.

Do you want to perform these actions?
  Terraform will perform the actions described above.
  Only 'yes' will be accepted to approve.

  Enter a value: yes

tencentcloud_instance.web[0]: Creating...
tencentcloud_instance.web[0]: Still creating... [10s elapsed]
tencentcloud_instance.web[0]: Still creating... [20s elapsed]
tencentcloud_instance.web[0]: Still creating... [30s elapsed]
tencentcloud_instance.web[0]: Creation complete after 38s [id=ins-pvmqc3pr]

Apply complete! Resources: 1 added, 0 changed, 0 destroyed.
```

<img src="/assets/images/application/2.png">

##### 查询实例数据

```bash
# terraform show
# tencentcloud_instance.web[0]:
resource "tencentcloud_instance" "web" {
    allocate_public_ip         = false
    availability_zone          = "ap-beijing-6"
    create_time                = "2022-10-25T08:49:16Z"
    disable_monitor_service    = false
    disable_security_service   = false
    force_delete               = false
    id                         = "ins-pvmqc3pr"
    image_id                   = "img-hbbgxy7f"
    instance_charge_type       = "POSTPAID_BY_HOUR"
    instance_name              = "test web server"
    instance_status            = "RUNNING"
    instance_type              = "S6.MEDIUM2"
    internet_max_bandwidth_out = 0
    key_ids                    = []
    private_ip                 = "172.21.48.7"
    project_id                 = 0
    running_flag               = true
    security_groups            = [
        "sg-4m6i7s6v",
    ]
    subnet_id                  = "subnet-k8mir1zl"
    system_disk_id             = "disk-2t8ene3n"
    system_disk_size           = 50
    system_disk_type           = "CLOUD_PREMIUM"
    vpc_id                     = "vpc-bgsgnv7o"
}
```

##### 删除实例数据

```bash
# terraform destroy
tencentcloud_instance.web[0]: Refreshing state... [id=ins-pvmqc3pr]

Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the
following symbols:
  - destroy

Terraform will perform the following actions:

  # tencentcloud_instance.web[0] will be destroyed
  - resource "tencentcloud_instance" "web" {
      - allocate_public_ip         = false -> null
      - availability_zone          = "ap-beijing-6" -> null
      - create_time                = "2022-10-25T08:49:16Z" -> null
      - disable_monitor_service    = false -> null
      - disable_security_service   = false -> null
      - force_delete               = false -> null
      - id                         = "ins-pvmqc3pr" -> null
      - image_id                   = "img-hbbgxy7f" -> null
      - instance_charge_type       = "POSTPAID_BY_HOUR" -> null
      - instance_name              = "test web server" -> null
      - instance_status            = "RUNNING" -> null
      - instance_type              = "S6.MEDIUM2" -> null
      - internet_max_bandwidth_out = 0 -> null
      - key_ids                    = [] -> null
      - private_ip                 = "172.21.48.7" -> null
      - project_id                 = 0 -> null
      - running_flag               = true -> null
      - security_groups            = [
          - "sg-4m6i7s6v",
        ] -> null
      - subnet_id                  = "subnet-k8mir1zl" -> null
      - system_disk_id             = "disk-2t8ene3n" -> null
      - system_disk_size           = 50 -> null
      - system_disk_type           = "CLOUD_PREMIUM" -> null
      - tags                       = {} -> null
      - vpc_id                     = "vpc-bgsgnv7o" -> null
    }

Plan: 0 to add, 0 to change, 1 to destroy.

Do you really want to destroy all resources?
  Terraform will destroy all your managed infrastructure, as shown above.
  There is no undo. Only 'yes' will be accepted to confirm.

  Enter a value: yes

tencentcloud_instance.web[0]: Destroying... [id=ins-pvmqc3pr]
tencentcloud_instance.web[0]: Still destroying... [id=ins-pvmqc3pr, 10s elapsed]
tencentcloud_instance.web[0]: Destruction complete after 11s

Destroy complete! Resources: 1 destroyed.
```

##### 无资源测试

```bash
# terraform plan

Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the
following symbols:
  + create

Terraform will perform the following actions:

  # tencentcloud_instance.web[0] will be created
  + resource "tencentcloud_instance" "web" {
      + allocate_public_ip                      = false
      + availability_zone                       = "ap-beijing-6"
      + create_time                             = (known after apply)
      + disable_monitor_service                 = false
      + disable_security_service                = false
      + expired_time                            = (known after apply)
      + force_delete                            = false
      + id                                      = (known after apply)
      + image_id                                = "img-hbbgxy7f"
      + instance_charge_type                    = "POSTPAID_BY_HOUR"
      + instance_charge_type_prepaid_renew_flag = (known after apply)
      + instance_name                           = "test web server"
      + instance_status                         = (known after apply)
      + instance_type                           = "S5se.LARGE16"
      + internet_charge_type                    = (known after apply)
      + internet_max_bandwidth_out              = (known after apply)
      + key_ids                                 = (known after apply)
      + key_name                                = (known after apply)
      + private_ip                              = (known after apply)
      + project_id                              = 0
      + public_ip                               = (known after apply)
      + running_flag                            = true
      + security_groups                         = [
          + "sg-4m6i7s6v",
        ]
      + subnet_id                               = (known after apply)
      + system_disk_id                          = (known after apply)
      + system_disk_size                        = 50
      + system_disk_type                        = "CLOUD_PREMIUM"
      + vpc_id                                  = (known after apply)

      + data_disks {
          + data_disk_id           = (known after apply)
          + data_disk_size         = (known after apply)
          + data_disk_snapshot_id  = (known after apply)
          + data_disk_type         = (known after apply)
          + delete_with_instance   = (known after apply)
          + encrypt                = (known after apply)
          + throughput_performance = (known after apply)
        }
    }

Plan: 1 to add, 0 to change, 0 to destroy.

───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

Note: You didn't use the -out option to save this plan, so Terraform can't guarantee to take exactly these actions if you run
"terraform apply" now.
```

##### 无资源创建测试

```bash
Terraform used the selected providers to generate the following execution plan. Resource actions are indicated with the
following symbols:
  + create

Terraform will perform the following actions:

  # tencentcloud_instance.web[0] will be created
  + resource "tencentcloud_instance" "web" {
      + allocate_public_ip                      = false
      + availability_zone                       = "ap-beijing-6"
      + create_time                             = (known after apply)
      + disable_monitor_service                 = false
      + disable_security_service                = false
      + expired_time                            = (known after apply)
      + force_delete                            = false
      + id                                      = (known after apply)
      + image_id                                = "img-hbbgxy7f"
      + instance_charge_type                    = "POSTPAID_BY_HOUR"
      + instance_charge_type_prepaid_renew_flag = (known after apply)
      + instance_name                           = "test web server"
      + instance_status                         = (known after apply)
      + instance_type                           = "S5se.LARGE16"
      + internet_charge_type                    = (known after apply)
      + internet_max_bandwidth_out              = (known after apply)
      + key_ids                                 = (known after apply)
      + key_name                                = (known after apply)
      + private_ip                              = (known after apply)
      + project_id                              = 0
      + public_ip                               = (known after apply)
      + running_flag                            = true
      + security_groups                         = [
          + "sg-4m6i7s6v",
        ]
      + subnet_id                               = (known after apply)
      + system_disk_id                          = (known after apply)
      + system_disk_size                        = 50
      + system_disk_type                        = "CLOUD_PREMIUM"
      + vpc_id                                  = (known after apply)

      + data_disks {
          + data_disk_id           = (known after apply)
          + data_disk_size         = (known after apply)
          + data_disk_snapshot_id  = (known after apply)
          + data_disk_type         = (known after apply)
          + delete_with_instance   = (known after apply)
          + encrypt                = (known after apply)
          + throughput_performance = (known after apply)
        }
    }

Plan: 1 to add, 0 to change, 0 to destroy.

Do you want to perform these actions?
  Terraform will perform the actions described above.
  Only 'yes' will be accepted to approve.

  Enter a value: yes

tencentcloud_instance.web[0]: Creating...
╷
│ Error: [TencentCloudSDKError] Code=ResourceInsufficient.SpecifiedInstanceType, Message=The specified type of instance is understocked., RequestId=c978845f-cd62-46d0-8b91-60d9aa13e889
│ 
│   with tencentcloud_instance.web[0],
│   on cvm.tf line 1, in resource "tencentcloud_instance" "web":
│    1: resource "tencentcloud_instance" "web" {
│ 
╵
```


