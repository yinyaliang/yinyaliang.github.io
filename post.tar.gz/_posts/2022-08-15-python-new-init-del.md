---
title: "`Python中的 __new__ __init__ __del__`"
tags:
  - Python
toc: true
---

Python 中特殊方法的一些理解笔记

Python中的__new\_\_ \_\_init\_\_ \_\_del__三个方法用于实例的创建和销毁,在使用python的类中，我们最常用的是__init__方法，通常称为构造方法,\_\_new__方法几乎不会使用，这篇文章是基于Python3.6为基础来做实验，主要谈一谈python的__new__和__init__，\_\_init__通常称为构造方法,但其实它是个“初始化方法”，真正的构造方法是__new__,__init__既然是初始化方法，那么肯定是对对象的初始化，也就是存在一个被初始化的对象

### 第一个例子
```python
class inch():
    def __init__(self):
        print("__init__")

    def __new__(cls):
        print("__new__ ")
        print("__new__ ")

__new__
None
```

因为我们没有从__new__返回任何结果，__init__这里不会调用。如果init被调用，我们就会看到我们在init中的打印语句。

### 第二个例子

```python
class inch():
    def __new__(cls):
        print("__new__ ")
        print(super(inch, cls).__new__(cls)) 
        return super(inch, cls).__new__(cls)
    def __init__(self):
        print("__init__")

print(inch())

__new__
<__main__.inch object at 0x002BF170>
__init__
<__main__.inch object at 0x002BF170>
```

用于构建实例的是特殊方法 __new__：是个类方法(不需要使用@classmethod)，调用__init__方法时要传入实例，\_\_new__必须返回一个实例。返回的实例会作为第一个参数（即 self）传给__init__ 方法。注意:__init__不允许返回任何值

### 第三个例子
```python
class inch(float):
    def __new__(cls, args=0.0):
        cls.new = float.__new__(cls,args*0.0254)
        return cls.new
    def __init__(self,a):
        print("__init__")
        print(a)

object1=inch(3)
print(object1.new)

__init__
3
0.07619999999999999
```
可以看到__init__方法中除了self之外定义的参数，都必须与__new__方法中除cls参数之外的参数保持一致

无论我们给超类的__new__传递的是哪个类，它都会创建该类的一个实例，如何我们想要创建一个inch的实例，所以，inch类必须作为第一个参数传递给float.__new__。在类inch的内部，cls指的是inch类，因此，我们需要将cls作为第一个参数传递给对象。

### 第四个例子
```python
class B(float):
    pass

class inch(float):
    def __new__(cls, args=0.0):
        B.new = float.__new__(B,args*0.0254)
        return B.new
    def __init__(self,a):
        print("__init__")
        print(a)

object1=inch(3)
print(type(object))
print(object1.new)

<class '__main__.B'>
0.0761999999999999
```

最后:\_\_new__是用来创建一个实例的，从 object 类继承的已经很完善。所以我们基本上不需要自己编写__new__ 方法

### 第五个例子
一个__new__的应用，著名的单例模式(:python 中 None 对象就是单例):
```python
class Singleton:
    _instance = None
    def __new__(cls, *args, **kwargs):
        if not isinstance(cls._instance, cls):
            cls._instance = object.__new__(cls, *args, **kwargs)
        return cls._instance

a=Singleton()
b=Singleton()
print(a is b)

True
```
