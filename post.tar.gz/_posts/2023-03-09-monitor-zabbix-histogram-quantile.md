---
title: "zabbix 实现 histogram_quantile"
tags:
  - Monitor
toc: true
---
 
zabbix 收集TIDB的etcd_disk_wal_fsync_duration_seconds_bucket, 实现prometheus的 histogram_quantile 

### prometheus的报警规则
```bash
histogram_quantile(0.99,sum(rate(etcd_disk_wal_fsync_duration_seconds_bucket[1m])) by (instance,job,le)) > 1
```

### 客户端 metrics
```bash
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.002"} 1.16569197e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.004"} 1.16826659e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.008"} 1.16908279e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.016"} 1.1695191e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.032"} 1.16979685e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.064"} 1.17018263e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.128"} 1.17029029e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.256"} 1.17033774e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="0.512"} 1.17035754e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="1.024"} 1.17036426e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="2.048"} 1.17036682e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="4.096"} 1.17036699e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="8.192"} 1.17036699e+08
etcd_disk_wal_fsync_duration_seconds_bucket{le="+Inf"} 1.17036699e+08
```


### zabbix yaml
```yaml
zabbix_export:
  version: '6.2'
  date: '2023-03-09T08:29:57Z'
  template_groups:
    -
      uuid: 748ad4d098d447d492bb935c907f652f
      name: Templates/Databases
  templates:
    -
      uuid: 43596328d4d74a5592906a9e08e3fd96
      template: service.TiDB-PD
      name: service.TiDB-PD
      groups:
        -
          name: Templates/Databases
      items:
        -
          uuid: a0e6cf6c975042e0b884de64710b56b5
          name: '[TIDB-PD] etcd write disk latency'
          type: CALCULATED
          key: etcd.write.disk.latency
          value_type: FLOAT
          params: 'histogram_quantile(0.99,bucket_rate_foreach(//etcd.write.disk.latency[*],60s))'
          tags:
            -
              tag: Application
              value: TIDB-PD
        -
          uuid: 3a1fd879a08a445cbf438f3d68078111
          name: 'PD: Get instance metrics'
          type: HTTP_AGENT
          key: pd.get_metrics
          delay: 30s
          history: '0'
          trends: '0'
          value_type: TEXT
          description: 'Get TiDB PD instance metrics.'
          preprocessing:
            -
              type: CHECK_NOT_SUPPORTED
              parameters:
                - ''
            -
              type: PROMETHEUS_TO_JSON
              parameters:
                - ''
          url: '{HOST.IP}:{$PD.PORT}/metrics'
          tags:
            -
              tag: Application
              value: RAW
      discovery_rules:
        -
          uuid: 74748726242c46bcaa7533edde4b2633
          name: 'etcd disk wal fsync duration seconds bucket discovery'
          type: DEPENDENT
          key: etcd.disk.wal.fsync.duration.seconds.bucket.discovery
          delay: '0'
          lifetime: '0'
          item_prototypes:
            -
              uuid: c56a7113b37d48db836e6af8043e2639
              name: 'TiDB-PD: {#NAME}  {#LE}'
              type: DEPENDENT
              key: 'etcd.write.disk.latency[{#LE}]'
              delay: '0'
              value_type: FLOAT
              preprocessing:
                -
                  type: JSONPATH
                  parameters:
                    - '$[?(@.name=="etcd_disk_wal_fsync_duration_seconds_bucket")]'
                -
                  type: JAVASCRIPT
                  parameters:
                    - |
                      var obj = JSON.parse(value)
                      for (var i=0;i< obj.length;i++){
                          if (obj[i]['labels']['le'] == "{#LE}" && obj[i]["name"] == "{#NAME}" ){
                              return obj[i]["line_raw"].split(" ")[1]
                          }
                      }
                      return
                      
                -
                  type: CHANGE_PER_SECOND
                  parameters:
                    - ''
              master_item:
                key: pd.get_metrics
              tags:
                -
                  tag: Application
                  value: TIDB-PD
          master_item:
            key: pd.get_metrics
          preprocessing:
            -
              type: JSONPATH
              parameters:
                - '$[?(@.name=="etcd_disk_wal_fsync_duration_seconds_bucket")]'
              error_handler: CUSTOM_VALUE
              error_handler_params: '[]'
            -
              type: JAVASCRIPT
              parameters:
                - |
                  var obj = JSON.parse(value)
                  var outJson=[]
                  for (var i=0;i<obj.length;i++){
                      outJson.push({"{#LE}":obj[i]['labels']['le'],"{#NAME}":obj[i]["name"]})
                  }
                  var ret = {}
                  ret["data"] = outJson
                  return JSON.stringify(ret)
        -
          uuid: cd1f27cf5f1d4f6f84032386ec7f8abb
          name: 'Cluster metrics discovery'
          type: DEPENDENT
          key: pd.cluster.discovery
          delay: '0'
          lifetime: '0'
          description: 'Discovery cluster specific metrics.'
          item_prototypes:
            -
              uuid: 060fe77d53c24329a9165b50068ba757
              name: 'TiDB cluster: tikv used sotrage capacity'
              type: CALCULATED
              key: 'pd.cluster.capacity[{#SINGLETON}]'
              units: '%'
              params: 'last(//pd.cluster_status.storage_size[{#SINGLETON}]) / last(//pd.cluster_status.storage_capacity[{#SINGLETON}]) * 100'
              tags:
                -
                  tag: Application
                  value: TIDB-PD
            -
              uuid: d39f58372e3f464c87b2ec42acdf2061
              name: 'TiDB cluster: Storage capacity'
              type: DEPENDENT
              key: 'pd.cluster_status.storage_capacity[{#SINGLETON}]'
              delay: '0'
              history: 7d
              value_type: FLOAT
              units: MB
              description: 'The total storage capacity for this TiDB cluster.'
              preprocessing:
                -
                  type: JSONPATH
                  parameters:
                    - '$[?(@.name == "pd_cluster_status" && @.labels.type == "storage_capacity")].value.first()'
                -
                  type: JAVASCRIPT
                  parameters:
                    - 'return value/1024/1024'
              master_item:
                key: pd.get_metrics
              tags:
                -
                  tag: Application
                  value: TIDB-PD
            -
              uuid: c72e6a2f89d041c4bf764021b9bc182c
              name: 'TiDB cluster: Storage size'
              type: DEPENDENT
              key: 'pd.cluster_status.storage_size[{#SINGLETON}]'
              delay: '0'
              history: 7d
              value_type: FLOAT
              units: MB
              description: 'The storage size that is currently used by the TiDB cluster.'
              preprocessing:
                -
                  type: JSONPATH
                  parameters:
                    - '$[?(@.name == "pd_cluster_status" && @.labels.type == "storage_size")].value.first()'
                -
                  type: JAVASCRIPT
                  parameters:
                    - 'return value/1024/1024'
              master_item:
                key: pd.get_metrics
              tags:
                -
                  tag: Application
                  value: TIDB-PD
            -
              uuid: ce35701fa8344c4cbd1dc6b1d24dfa10
              name: 'TiDB cluster: Lowspace stores'
              type: DEPENDENT
              key: 'pd.cluster_status.store_low_space[{#SINGLETON}]'
              delay: '0'
              history: 7d
              units: MB
              description: 'The count of low space stores.'
              preprocessing:
                -
                  type: JSONPATH
                  parameters:
                    - '$[?(@.name == "pd_cluster_status" && @.labels.type == "store_low_space_count")].value.first()'
              master_item:
                key: pd.get_metrics
              tags:
                -
                  tag: Application
                  value: TIDB-PD
          trigger_prototypes:
            -
              uuid: 843d566b33bc401390c2a633d08bb033
              expression: 'min(/service.TiDB-PD/pd.cluster_status.storage_size[{#SINGLETON}],5m)/last(/service.TiDB-PD/pd.cluster_status.storage_capacity[{#SINGLETON}])*100>{$PD.STORAGE_USAGE.MAX.WARN}'
              name: 'TiDB cluster: Current storage usage is too high (over {$PD.STORAGE_USAGE.MAX.WARN}% for 5m)'
              status: DISABLED
              priority: WARNING
              description: 'Over {$PD.STORAGE_USAGE.MAX.WARN}% of the cluster space is occupied.'
          graph_prototypes:
            -
              uuid: 270de7aa73cf454cb147a3f5b39ebb35
              name: 'TiDB cluster: Storage Usage[{#SINGLETON}]'
              graph_items:
                -
                  color: 1A7C11
                  item:
                    host: service.TiDB-PD
                    key: 'pd.cluster_status.storage_size[{#SINGLETON}]'
                -
                  sortorder: '1'
                  color: 2774A4
                  item:
                    host: service.TiDB-PD
                    key: 'pd.cluster_status.storage_capacity[{#SINGLETON}]'
          master_item:
            key: pd.get_metrics
          preprocessing:
            -
              type: JSONPATH
              parameters:
                - '$[?(@.name=="pd_cluster_status")]'
              error_handler: CUSTOM_VALUE
              error_handler_params: '[]'
            -
              type: JAVASCRIPT
              parameters:
                - 'return JSON.stringify(value != "[]" ? [{''{#SINGLETON}'': ''''}] : []);'
        -
          uuid: e75aae0f2933400399028f8286b555f2
          name: 'pd events metrics discovery'
          type: DEPENDENT
          key: pd.events.discovery
          delay: '0'
          lifetime: '0'
          item_prototypes:
            -
              uuid: 1dac13d2c6d04cf09faee366442069c3
              name: 'TiDB: pd tso events[save]'
              type: DEPENDENT
              key: 'pd.tso.evnets[{#SINGLETON}]'
              delay: '0'
              value_type: FLOAT
              preprocessing:
                -
                  type: JSONPATH
                  parameters:
                    - '$[?(@.name == "pd_tso_events" && @.labels.type == "save")].value.first()'
                -
                  type: SIMPLE_CHANGE
                  parameters:
                    - ''
              master_item:
                key: pd.get_metrics
              tags:
                -
                  tag: Application
                  value: TIDB-PD
          master_item:
            key: pd.get_metrics
          preprocessing:
            -
              type: JSONPATH
              parameters:
                - '$[?(@.name=="pd_tso_events")]'
              error_handler: CUSTOM_VALUE
              error_handler_params: '[]'
            -
              type: JAVASCRIPT
              parameters:
                - 'return JSON.stringify(value != "[]" ? [{''{#SINGLETON}'': ''''}] : []);'
        -
          uuid: 1138b1dbad934a57af545d04a2979294
          name: 'pd process start  time discovery'
          type: DEPENDENT
          key: pd.process.start.time.discovery
          delay: '0'
          lifetime: '0'
          item_prototypes:
            -
              uuid: 4f0ec43060af4ef3a506f578af97b664
              name: 'TiDB-PD: process start time seconds'
              type: DEPENDENT
              key: 'process.start.time.seconds[{#SINGLETON}]'
              delay: '0'
              preprocessing:
                -
                  type: JSONPATH
                  parameters:
                    - '$[?(@.name == "process_start_time_seconds" )].value.first()'
                -
                  type: SIMPLE_CHANGE
                  parameters:
                    - ''
              master_item:
                key: pd.get_metrics
              tags:
                -
                  tag: Application
                  value: TIDB-PD
          master_item:
            key: pd.get_metrics
          preprocessing:
            -
              type: JSONPATH
              parameters:
                - '$[?(@.name=="process_start_time_seconds")]'
              error_handler: CUSTOM_VALUE
              error_handler_params: '[]'
            -
              type: JAVASCRIPT
              parameters:
                - 'return JSON.stringify(value != "[]" ? [{''{#SINGLETON}'': ''''}] : []);'
      macros:
        -
          macro: '{$PD.MISS_REGION.MAX.WARN}'
          value: '100'
          description: 'Maximum number of missed regions'
        -
          macro: '{$PD.PORT}'
          value: '2379'
          description: 'The port of PD server metrics web endpoint'
        -
          macro: '{$PD.STORAGE_USAGE.MAX.WARN}'
          value: '80'
          description: 'Maximum percentage of cluster space used'
        -
          macro: '{$PD.URL}'
          value: '{HOST.IP}'
          description: 'PD server URL'
      valuemaps:
        -
          uuid: bce54cbdf2b8487985f9c7847a4c4918
          name: 'Service state'
          mappings:
            -
              value: '0'
              newvalue: Down
            -
              value: '1'
              newvalue: Up
```

### 效果
#### prometheus img
<img src="/assets/images/zabbix/2023-03-09_16-35.png">

#### zabbix img
<img src="/assets/images/zabbix/2023-03-09_16-35_1.png">

### 参考链接
```
https://www.zabbix.com/documentation/6.0/en/manual/appendix/functions/aggregate
https://www.zabbix.com/documentation/6.0/en/manual/appendix/functions/aggregate/foreach
https://support.zabbix.com/browse/ZBXNEXT-6879
```
