---
title: "Job"
tags:
  - Kubernetes
toc: true
---

Job

临时使用或者是定期运行的工作,可以通过 cronjob实现

### 创建及删除job

job用于临时性任务,成功则job结束，失败则创建新的或者重启pod

#### 创建空间

```bash
kubectl create ns nsjob
```

```bash
[root@master probe]# kubectl create ns nsjob
namespace/nsjob created
[root@master probe]# kubens nsjob
Context "kubernetes-admin@kubernetes" modified.
Active namespace is "nsjob".
```

#### 创建job

两种方式,命令行或者是生成yaml,建议命令行生成yaml再修改生成job

kubectl create job 名字 --image=镜像 -- "命令"

```bash
kubectl create job job1 --image=busybox --dry-run=client -o yaml -- sh -c "echo hello && sleep 10" > job.yaml
```

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  creationTimestamp: null
  name: job1
spec:
  template:
    metadata:
      creationTimestamp: null
    spec:
      containers:
      - command:
        - sh
        - -c
        - echo hello && sleep 10
        image: busybox
        imagePullPolicy: IfNotPresent
        name: job1
        resources: {}
      restartPolicy: Never
status: {}
```

增加IfNotPresent

job的restart 策略有两种:

- Never: 只要任务没有完成,则新创建pod运行，知道job完成,会产生多个pod
- OnFailure: 只要pod没有完成, 就会重启pod,重新执行任务

#### 创建job

```bash
[root@master probe]# kubectl apply -f job.yaml 
job.batch/job1 created
```

#### 查看job状态

```bash
[root@master probe]# kubectl get jobs
NAME   COMPLETIONS   DURATION   AGE
job1   1/1           11s        34s
```

1/1显示完成

#### 删除pod

```bash
[root@master probe]# kubectl delete job job1
job.batch "job1" deleted
```

#### job中指定参数

parallelism: N  并行运行N个pod，parallelism的值 不会超过completions

completions: M  job测试多次的话,要有M次要成功才算成功,即要有M个状态为Complete的pod,如果没有就重复执行

backoffLimit: N  如果job失败,则重试几次

activeDeadlineSeconds: N  job运行的最长时间，单位: 秒

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  creationTimestamp: null
  name: job1
spec:
  parallelism: 3
  completions: 6
  backoffLimit: 4
  template:
    metadata:
      creationTimestamp: null
    spec:
      containers:
      - command:
        - sh
        - -c
        - echo hello && sleep 10
        image: busybox
        imagePullPolicy: IfNotPresent
        name: job1
        resources: {}
      restartPolicy: Never
status: {}
```

并行设置3个,要有6个pod处于完成状态才可以

#### 创建

```bash
[root@master probe]# kubectl apply -f job.yaml 
job.batch/job1 created
```

#### 查看pod

```bash
[root@master probe]# kubectl get pods
NAME         READY   STATUS      RESTARTS   AGE
job1-9m4rl   0/1     Completed   0          17s
job1-hhm75   1/1     Running     0          5s
job1-l9kqn   1/1     Running     0          5s
job1-pw7kk   0/1     Completed   0          17s
job1-qmdxd   0/1     Completed   0          17s
job1-rm44q   1/1     Running     0          5s
```

有三个运行的job

#### 查看job

```bash
[root@master probe]# kubectl get jobs
NAME   COMPLETIONS   DURATION   AGE
job1   6/6           24s        68s
```

#### 再次看pod的状态

```bash
[root@master probe]# kubectl get pods
NAME         READY   STATUS      RESTARTS   AGE
job1-9m4rl   0/1     Completed   0          95s
job1-hhm75   0/1     Completed   0          83s
job1-l9kqn   0/1     Completed   0          83s
job1-pw7kk   0/1     Completed   0          95s
job1-qmdxd   0/1     Completed   0          95s
job1-rm44q   0/1     Completed   0          83s
```

#### 删除

```bash
[root@master probe]# kubectl delete -f job.yaml 
job.batch "job1" deleted
```

#### 测试失败

```yaml
apiVersion: batch/v1
kind: Job
metadata:
  creationTimestamp: null
  name: job1
spec:
  parallelism: 3
  completions: 6
  backoffLimit: 4
  template:
    metadata:
      creationTimestamp: null
    spec:
      containers:
      - command:
        - sh
        - -c
        - echoX hello && sleep 10
        image: busybox
        imagePullPolicy: IfNotPresent
        name: job1
        resources: {}
      restartPolicy: Never
status: {}
~              
```

```bash
[root@master probe]# kubectl apply -f job.yaml 
job.batch/job1 created
```

```bash
[root@master probe]# kubectl get pods
NAME         READY   STATUS   RESTARTS   AGE
job1-6858m   0/1     Error    0          6s
job1-dbpgx   0/1     Error    0          9s
job1-gndds   0/1     Error    0          8s
job1-nb9gr   0/1     Error    0          8s
job1-xh45n   0/1     Error    0          9s
job1-xnhqb   0/1     Error    0          9s
```

```bash
[root@master probe]# kubectl delete -f job.yaml 
job.batch "job1" deleted
```

### 创建及删除cronjob

```bash
[root@master probe]# kubectl get cj
No resources found in nsjob namespace.
```

#### 命令创建

kubectl create cj 名字 --image=镜像 --schedule="*/1 * * * *" -- /bin/sh -c "命令"

--schedule 定时

#### yaml创建

```bash
[root@master probe]# kubectl create cj job2 --image=busybox --schedule="*/1 * * * *" --dry-run=client -o yaml -- /bin/sh -c "echo hello world" > job2.yaml
```

```bash
apiVersion: batch/v1
kind: CronJob
metadata:
  creationTimestamp: null
  name: job2
spec:
  jobTemplate:
    metadata:
      creationTimestamp: null
      name: job2
    spec:
      template:
        metadata:
          creationTimestamp: null
        spec:
          containers:
          - command:
            - /bin/sh
            - -c
            - echo hello world
            image: busybox
            name: job2
            resources: {}
          restartPolicy: OnFailure
  schedule: '*/1 * * * *'
status: {}
```

#### 创建

```bash
[root@master probe]# kubectl apply -f job2.yaml 
cronjob.batch/job2 created
```

#### 查看

```bash
[root@master probe]# kubectl get cj
NAME   SCHEDULE      SUSPEND   ACTIVE   LAST SCHEDULE   AGE
job2   */1 * * * *   False     0        <none>          10s
```

```bash
[root@master probe]# kubectl get pods
NAME                  READY   STATUS              RESTARTS   AGE
job2-27642647-th984   0/1     ContainerCreating   0          21s
```

```bash
[root@master probe]# kubectl get pods
NAME                  READY   STATUS      RESTARTS   AGE
job2-27642647-th984   0/1     Completed   0          79s
job2-27642648-wgkzc   0/1     Completed   0          19s
```

#### 删除

```bash
[root@master probe]# kubectl delete -f job2.yaml 
cronjob.batch "job2" deleted
```


