---
title: "`Python中的 __call__`"
tags:
  - Python
toc: true
---

Python 中特殊方法的一些理解笔记

如果python中的一个类定义了 __call__ 方法，那么这个类它的实例就可以作为函数调用,也就是实现了 () 运算符，即可调用对象协议

### code
```python
class TmpTest:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __call__(self, x, y):
        self.x, self.y = x, y


a = TmpTest(1, 2)
a(4, 5)
print(a.x, a.y)
4 5
```

在本文中不讨论装饰部分的内容，借用装饰器来讲解一个__call__方法的使用，如果需要将一个类作为装饰器，那需要为这个类实现__call__方法，一个使用__call__来实现类装饰器的例子
```python
class TmpTest:
    def __init__(self, func):
        self.func=func

    def __call__(self, *args,**kwargs):
        result=self.func(*args,**kwargs)
        return result


@TmpTest
def add_num(x,y):
    return x+y

print(add_num(1,0))
1
```
