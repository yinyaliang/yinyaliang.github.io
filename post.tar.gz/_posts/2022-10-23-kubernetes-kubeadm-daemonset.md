---
title: "Daemonset"
tags:
  - Kubernetes
toc: true
---

daemonset


### 创建及删除daemonset

- daemonset会在所有的节点上创建一个pod,有几个节点就创建几个pod,每个节点只有一个
- 一般用于监控、日志等，每个节点上运行一个pod
- master上不会产生Pod,因为master上有污点

```bash
[root@master ~]# kubectl describe nodes master | grep ^Taints
Taints:             node-role.kubernetes.io/master:NoSchedule
```

#### 查看

```bash
[root@master ~]# kubectl get ds
No resources found in nsdeploy namespace.
```

#### 创建及删除ds

```bash
mkdir ds
cd ds/
```

```bash
[root@master ds]# kubectl create ns nsds
namespace/nsds created
[root@master ds]# kubens nsds
Context "kubernetes-admin@kubernetes" modified.
Active namespace is "nsds".
```

daemonset和deployment的yaml只有四点不同,

- 把kind改成Daemonset
- deployment有副本数,daemonset没有副本数
- 删除.spec下的strategy:{}
- 删除最后一行的status:{}

```yaml
apiVersion:  apps/v1
kind:  DaemonSet
metadata:  
  name:  ds1
spec:
  selector:
    matchLabels:
      app:  busybox
  template:
    metadata:
      labels:
        app:  busybox
    spec:
      containers:
      - image: busybox
        imagePullPolicy:  IfNotPresent
        name:  busybox
        command:  ["sh","-c","sleep 36000"]
```

```bash
[root@master ds]# kubectl apply -f ds1.yaml 
daemonset.apps/ds1 created
```

#### 查看pod的运行

```bash
[root@master ds]# kubectl get pods -o wide
NAME        READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
ds1-2b2cq   1/1     Running   0          27s   10.244.104.48    node2   <none>           <none>
ds1-b2rgv   1/1     Running   0          27s   10.244.166.169   node1   <none>           <none>
```

#### 删除daemonset

```bash
[root@master ds]# kubectl delete ds ds1
daemonset.apps "ds1" deleted
```

```bash
[root@master ds]# kubectl get ds
No resources found in nsds namespace.
```



### 指定pod运行在特定的节点

可以通过标签的方式制定daemonset的pod在指定的节点上运行

```yaml
apiVersion:  apps/v1
kind:  DaemonSet
metadata:  
  name:  ds1
spec:
  selector:
    matchLabels:
      app:  busybox
  template:
    metadata:
      labels:
        app:  busybox
    spec:
      nodeSelector:
        diskxx:  ssdxx
      containers:
      - image: busybox
        imagePullPolicy:  IfNotPresent
        name:  busybox
        command:  ["sh","-c","sleep 36000"]
```

这里通过nodeSelector来指定pod运行在含有标签diskxx==ssdxx的节点上

### 其它控制器 ReplicationController (rc)

 rc和deployment的作用一样，使用方法也一样

```bash
[root@master ds]# kubectl get rc
No resources found in nsds namespace.
```

#### 创建rc所需要的yaml文件

```yaml
apiVersion:  v1
kind:  ReplicationController
metadata:
  name:  myrc
spec:
  replicas:  3
  selector:
    app:  nginx
  template:
    metadata:
      labels:
        app:  nginx
    spec:
      containers:
      - name:  nginx
        image:  nginx
        imagePullPolicy:  IfNotPresent
        ports:
        - containerPort:  80
```

```bash
[root@master ds]# kubectl apply -f rc1.yaml 
replicationcontroller/myrc created
```

#### 查看

```bash
[root@master ds]# kubectl get rc
NAME   DESIRED   CURRENT   READY   AGE
myrc   3         3         3       30s
[root@master ds]# kubectl get pods
NAME         READY   STATUS    RESTARTS   AGE
myrc-cqj4m   1/1     Running   0          38s
myrc-hdjz8   1/1     Running   0          38s
myrc-s77mw   1/1     Running   0          38s
```

#### 扩展

```bash
[root@master ds]# kubectl scale rc myrc --replicas=5
replicationcontroller/myrc scaled
```

```bash
[root@master ds]# kubectl get pods
NAME         READY   STATUS    RESTARTS   AGE
myrc-bzphd   1/1     Running   0          11s
myrc-cqj4m   1/1     Running   0          94s
myrc-hdjz8   1/1     Running   0          94s
myrc-kn5zc   1/1     Running   0          11s
myrc-s77mw   1/1     Running   0          94s
```

#### 更新

```bash
[root@master ds]# kubectl get rc -o wide
NAME   DESIRED   CURRENT   READY   AGE    CONTAINERS   IMAGES   SELECTOR
myrc   5         5         5       2m6s   nginx        nginx    app=nginx
```

```bash
[root@master ds]# kubectl set image rc myrc nginx=nginx:1.9
replicationcontroller/myrc image updated
```

```bash
[root@master ds]# kubectl get rc -o wide
NAME   DESIRED   CURRENT   READY   AGE     CONTAINERS   IMAGES      SELECTOR
myrc   5         5         5       2m42s   nginx        nginx:1.9   app=nginx
```

#### 删除

```bash
kubectl delete rc myrc
```

### 其他控制器 RplicaSet (rs)

和deployment作用一样

#### 查看

```bash
[root@master ds]# kubectl get rs
No resources found in nsds namespace.
```

#### 创建

```yaml
apiVersion:  apps/v1
kind:  ReplicaSet
metadata:
  name:  myrs
  labels:
    app:  rs1
spec:
  replicas:  3
  selector:
    matchLabels:
      app:  rsx
  template:
    metadata:
      labels:
        app:  rsx
    spec:
      containers:
      - name:  web
        imagePullPolicy:  IfNotPresent
        image:  nginx
```

```bash
[root@master ds]# kubectl apply -f rs1.yaml 
replicaset.apps/myrs created
```

```bash
[root@master ds]# kubectl get pods
NAME         READY   STATUS    RESTARTS   AGE
myrs-mc2j6   1/1     Running   0          23s
myrs-rbg92   1/1     Running   0          23s
myrs-zx9db   1/1     Running   0          23s
```

#### 扩展

```bash
[root@master ds]# kubectl scale rs myrs --replicas=5
replicaset.apps/myrs scaled
```

```bash
[root@master ds]# kubectl get pods -o wide
NAME         READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
myrs-htmgf   1/1     Running   0          14s   10.244.166.178   node1   <none>           <none>
myrs-mc2j6   1/1     Running   0          84s   10.244.166.176   node1   <none>           <none>
myrs-rbg92   1/1     Running   0          84s   10.244.166.177   node1   <none>           <none>
myrs-skxft   1/1     Running   0          14s   10.244.166.179   node1   <none>           <none>
myrs-zx9db   1/1     Running   0          84s   10.244.166.175   node1   <none>           <none>
```

#### 删除

```bash
[root@master ds]# kubectl delete rs myrs
replicaset.apps "myrs" deleted
```

#### 对比

|                       | api     | select                  |
| --------------------- | ------- | ----------------------- |
| deploment             | apps/v1 | selector<br>matchLabels |
| daemonset             | apps/v1 | selector<br>matchLaels  |
| ReplicationController | v1      | selector                |
| ReplicaSet            | apps/v1 | selector<br>matchLabels |
