---
title: "Zabbix 对于 KVM 虚拟机资源监控"
tags:
  - Monitor
toc: true
---

采集KVM虚拟主机CPU以及内存使用资源情况

#### 安装

##### centos

```bash
 yum -y install libvirt-devel
```

##### ubuntu

```bash
apt install libvirt-dev
```

package

```bash
 go get libvirt/libvirt-go
```

#### 代码

```golang
package kvm

import (
	"encoding/json"
	"fmt"
	"time"

	"libvirt.org/go/libvirt"
	"zabbix.com/pkg/plugin"
	"zabbix.com/pkg/zbxerr"
)

type Plugin struct {
	plugin.Base
}

var impl Plugin

func (p *Plugin) Export(key string, params []string, ctx plugin.ContextProvider) (result interface{}, err error) {
	switch key {
	case "kvm.avtive.domain.discovery":
		result, err := p.virtual_host_discovery()
		if err != nil {
			return nil, err
		}
		return string(result), nil
	case "domain.info":
		result, err := p.virtual_domain_info(params)
		if err != nil {
			return nil, err
		}
		return string(result), nil
	default:
		return nil, plugin.UnsupportedMetricError
	}
}

type kvmkDiscovery struct {
	Kvm string `json:"{#KVM}"`
}

type domainInfo struct {
	MemUnUsed uint64 `json:"MEMUNUSED"`
	CPUUsage  uint64 `json:"CPUUsage"`
}

func (p *Plugin) virtual_domain_info(params []string) (result []byte, err error) {
	if len(params) != 1 {
		return nil, fmt.Errorf("Invalid parameter.")
	}

	domainName := params[0]

	conn, err := libvirt.NewConnect("qemu:///system")
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	var domainifo domainInfo

	var cpu_time_last uint64
	var cpu_time_pre uint64
	var memory_unused uint64
	var cpuUsage uint64
	for count := 1; count <= 2; count++ {

		doms, err := conn.ListAllDomains(libvirt.CONNECT_LIST_DOMAINS_ACTIVE)
		if err != nil {
			return nil, err
		}
		for _, dom := range doms {
			name, err := dom.GetName()
			if err != nil {
				return nil, err
			}
			if name != domainName {
				dom.Free()
				continue
			}
			// memory
			meminfo, err := dom.MemoryStats(10, 0)

			for _, tag := range meminfo {
				if tag.Tag == 5 {
					memory_unused = tag.Val
				}
			}
			// Query cpu total stats
			cpuStats, err := dom.GetCPUStats(-1, 1, 0)
			if err != nil {
				return nil, err
			}
			cpu_time_pre = cpu_time_last
			cpu_time_last = cpuStats[0].CpuTime
			cpuUsage = 100 * (cpu_time_last - cpu_time_pre) / (1 * 1000000000)

			dom.Free()
		}
		time.Sleep(1 * time.Second)
	}

	domainifo.CPUUsage = cpuUsage
	domainifo.MemUnUsed = memory_unused
	if result, err = json.Marshal(&domainifo); err != nil {
		return nil, zbxerr.ErrorCannotMarshalJSON.Wrap(err)
	}
	return
}

func (p *Plugin) virtual_host_discovery() (result []byte, err error) {
	conn, err := libvirt.NewConnect("qemu:///system")
	if err != nil {
		return nil, err
	}
	defer conn.Close()
	kvm := make([]kvmkDiscovery, 0)
	// 获取所有开启的虚拟机名称

	doms, err := conn.ListAllDomains(libvirt.CONNECT_LIST_DOMAINS_ACTIVE)

	if err != nil {
		return nil, err
	}

	for _, dom := range doms {

		name, err := dom.GetName()
		if err != nil {
			return nil, err
		}

		kvm = append(kvm, kvmkDiscovery{Kvm: name})
		dom.Free()
	}

	if result, err = json.Marshal(&kvm); err != nil {
		return nil, zbxerr.ErrorCannotMarshalJSON.Wrap(err)
	}
	return
}

func init() {
	plugin.RegisterMetrics(&impl, "Kvm",
		"kvm.avtive.domain.discovery", "Returns availabe domain.",
		"domain.info", "Extract information about a domain.")
}

```

#### 效果

<img src="/assets/images/zabbix/03.png">

#### 参考
```
https://people.redhat.com/rjones/virt-top/faq.html
https://gitlab.com/libvirt/libvirt-go/blob/v7.4.0/domain.go#L369
https://pkg.go.dev/libvirt.org/libvirt-go
```
