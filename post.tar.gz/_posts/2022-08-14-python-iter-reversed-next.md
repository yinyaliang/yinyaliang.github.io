---
title: "`Python中的 __iter__ __reversed__ __next__`"
tags:
  - Python
toc: true
---

Python 中特殊方法的一些理解笔记

### __reversed__说明

返回集合的倒叙迭代器,如果没有实现这个方法,reversed()会去使用__getitem__和__len__来实现

###  特殊方法__next__和__iter__说明

介绍__next__和__iter__方法需要了解下可迭代对象(iterable)和迭代器(iterator):

##### iterable

如果对象实现了__iter__方法,那么对象就是可迭代的。python中的序列都可以迭代。如果没有实现__iter__,实现了__getitem__方法,而且参数是从零开始的索引,这种对象也可以迭代。

##### iterator

标准的迭代器都有两个方法___next__和__iter__:
* __next__返回下一个可用的元素,如果没有元素了,抛出 StopIteration 异常
* __iter__返回self


#### code
python从可迭代对象中获取迭代器(可迭代对象---iter()--->迭代器---next()--->值)   


```python
In [9]: a=(1,2,3)

    In [10]: type(a)
    Out[10]: tuple

    In [11]: b=iter(a)

    In [12]: type(b)
    Out[12]: tuple_iterator

    In [13]: a=[1,2,3]

    In [14]: type(a)
    Out[14]: list

    In [15]: b=iter(a)

    In [16]: type(b)
    Out[16]: list_iterator
    
    In [20]: while True:
    ...:     try:
    ...:         print(next(b))
    ...:     except StopIteration:
    ...:         break
    ...:
    1
    2
    3
    也可以使用for来做,上面的异常python已经内部自动处理:
    In [3]: for i in b:
   ...:     print(i)
   ...:
    1
    2
    3
```

定义一个可迭代对象和迭代器

```python
from random import choice
class TmptestIterator:
    def __iter__(self):
        return self
    def __next__(self):
        tmp=choice([i for i in range(10)])
        if tmp == 5:
            raise StopIteration
        return tmp

class TemTest:
    def __iter__(self):
        return TmptestIterator()
```

```python
a=TemTest()
print(TmptestIterator,TemTest)
for i in a:
    print (i)

<class '__main__.TmptestIterator'> <class '__main__.TemTest'>
6
1
1
2
2
2
1
3
```

#### 参考
https://docs.python.org/3/library/stdtypes.html#container.__iter__()
