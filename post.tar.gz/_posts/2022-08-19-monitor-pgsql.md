---
title: "pgsql监控"
tags:
  - Monitor
toc: true
---
 
测试pgsql监控

### 系统
Centos 7

### 安装pgsql

```bash
sudo yum install -y https://download.postgresql.org/pub/repos/yum/reporpms/EL-7-x86_64/pgdg-redhat-repo-latest.noarch.rpm
sudo yum install -y postgresql12-server
sudo /usr/pgsql-12/bin/postgresql-12-setup initdb
sudo systemctl enable postgresql-12
sudo systemctl start postgresql-12
```

### 数据库设置
```bash
sudo su postgres
psql
CREATE USER zbx_monitor WITH PASSWORD 'monitor' INHERIT;
GRANT EXECUTE ON FUNCTION pg_catalog.pg_ls_dir(text) TO zbx_monitor;
GRANT EXECUTE ON FUNCTION pg_catalog.pg_stat_file(text) TO zbx_monitor;
GRANT EXECUTE ON FUNCTION pg_catalog.pg_ls_waldir() TO zbx_monitor;
```

### 监控配置
监控页面添加主机挂载对应pgsql模板

### 参考
https://www.postgresql.org/download/linux/redhat/

