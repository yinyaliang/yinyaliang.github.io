---
title: "Centos Prometheus 安装"
tags:
  - Application
toc: true
---

Prometheus 在centos中的安装记录

### 下载
```bash
cd /tmp
wget https://github.com/prometheus/prometheus/releases/download/v2.37.0/prometheus-2.37.0.linux-amd64.tar.gz
```

### 解压
```bash
tar zxvfp prometheus-2.37.0.linux-amd64.tar.gz
mv prometheus-2.37.0.linux-amd64 /usr/local/
mkdir /data/config/oss/prometheus
cd /usr/local/
ln -s prometheus-2.37.0.linux-amd64 prometheus
 
cd prometheus
mv prometheus.yml /data/config/oss/prometheus/
 
mkdir /data/prometeus
mv data /data/prometeus/
```

### 启动文件
```bash
cat << 'EOF' | sudo tee /etc/systemd/system/prometheus.service
[Unit]
Description=Prometheus Server
Documentation=https://prometheus.io/docs/introduction/overview/
After=network-online.target
 
[Service]
User=root
ExecStart=/usr/local/prometheus/prometheus --config.file=/data/config/oss/prometheus/prometheus.yml --storage.tsdb.path=/data/prometeus/data --web.console.templates=/data/config/oss/prometheus/consoles  --web.console.libraries=/data/config/oss/prometheus/console_libraries
ExecStop=/bin/kill -TERM ${MAINPID}
ExecReload=/bin/kill -HUP ${MAINPID}
 
[Install]
WantedBy=multi-user.target
EOF
```

### 启动服务
```bash
systemctl daemon-reload
systemctl enable prometheus.service
systemctl start prometheus.service
systemctl status prometheus.service
```
