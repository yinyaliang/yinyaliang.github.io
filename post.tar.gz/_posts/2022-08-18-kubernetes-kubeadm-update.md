---
title: "使用kubeadm 升级Kubernetes "
tags:
  - Kubernetes
toc: true
---

升级kubernetes版本

### 安装一套v1.20.1集群

#### 创建两台主机

| 主机名  | IP地址          | 内存需求 | 操作系统 | 角色   |
| ------- | --------------- | -------- | -------- | ------ |
| umaster | 192.168.122.240 | 4GB      | centos 7 | master |
| unode1  | 192.168.122.241 | 4GB      | centos 7 | node   |

#### 初始化配置

```
virt-install --name umaster --ram 4096 --vcpus=4 --os-type=linux --accelerate --cdrom=/home/kvm/CentOS-7.5-x86_64-Minimal-1804.iso  --disk path=/home/kvm/umaster.qcow2,size=30,format=qcow2,bus=ide --bridge=virbr0 --vnc --vncport=60021 --vnclisten=0.0.0.0
```

```
virt-install --name unode1 --ram 4096 --vcpus=2 --os-type=linux --accelerate --cdrom=/home/kvm/CentOS-7.5-x86_64-Minimal-1804.iso  --disk path=/home/kvm/unode1.qcow2,size=30,format=qcow2,bus=ide --bridge=virbr0 --vnc --vncport=60022 --vnclisten=0.0.0.0
```

所有节点初始化

```bash
# master node 关闭防火墙  
systemctl stop firewalld 
systemctl disable firewalld 
 
# master node 关闭selinux   
sed -i 's/enforcing/disabled/' /etc/selinux/config  # 永久 
setenforce 0  # 临时 
 
# master node 关闭swap 
swapoff -a  # 临时 
sed -ri 's/.*swap.*/#&/' /etc/fstab    # 永久 
 
# master node 时间同步 
yum install ntpdate -y 
ntpdate time.windows.com

# master node 安装vim wget
yum -y install vim wget 
 
#添加hosts 
cat >> /etc/hosts << EOF 
192.168.122.240 master
192.168.122.241 node1 
EOF 
 
# 将桥接的IPv4流量传递到iptables的链 
cat > /etc/sysctl.d/k8s.conf << EOF 
net.bridge.bridge-nf-call-ip6tables = 1 
net.bridge.bridge-nf-call-iptables = 1 
EOF 

sysctl --system  # 生效 
 
# master 设置 
hostnamectl set-hostname master
# node1 设置
hostnamectl set-hostname node1
# node2 设置
hostnamectl set-hostname node2

# 安装docker
bash <(wget -O- get.docker.com)

#启动并设置开机启动
systemctl daemon-reload
systemctl start docker
systemctl enable docker
systemctl status docker

#修改配置
cat > /etc/docker/daemon.json << EOF
{
  "registry-mirrors": ["https://b9pmyelo.mirror.aliyuncs.com"]
}
EOF

#重启
systemctl restart docker
```

```bash
mv /etc/yum.repos.d/* /tmp/
wget -P /etc/yum.repos.d/ ftp://ftp.rhce.cc/k8s/*
```

```bash
yum install -y kubelet-1.20.1-0 kubeadm-1.20.1-0 kubectl-1.20.1-0 --disableexcludes=kubernetes
```

```bash
systemctl restart kubelet
systemctl enable kubelet
```

#### 导出配置

master上到传到umaster，修改版本

```bash
[root@master tmp]# kubectl get cm -o yaml -n kube-system kubeadm-config
apiVersion: v1
data:
  ClusterConfiguration: |
    apiServer:
      extraArgs:
        authorization-mode: Node,RBAC
      timeoutForControlPlane: 4m0s
    apiVersion: kubeadm.k8s.io/v1beta2
    certificatesDir: /etc/kubernetes/pki
    clusterName: kubernetes
    controllerManager: {}
    dns:
      type: CoreDNS
    etcd:
      local:
        dataDir: /var/lib/etcd
    imageRepository: registry.aliyuncs.com/google_containers
    kind: ClusterConfiguration
    kubernetesVersion: v1.20.1
    networking:
      dnsDomain: cluster.local
      podSubnet: 10.244.0.0/16
      serviceSubnet: 10.96.0.0/12
    scheduler: {}
  ClusterStatus: |
    apiEndpoints:
      master:
        advertiseAddress: 192.168.122.200
        bindPort: 6443
    apiVersion: kubeadm.k8s.io/v1beta2
    kind: ClusterStatus
kind: ConfigMap
metadata:
  creationTimestamp: "2022-07-10T12:08:39Z"
  name: kubeadm-config
  namespace: kube-system
  resourceVersion: "206"
  uid: ccf5abbc-caed-4528-a572-9422a71112a1
```

创建集群

```bash
kubeadm init --config=kubeadm-config.yaml
```

umaster执行

```bash
  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config
```

unode1加入集群

```bash
kubeadm join 192.168.122.240:6443 --token vy5ws2.p3e19ircj05jfoyo \
    --discovery-token-ca-cert-hash sha256:6441dd3e73c23c9cc85c62454f1786d820f891a8fd73263f500fdf2180c4efb8 
```

#### 安装calico

master上执行

```bash
cd /tmp
wget https://docs.projectcalico.org/v3.19/manifests/calico.yaml --no-check-certificate
```

修改

```yaml
            - name: CALICO_IPV4POOL_CIDR
              value: "192.168.0.0/16"
```

为

```yaml
            - name: CALICO_IPV4POOL_CIDR
              value: "10.244.0.0/16"
```

下载镜像

```
[root@master tmp]# grep image calico.yaml 
          image: docker.io/calico/cni:v3.19.4
          image: docker.io/calico/cni:v3.19.4
          image: docker.io/calico/pod2daemon-flexvol:v3.19.4
          image: docker.io/calico/node:v3.19.4
          image: docker.io/calico/kube-controllers:v3.19.4
```

```bash
for i in calico/cni:v3.19.4 calico/pod2daemon-flexvol:v3.19.4  calico/node:v3.19.4 calico/kube-controllers:v3.19.4 ;do docker pull $i;done
```

安装calico

```bash
kubectl apply -f calico.yaml
```

查看

```bash
[root@umaster tmp]# kubectl get nodes
NAME      STATUS   ROLES                  AGE   VERSION
umaster   Ready    control-plane,master   16m   v1.20.1
unode1    Ready    <none>                 15m   v1.20.1

[root@umaster tmp]# kubectl version --short
Client Version: v1.20.1
Server Version: v1.20.1
```

### 步骤

节点  先升级master  再升级worker  多台master，先升级master 在升级worker

软件  先升级kubeadm 然后执行 kubeadm upgrade,再升级 kubelet和kubectl

## 升级master

确定源里的kubeadm的可用版本

```bash
yum list --showduplicates kubeadm
```

#### 升级kubeadm

```bash
yum -y install kubeadm-1.21.1-0 --disableexcludes=kubernetes
```

验证

```bash
[root@umaster tmp]# kubeadm version
kubeadm version: &version.Info{Major:"1", Minor:"21", GitVersion:"v1.21.1", GitCommit:"5e58841cce77d4bc13713ad2b91fa0d961e69192", GitTreeState:"clean", BuildDate:"2021-05-12T14:17:27Z", GoVersion:"go1.16.4", Compiler:"gc", Platform:"linux/amd64"}
```

#### 查看集群是否需要升级,以及可以升级的版本

```bash
[root@umaster tmp]# kubeadm upgrade plan
[upgrade/config] Making sure the configuration is correct:
[upgrade/config] Reading configuration from the cluster...
[upgrade/config] FYI: You can look at this config file with 'kubectl -n kube-system get cm kubeadm-config -o yaml'
[preflight] Running pre-flight checks.
[upgrade] Running cluster health checks
[upgrade] Fetching available versions to upgrade to
[upgrade/versions] Cluster version: v1.20.1
[upgrade/versions] kubeadm version: v1.21.1
I0710 23:34:23.085584    1579 version.go:254] remote version is much newer: v1.24.2; falling back to: stable-1.21
[upgrade/versions] Target version: v1.21.14
[upgrade/versions] Latest version in the v1.20 series: v1.20.15

Components that must be upgraded manually after you have upgraded the control plane with 'kubeadm upgrade apply':
COMPONENT   CURRENT       TARGET
kubelet     2 x v1.20.1   v1.20.15

Upgrade to the latest version in the v1.20 series:

COMPONENT                 CURRENT    TARGET
kube-apiserver            v1.20.1    v1.20.15
kube-controller-manager   v1.20.1    v1.20.15
kube-scheduler            v1.20.1    v1.20.15
kube-proxy                v1.20.1    v1.20.15
CoreDNS                   1.7.0      v1.8.0
etcd                      3.4.13-0   3.4.13-0

You can now apply the upgrade by executing the following command:

        kubeadm upgrade apply v1.20.15

_____________________________________________________________________

Components that must be upgraded manually after you have upgraded the control plane with 'kubeadm upgrade apply':
COMPONENT   CURRENT       TARGET
kubelet     2 x v1.20.1   v1.21.14

Upgrade to the latest stable version:

COMPONENT                 CURRENT    TARGET
kube-apiserver            v1.20.1    v1.21.14
kube-controller-manager   v1.20.1    v1.21.14
kube-scheduler            v1.20.1    v1.21.14
kube-proxy                v1.20.1    v1.21.14
CoreDNS                   1.7.0      v1.8.0
etcd                      3.4.13-0   3.4.13-0

You can now apply the upgrade by executing the following command:

        kubeadm upgrade apply v1.21.14

Note: Before you can perform this upgrade, you have to update kubeadm to v1.21.14.

_____________________________________________________________________


The table below shows the current state of component configs as understood by this version of kubeadm.
Configs that have a "yes" mark in the "MANUAL UPGRADE REQUIRED" column require manual config upgrade or
resetting to kubeadm defaults before a successful upgrade can be performed. The version to manually
upgrade to is denoted in the "PREFERRED VERSION" column.

API GROUP                 CURRENT VERSION   PREFERRED VERSION   MANUAL UPGRADE REQUIRED
kubeproxy.config.k8s.io   v1alpha1          v1alpha1            no
kubelet.config.k8s.io     v1beta1           v1beta1             no
_____________________________________________________________________
```

#### master置为维护模式

```bash
[root@umaster tmp]# kubectl drain umaster --ignore-daemonsets
node/umaster cordoned
WARNING: ignoring DaemonSet-managed Pods: kube-system/calico-node-76vzp, kube-system/kube-proxy-ttm4n
evicting pod kube-system/coredns-7f89b7bc75-qrns5
evicting pod kube-system/calico-kube-controllers-848c5d445f-8v7t2
evicting pod kube-system/coredns-7f89b7bc75-p54c4
pod/coredns-7f89b7bc75-qrns5 evicted
pod/coredns-7f89b7bc75-p54c4 evicted
pod/calico-kube-controllers-848c5d445f-8v7t2 evicted
```

验证

```bash
[root@umaster tmp]# kubectl get nodes
NAME      STATUS                     ROLES                  AGE   VERSION
umaster   Ready,SchedulingDisabled   control-plane,master   47m   v1.20.1
unode1    Ready                      <none>                 46m   v1.20.1
```

处理coredns

```bash
docker pull coredns/coredns:1.8.0
docker tag coredns/coredns:1.8.0 registry.aliyuncs.com/google_containers/coredns/coredns:v1.8.0
docker rmi coredns/coredns:1.8.0
```

#### 升级组件

```bash
[root@umaster tmp]# kubeadm upgrade apply v1.21.1
[upgrade/config] Making sure the configuration is correct:
[upgrade/config] Reading configuration from the cluster...
[upgrade/config] FYI: You can look at this config file with 'kubectl -n kube-system get cm kubeadm-config -o yaml'
[preflight] Running pre-flight checks.
[upgrade] Running cluster health checks
[upgrade/version] You have chosen to change the cluster version to "v1.21.1"
[upgrade/versions] Cluster version: v1.20.1
[upgrade/versions] kubeadm version: v1.21.1
[upgrade/confirm] Are you sure you want to proceed with the upgrade? [y/N]: y
[upgrade/prepull] Pulling images required for setting up a Kubernetes cluster
[upgrade/prepull] This might take a minute or two, depending on the speed of your internet connection
[upgrade/prepull] You can also perform this action in beforehand using 'kubeadm config images pull'
[upgrade/apply] Upgrading your Static Pod-hosted control plane to version "v1.21.1"...
Static pod: kube-apiserver-umaster hash: 6df1b5224c3fc3fb71a622a2c30fcaea
Static pod: kube-controller-manager-umaster hash: de64b953177047fd563a18150d6c6070
Static pod: kube-scheduler-umaster hash: 78404d25f9e940515e51f92dc60988eb
[upgrade/etcd] Upgrading to TLS for etcd
Static pod: etcd-umaster hash: 8810d7e5e8825396038f6fef0fb4bd30
[upgrade/staticpods] Preparing for "etcd" upgrade
[upgrade/staticpods] Current and new manifests of etcd are equal, skipping upgrade
[upgrade/etcd] Waiting for etcd to become available
[upgrade/staticpods] Writing new Static Pod manifests to "/etc/kubernetes/tmp/kubeadm-upgraded-manifests922784263"
[upgrade/staticpods] Preparing for "kube-apiserver" upgrade
[upgrade/staticpods] Renewing apiserver certificate
[upgrade/staticpods] Renewing apiserver-kubelet-client certificate
[upgrade/staticpods] Renewing front-proxy-client certificate
[upgrade/staticpods] Renewing apiserver-etcd-client certificate
[upgrade/staticpods] Moved new manifest to "/etc/kubernetes/manifests/kube-apiserver.yaml" and backed up old manifest to "/etc/kubernetes/tmp/kubeadm-backup-manifests-2022-07-10-23-44-12/kube-apiserver.yaml"
[upgrade/staticpods] Waiting for the kubelet to restart the component
[upgrade/staticpods] This might take a minute or longer depending on the component/version gap (timeout 5m0s)
Static pod: kube-apiserver-umaster hash: 6df1b5224c3fc3fb71a622a2c30fcaea
Static pod: kube-apiserver-umaster hash: bec11aedb967e3dd4da819e28c3611dc
[apiclient] Found 1 Pods for label selector component=kube-apiserver
[upgrade/staticpods] Component "kube-apiserver" upgraded successfully!
[upgrade/staticpods] Preparing for "kube-controller-manager" upgrade
[upgrade/staticpods] Renewing controller-manager.conf certificate
[upgrade/staticpods] Moved new manifest to "/etc/kubernetes/manifests/kube-controller-manager.yaml" and backed up old manifest to "/etc/kubernetes/tmp/kubeadm-backup-manifests-2022-07-10-23-44-12/kube-controller-manager.yaml"
[upgrade/staticpods] Waiting for the kubelet to restart the component
[upgrade/staticpods] This might take a minute or longer depending on the component/version gap (timeout 5m0s)
Static pod: kube-controller-manager-umaster hash: de64b953177047fd563a18150d6c6070
Static pod: kube-controller-manager-umaster hash: d69c9bc304051e2fcc0aba1a366e8511
[apiclient] Found 1 Pods for label selector component=kube-controller-manager
[upgrade/staticpods] Component "kube-controller-manager" upgraded successfully!
[upgrade/staticpods] Preparing for "kube-scheduler" upgrade
[upgrade/staticpods] Renewing scheduler.conf certificate
[upgrade/staticpods] Moved new manifest to "/etc/kubernetes/manifests/kube-scheduler.yaml" and backed up old manifest to "/etc/kubernetes/tmp/kubeadm-backup-manifests-2022-07-10-23-44-12/kube-scheduler.yaml"
[upgrade/staticpods] Waiting for the kubelet to restart the component
[upgrade/staticpods] This might take a minute or longer depending on the component/version gap (timeout 5m0s)
Static pod: kube-scheduler-umaster hash: 78404d25f9e940515e51f92dc60988eb
Static pod: kube-scheduler-umaster hash: 57952607cc2b5d4a4ac242954121e925
[apiclient] Found 1 Pods for label selector component=kube-scheduler
[upgrade/staticpods] Component "kube-scheduler" upgraded successfully!
[upgrade/postupgrade] Applying label node-role.kubernetes.io/control-plane='' to Nodes with label node-role.kubernetes.io/master='' (deprecated)
[upgrade/postupgrade] Applying label node.kubernetes.io/exclude-from-external-load-balancers='' to control plane Nodes
[upload-config] Storing the configuration used in ConfigMap "kubeadm-config" in the "kube-system" Namespace
[kubelet] Creating a ConfigMap "kubelet-config-1.21" in namespace kube-system with the configuration for the kubelets in the cluster
[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
[bootstrap-token] configured RBAC rules to allow Node Bootstrap tokens to get nodes
[bootstrap-token] configured RBAC rules to allow Node Bootstrap tokens to post CSRs in order for nodes to get long term certificate credentials
[bootstrap-token] configured RBAC rules to allow the csrapprover controller automatically approve CSRs from a Node Bootstrap Token
[bootstrap-token] configured RBAC rules to allow certificate rotation for all node client certificates in the cluster
[addons] Applied essential addon: CoreDNS
[addons] Applied essential addon: kube-proxy

[upgrade/successful] SUCCESS! Your cluster was upgraded to "v1.21.1". Enjoy!

[upgrade/kubelet] Now that your control plane is upgraded, please proceed with upgrading your kubelets if you haven't already done so.
```

如果不想升级某个组建,可以添加上 --etcd-upgrade=false

#### 取消维护模式

```bash
[root@umaster tmp]# kubectl uncordon umaster
node/umaster uncordoned

[root@umaster tmp]# kubectl get nodes
NAME      STATUS   ROLES                  AGE   VERSION
umaster   Ready    control-plane,master   53m   v1.20.1
unode1    Ready    <none>                 52m   v1.20.1
```

#### 升级master上的kubelet和kubectl

```bash
yum install -y kubelet-1.21.1-0 kubectl-1.21.1-0 --disableexcludes=kubernetes
```

#### 重启服务

```bash
systemctl daemon-reload
systemctl restart kubelet
```

#### 查看版本

```bash
[root@umaster tmp]# kubectl version --short
Client Version: v1.21.1
Server Version: v1.21.1
```



### 升级worker

#### 升级kubeadm

```bash
yum -y install kubeadm-1.21.1-0 --disableexcludes=kubernetes
```

#### 置为维护模式-master操作

```bash
[root@umaster tmp]# kubectl drain unode1 --ignore-daemonsets
node/unode1 cordoned
WARNING: ignoring DaemonSet-managed Pods: kube-system/calico-node-wvf6l, kube-system/kube-proxy-2c88l
evicting pod kube-system/coredns-7f89b7bc75-vqghq
evicting pod kube-system/calico-kube-controllers-848c5d445f-vxmk6
evicting pod kube-system/coredns-545d6fc579-rp2sv
evicting pod kube-system/coredns-545d6fc579-v647b
pod/coredns-7f89b7bc75-vqghq evicted
pod/coredns-545d6fc579-v647b evicted
pod/coredns-545d6fc579-rp2sv evicted
pod/calico-kube-controllers-848c5d445f-vxmk6 evicted
node/unode1 evicted
```

查看状态

```bash
[root@umaster tmp]# kubectl get nodes
NAME      STATUS                     ROLES                  AGE   VERSION
umaster   Ready                      control-plane,master   72m   v1.21.1
unode1    Ready,SchedulingDisabled   <none>                 71m   v1.20.1
```

#### 升级

```bash
[root@unode1 tmp]# kubeadm upgrade node
[upgrade] Reading configuration from the cluster...
[upgrade] FYI: You can look at this config file with 'kubectl -n kube-system get cm kubeadm-config -o yaml'
[preflight] Running pre-flight checks
[preflight] Skipping prepull. Not a control plane node.
[upgrade] Skipping phase. Not a control plane node.
[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
[upgrade] The configuration for this node was successfully updated!
[upgrade] Now you should go ahead and upgrade the kubelet package using your package manager.
```

#### 更新kubelet 和 kubectl

```bash
yum install -y kubelet-1.21.1-0 kubectl-1.21.1-0 --disableexcludes=kubernetes
```

#### 取消维护

```bash
kubectl uncordon unode1
```

查看

```bash
kubectl get nodes
```


