---
title: "`Python中的 __len__、__getitem__、__setitem__、__delitem__、__contains__`"
tags:
  - Python
toc: true
---

Python 中特殊方法的一些理解笔记 

### \_\_len\_\_
返回集合长度

### \_\_getitem\_\_(self, item)
使用索引访问元素

### \_\_setitem\_\_(self, key, value) 
对索引赋值,使用 self[key] = value 

### \_\_delitem\_\_(self, key) 
删除索引值 del self[key]

### \_\_contains\_\_
实现in运算符，如果没有实现这个方法python也会调用__getitem__来使in运算符可用

### 可变集合和不可变集合
* 可变集合需要实现: __len__  __getitem__    __setitem__  __delitem__
* 不可变集合需要实现: __len__  __getitem__

### code
```python
class TemTest:

    def __init__(self,):
        self.x=[i for i in range(10)]

    def __len__(self):
        return len(self.x)

    def __getitem__(self, item):
        return self.x[item]

    def __setitem__(self, key, value):
        self.x[key]=value

    def __delitem__(self, key):
        del self.x[key]

    def __contains__(self, item):
        return item in self.x

    def __repr__(self):
        return '{}'.format(self.x)
```

```python
test=TemTest() #实例化
print(len(test)) #返回长度


print(test[0])   #打印下标0的值
print(test[:3])  #切片


test[3]=10       #将下标3的值替换为10
print(test)


del test[3]      #删除下标3的值
print(test)


print(1 in test)  #测试in运算符
print(3 in test) 
```

```python
10
0
[0, 1, 2]
[0, 1, 2, 10, 4, 5, 6, 7, 8, 9]
[0, 1, 2, 4, 5, 6, 7, 8, 9]
True
False
```
