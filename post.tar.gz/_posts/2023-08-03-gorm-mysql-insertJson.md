---
title: "使用Gorm将struct做为json字段插入mysql数据库"
tags:
  - Gorm
toc: true
---
 
Gorm使用


#### 代码
```golang
package main

import (
	"encoding/json"
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
)

type ContinentData struct {
	Name string `json:"name"`
	Code string `json:"code"`
}

type Fixaiwen struct {
	ID        uint            `gorm:"primaryKey;autoIncrement" json:"id"`
	Minip     uint            `json:"minip"`
	Maxip     uint            `json:"maxip"`
	Continent json.RawMessage `gorm:"type:json" json:"continent"`
}

func main() {
	dsn := "user:password@tcp(127.0.0.1:3306)/database_name?charset=utf8mb4&parseTime=True&loc=Local"
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic("failed to connect to database")
	}

	continentData := ContinentData{
		Name: "Asia",
		Code: "AS",
	}

	continentJSON, err := json.Marshal(continentData)
	if err != nil {
		panic("failed to convert struct to JSON")
	}

	fixaiwen := Fixaiwen{
		ID:        1,
		Minip:     16785408,
		Maxip:     16785659,
		Continent: continentJSON,
	}

	err = db.Create(&fixaiwen).Error
	if err != nil {
		panic("failed to insert data into database")
	}

	fmt.Println("Data inserted successfully!")
}

```
