---
title: "Pod 管理"
tags:
  - Kubernetes
toc: true
---

### 创建和删除pod

pod是k8s里最小调度单元

#### 下载镜像

```bash
docker pull hub.c.163.com/library/centos:7
docker pull nginx
docker pull nginx:1.7.9
docker pull nginx:1.9
docker pull busybox
docker pull alpine
docker pull perl
```

#### 查看

默认命名空间

```bash
[root@master tmp]# kubectl get pods
No resources found in default namespace.
```

指定命名空间

```bash
[root@master tmp]# kubectl get pods -n kube-system
NAME                                       READY   STATUS    RESTARTS   AGE
calico-kube-controllers-7cc8dd57d9-dhv5r   1/1     Running   0          161m
calico-node-54njj                          1/1     Running   2          4h43m
calico-node-559jn                          1/1     Running   1          4h43m
calico-node-w6rwp                          1/1     Running   1          4h27m
coredns-545d6fc579-j9f7q                   1/1     Running   1          5h
coredns-545d6fc579-t7st8                   1/1     Running   1          5h
etcd-master                                1/1     Running   1          5h
kube-apiserver-master                      1/1     Running   1          5h
kube-controller-manager-master             1/1     Running   1          5h
kube-proxy-j28gq                           1/1     Running   1          5h
kube-proxy-jgsxd                           1/1     Running   2          4h54m
kube-proxy-qrf8c                           1/1     Running   1          4h27m
kube-scheduler-master                      1/1     Running   1          5h
metrics-server-6b7f4dfdcb-tjfcj            1/1     Running   0          159m
```

所有命名空间

```bash
[root@master tmp]# kubectl get pods -A
NAMESPACE     NAME                                       READY   STATUS    RESTARTS   AGE
kube-system   calico-kube-controllers-7cc8dd57d9-dhv5r   1/1     Running   0          161m
kube-system   calico-node-54njj                          1/1     Running   2          4h44m
kube-system   calico-node-559jn                          1/1     Running   1          4h44m
kube-system   calico-node-w6rwp                          1/1     Running   1          4h28m
kube-system   coredns-545d6fc579-j9f7q                   1/1     Running   1          5h
kube-system   coredns-545d6fc579-t7st8                   1/1     Running   1          5h
kube-system   etcd-master                                1/1     Running   1          5h1m
kube-system   kube-apiserver-master                      1/1     Running   1          5h1m
kube-system   kube-controller-manager-master             1/1     Running   1          5h1m
kube-system   kube-proxy-j28gq                           1/1     Running   1          5h
kube-system   kube-proxy-jgsxd                           1/1     Running   2          4h54m
kube-system   kube-proxy-qrf8c                           1/1     Running   1          4h28m
kube-system   kube-scheduler-master                      1/1     Running   1          5h1m
kube-system   metrics-server-6b7f4dfdcb-tjfcj            1/1     Running   0          160m
```

#### 创建

kubectl run 名字 --image=镜像

指定pod的标签

kubectl run 名字 --image=镜像 --labels=标签=值   多个标签使用多个--labels

指定变量

kubectl run 名字 --image=镜像 --env="变量名=值"  多个变量使用多个--env

指定端口

kubectl run 名字 --image=镜像 --port=端口号

指定下载策略

kubectl run 名字 --image=镜像 --image-pull-policy=镜像现在策略

```bash
kubectl run pod1 --image=nginx
```

默认镜像下载策略为Always,即使本地有镜像也会去下载,建议加上 --image-pull-policy=IfNotPresent

验证

```bash
[root@master tmp]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
pod1   1/1     Running   0          74s
```

查看运行的节点

```bash
[root@master tmp]# kubectl get pods -o wide
NAME   READY   STATUS    RESTARTS   AGE    IP             NODE    NOMINATED NODE   READINESS GATES
pod1   1/1     Running   0          114s   10.244.104.3   node2   <none>           <none>
```

#### 删除

```bash
kubectl delete pod pod1 --force
```

--force 加快删除速度

验证

```bash
[root@master tmp]# kubectl get pods
No resources found in default namespace.
```

#### 生成yaml文件创建pod

kubectl run 名字 --image=镜像 --dry-run=client -o yaml > pod.yaml

```bash
mkdir pod;cd pod
kubectl run pod1 --image=nginx --dry-run=client -o yaml > pod.yaml
```

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: pod1
  name: pod1
spec:
  containers:
  - image: nginx
    imagePullPolicy: IfNotPresent  # 新增
    name: pod1
    resources: {}
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

解释

```yaml
apiVersion: v1    　　　　　　# 必选，版本号
kind: Pod         　　　　　　# 必选，Pod
metadata:         　　　　　　# 必选，元数据
  name: String    　　　　　　# 必选，Pod名称
  namespace: String    　　　 # 必选，Pod所属的命名空间
  labels:            　　　　 # 自定义标签，Map格式
    Key: Value    　　　　　　# 键值对
  annotations:    　　　　　　# 自定义注解
    Key: Value    　　　　　  # 键值对
spec:            　　　　　　 # 必选，Pod中容器的详细属性
  containers:        　　　　 # 必选，Pod中容器列表
  - name: String   　　　　   # 必选，容器名称
    image: String    　　　　 # 必选，容器的镜像地址和名称
    imagePullPolicy: {Always | Never | IfNotPresent}   
 　　　　                     # 获取镜像的策略，Always表示下载镜像，IfnotPresent 表示优先使用本地镜像，否则下载镜像，Never表示仅使用本地镜像。
    command: [String]         # 容器的启动命令列表(覆盖)，如不指定，使用打包镜像时的启动命令。
    args: [String]            # 容器的启动命令参数列表
    workingDir: String        # 容器的工作目录
    volumeMounts:             # 挂载到容器内部的存储卷配置
    - name: String            # 引用Pod定义的共享存储卷的名，需用Pod.spec.volumes[]部分定义的卷名
      mountPath: String       # 存储卷在容器内Mount的绝对路径，应少于512字符
      readOnly: boolean       # 是否为只读模式
  ports:                      # 容器需要暴露的端口库号列表
  - name: String              # 端口号名称
    containerPort: Int        # 容器需要监听的端口号
    hostPort: Int             # 可选，容器所在主机需要监听的端口号，默认与Container相同
  env:                        # 容器运行前需设置的环境变量列表
  - name: String              # 环境变量名称
    value: String             # 环境变量的值
  resources:                  # 资源限制和请求的设置
    limits:                   # 资源限制的设置
      cpu: String             # Cpu的限制，单位为Core数，将用于docker run --cpu-shares参数，如果整数后跟m，表示占用权重，1Core=1000m
      memory: String          # 内存限制，单位可以为Mib/Gib，将用于docker run --memory参数
    requests:                 # 资源请求的设置
      cpu: string             # CPU请求，容器启动的初始可用数量
      memory: string          # 内存请求，容器启动的初始可用数量
  livenessProbe:   
 　　　　           # 对Pod内容器健康检查设置，当探测无响应几次后将自动重启该容器，检查方法有exec、httpGet和tcpSocket，对一个容器只需设置其中一种方法即可。
    exec:                     # 对Pod容器内检查方式设置为exec方式
      command: [String]       # exec方式需要制定的命令或脚本
    httpGet:                  # 对Pod容器内检查方式设置为HttpGet方式，需要指定path、port
      path: String            # 网址URL路径（去除对应的域名或IP地址的部分）
      port: Int               # 对应端口
      host: String            # 域名或IP地址
      schema: String          # 对应的检测协议，如http
      HttpHeaders:            # 指定报文头部信息
      - name: String
        value: String
    tcpSocket:                # 对Pod容器内检查方式设置为tcpSocket方式
      port: Int
    initialDelaySeconds: Int  # 容器启动完成后首次探测的时间，单位为秒
    timeoutSeconds: Int       # 对容器健康检查探测等待响应的超时时间，单位为秒，默认为1秒
    periodSeconds: Int        # 对容器监控检查的定期探测时间设置，单位为秒，默认10秒一次
    successThreshold: Int     # 探测几次成功后认为成功
    failureThreshold: Int     # 探测几次失败后认为失败
    securityContext:
      privileged: false
  restartPolicy: {Always | Never | OnFailure} 
 　　　　           # Pod的重启策略，Always表示一旦不管以何种方式终止运行，kubelet都将重启，OnFailure表示只有Pod以非0退出码才重启，Nerver表示不再重启该Pod
  nodeSelector:              # 设置NodeSelector表示将该Pod调度到包含这个label的node上，以Key:Value的格式指定
    Key: Value               # 调度到指定的标签Node上
  imagePullSecrets:          # Pull镜像时使用的secret名称，以Key:SecretKey格式指定
  - name: String
  hostNetwork: false         # 是否使用主机网络模式，默认为false，如果设置为true，表示使用宿主机网络
  volumes:                   # 在该Pod上定义共享存储卷列表
  - name: String             # 共享存储卷名称（Volumes类型有多种）
    emptyDir: { }            # 类型为emptyDir的存储卷，与Pod同生命周期的一个临时目录，为空值
    hostPath: String         # 类型为hostPath的存储卷，表示挂载Pod所在宿主机的目录
    path: String             # Pod所在宿主机的目录，将被用于同期中Mount的目录
  secret:                    # 类型为Secret的存储卷，挂载集群与定义的Secret对象到容器内部
    secretname: String
    items:                   # 当仅需挂载一个Secret对象中的指定Key时使用
    - key: String
     path: String
  configMap:                 # 类型为ConfigMap的存储卷，挂载预定义的ConfigMap对象到容器内部
    name: String
    items:                   # 当仅需挂载一个ConfigMap对象中的指定Key时使用
    - key: String
      path: String
```

参考: https://www.cnblogs.com/kevingrace/p/11309409.html

#### 使用yaml文件创建

```bash
[root@master pod]# kubectl apply -f pod.yaml
pod/pod1 created
```

验证

```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
pod1   1/1     Running   0          24s
```

#### 创建pod时指定pod运行其它进程

kubectl run 名字 --image=镜像 --dry-run=client -o yaml -- "命令" >pod.yaml

kubectl run 名字 --image=镜像 --dry-run=client -o yaml -- sh -c "命令" >pod.yaml

--两边要有空格

--dry-run=client -o yaml 下载--前面，命令卸载-- 后面

pod中执行echo aa,休眠1000秒

```bash
kubectl run pod2 --image=nginx --image-pull-policy=IfNotPresent --dry-run=client -o yaml -- sh -c "echo aa; sleep 1000"> pod2.yaml
```

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: pod2
  name: pod2
spec:
  containers:
  - args:
    - sh
    - -c
    - echo aa; sleep 1000
    image: nginx
    imagePullPolicy: IfNotPresent
    name: pod2
    resources: {}
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

创建

```bash
[root@master pod]# kubectl apply -f pod2.yaml
pod/pod2 created
```

删除

```bash
kubectl delete -f pod2.yaml
```

#### pod创建多容器

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: pod2
  name: pod2
spec:
  containers:
  - command: ["sh","-c","echo aa; sleep 1000"]
    image: nginx
    imagePullPolicy: IfNotPresent
    name: c1
    resources: {}
  - name: c2
    image: nginx
    imagePullPolicy: IfNotPresent
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

查看

```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
pod1   1/1     Running   0          9m46s
pod2   2/2     Running   0          13s
```

查看标签

```bash
[root@master pod]# kubectl get pods --show-labels
NAME   READY   STATUS    RESTARTS   AGE   LABELS
pod1   1/1     Running   0          10m   run=pod1
pod2   2/2     Running   0          40s   run=pod2
```

指定标签查看

```bash
[root@master pod]# kubectl get pods -l run=pod2
NAME   READY   STATUS    RESTARTS   AGE
pod2   2/2     Running   0          67s
```

### 在pod里执行命令

kubectl exec pod 名字 -- 命令

```bash
[root@master ~]# kubectl exec pod1 -- ls /usr/share/nginx/html
50x.html
index.html
```

拷贝文件

kubectl cp /path1/fil1 pod:/path2/ 把物理机文件/path1/file1拷贝到pod的path2里

kubectl cp pod:/path1/fil1 /path2/ 把pod的文件path2里 拷贝到物理机/path1/file1

```bash
[root@master ~]# kubectl cp /etc/hosts pod1:/usr/share/nginx/html
[root@master ~]# kubectl exec pod1 -- ls /usr/share/nginx/html
50x.html
hosts
index.html
```

```bash
[root@master ~]# kubectl cp pod1:/usr/share/nginx/html/ /tmp
tar: Removing leading `/' from member names
[root@master ~]# ls /tmp/
50x.html 
```

进入pod获取bash

```bash
[root@master ~]# kubectl exec -it pod1 -- bash
root@pod1:/# exit
exit
```

多个pod默认进入第一个

```bash
[root@master ~]# kubectl exec -it pod2 -- bash
Defaulted container "c1" out of: c1, c2
root@pod2:/# exit
exit
[root@master ~]# 
```

使用 -c 指定容器名

```bash
[root@master ~]# kubectl exec -it pod2 -c c2 -- bash 
root@pod2:/# exit
exit
```

查看pod属性

```bash
[root@master ~]# kubectl describe pod pod2
Name:         pod2
Namespace:    default
Priority:     0
Node:         node1/192.168.122.202
Start Time:   Mon, 11 Jul 2022 01:35:21 +0800
Labels:       run=pod2
Annotations:  cni.projectcalico.org/containerID: 81dcb5949057c2d0a998f5119020dd76ee12dc2d9faa79e30c00d93709d21e5e
              cni.projectcalico.org/podIP: 10.244.166.134/32
              cni.projectcalico.org/podIPs: 10.244.166.134/32
Status:       Running
IP:           10.244.166.134
IPs:
  IP:  10.244.166.134
Containers:
  c1:
    Container ID:  docker://0449ea9f0ea0921a06b1f11e8ac89414c11db12e28aee93882c5d574906684bb
    Image:         nginx
    Image ID:      docker-pullable://nginx@sha256:0d17b565c37bcbd895e9d92315a05c1c3c9a29f762b011a10c54a66cd53c9b31
    Port:          <none>
    Host Port:     <none>
    Command:
      sh
      -c
      echo aa; sleep 1000
    State:          Running
      Started:      Mon, 11 Jul 2022 23:55:07 +0800
    Last State:     Terminated
      Reason:       Error
      Exit Code:    137
      Started:      Mon, 11 Jul 2022 01:35:22 +0800
      Finished:     Mon, 11 Jul 2022 01:37:13 +0800
    Ready:          True
    Restart Count:  1
    Environment:    <none>
    Mounts:
      /var/run/secrets/kubernetes.io/serviceaccount from kube-api-access-789mj (ro)
  c2:
    Container ID:   docker://39c132c6c5a53c4b1667b44c303e3d25d7280de889bd7bf2509dcde1d2b44623
    Image:          nginx
    Image ID:       docker-pullable://nginx@sha256:0d17b565c37bcbd895e9d92315a05c1c3c9a29f762b011a10c54a66cd53c9b31
    Port:           <none>
    Host Port:      <none>
    State:          Running
      Started:      Mon, 11 Jul 2022 23:55:07 +0800
    Last State:     Terminated
      Reason:       Completed
      Exit Code:    0
      Started:      Mon, 11 Jul 2022 01:35:23 +0800
      Finished:     Mon, 11 Jul 2022 01:37:03 +0800
    Ready:          True
    Restart Count:  1
    Environment:    <none>
    Mounts:
      /var/run/secrets/kubernetes.io/serviceaccount from kube-api-access-789mj (ro)
Conditions:
  Type              Status
  Initialized       True 
  Ready             True 
  ContainersReady   True 
  PodScheduled      True 
Volumes:
  kube-api-access-789mj:
    Type:                    Projected (a volume that contains injected data from multiple sources)
    TokenExpirationSeconds:  3607
    ConfigMapName:           kube-root-ca.crt
    ConfigMapOptional:       <nil>
    DownwardAPI:             true
QoS Class:                   BestEffort
Node-Selectors:              <none>
Tolerations:                 node.kubernetes.io/not-ready:NoExecute op=Exists for 300s
                             node.kubernetes.io/unreachable:NoExecute op=Exists for 300s
Events:
  Type    Reason          Age                From               Message
  ----    ------          ----               ----               -------
  Normal  Scheduled       22h                default-scheduler  Successfully assigned default/pod2 to node1
  Normal  Pulled          22h                kubelet            Container image "nginx" already present on machine
  Normal  Created         22h                kubelet            Created container c1
  Normal  Started         22h                kubelet            Started container c1
  Normal  Pulled          22h                kubelet            Container image "nginx" already present on machine
  Normal  Created         22h                kubelet            Created container c2
  Normal  Started         22h                kubelet            Started container c2
  Normal  SandboxChanged  13m (x2 over 13m)  kubelet            Pod sandbox changed, it will be killed and re-created.
  Normal  Pulled          13m                kubelet            Container image "nginx" already present on machine
  Normal  Created         13m                kubelet            Created container c1
  Normal  Started         13m                kubelet            Started container c1
  Normal  Pulled          13m                kubelet            Container image "nginx" already present on machine
  Normal  Created         13m                kubelet            Created container c2
  Normal  Started         13m                kubelet            Started container c2
```

查看pod输出

```bash
[root@master ~]# kubectl logs pod1
/docker-entrypoint.sh: /docker-entrypoint.d/ is not empty, will attempt to perform configuration
/docker-entrypoint.sh: Looking for shell scripts in /docker-entrypoint.d/
/docker-entrypoint.sh: Launching /docker-entrypoint.d/10-listen-on-ipv6-by-default.sh
10-listen-on-ipv6-by-default.sh: info: Getting the checksum of /etc/nginx/conf.d/default.conf
10-listen-on-ipv6-by-default.sh: info: Enabled listen on IPv6 in /etc/nginx/conf.d/default.conf
/docker-entrypoint.sh: Launching /docker-entrypoint.d/20-envsubst-on-templates.sh
/docker-entrypoint.sh: Launching /docker-entrypoint.d/30-tune-worker-processes.sh
/docker-entrypoint.sh: Configuration complete; ready for start up
2022/07/11 15:55:05 [notice] 1#1: using the "epoll" event method
2022/07/11 15:55:05 [notice] 1#1: nginx/1.21.5
2022/07/11 15:55:05 [notice] 1#1: built by gcc 10.2.1 20210110 (Debian 10.2.1-6) 
2022/07/11 15:55:05 [notice] 1#1: OS: Linux 3.10.0-862.el7.x86_64
2022/07/11 15:55:05 [notice] 1#1: getrlimit(RLIMIT_NOFILE): 65536:65536
2022/07/11 15:55:05 [notice] 1#1: start worker processes
2022/07/11 15:55:05 [notice] 1#1: start worker process 31
2022/07/11 15:55:05 [notice] 1#1: start worker process 32
```

```bash
[root@master ~]# kubectl logs pod2
error: a container name must be specified for pod pod2, choose one of: [c1 c2]
[root@master ~]# kubectl logs pod2 -c c1
aa
```

删除pod

```bash
[root@master ~]# kubectl delete pod pod1
pod "pod1" deleted
```

```bash
[root@master pod]# kubectl delete -f pod2.yaml
pod "pod2" deleted
```

#### 生命周期

增加--force会提高删除pod的速度, 不加慢的原因是 pod的删除有个延期删除,默认是30s,可以通过 terminationGracePeriodSeconds来制定

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: pod2
  name: pod2
spec:
  terminationGracePeriodSeconds: 15
  containers:
  - command: ["sh","-c","echo aa; sleep 1000"]
    image: nginx
    imagePullPolicy: IfNotPresent
    name: c1
    resources: {}
  - name: c2
    image: nginx
    imagePullPolicy: IfNotPresent
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

此参数对nginx不起作用

如果pod被强制删除,客户端访问报错，可以使用钩子解决

1、postStart: 创建pod的时候,会随着pod里的主进程同时运行,没有先后顺序

2、preStop: 删除pod的时候,要先运行preStop里的程序,之后再关闭pod.

preStop也必须在terminationGracePeriodSeconds时间内完成.否则会被强制删除

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: pod2
  name: pod2
spec:
  terminationGracePeriodSeconds: 600
  containers:
  - command: ["sh","-c","echo aa; sleep 1000"]
    image: nginx
    imagePullPolicy: IfNotPresent
    name: c1
    resources: {}
    lifecycle:
      preStop:
        exec:
          command: ["/bin/bash","-c","/usr/sbin/nginx -s quit"]
  - name: c2
    image: nginx
    imagePullPolicy: IfNotPresent
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

### 创建初始化pod

#### 初始化容器,在正式运行容器前执行准备工作

```bash
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: pod3
  name: pod3
spec:
  containers:
  - image: nginx
    name: c1
    imagePullPolicy: IfNotPresent
    resources: {}
  initContainers:
  - image: docker.io/alpine:latest
    name: xx
    imagePullPolicy: IfNotPresent
    command: ["/bin/sh","-c","/sbin/sysctl -w vm.swappiness=10"]
    securityContext:
      privileged: true
    resources: {}
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

里面有两个容器,一个初始化容器xx和一个普通容器c1.xx运行起来，修改pod所在物理机的内核参数

测试

```bash
[root@node1 ~]# cat /proc/sys/vm/swappiness 
30
```

```bash
[root@node2 ~]# cat /proc/sys/vm/swappiness
30
```

```bash
[root@master pod]# kubectl get pods -o wide
NAME   READY   STATUS    RESTARTS   AGE   IP             NODE    NOMINATED NODE   READINESS GATES
pod3   1/1     Running   0          22s   10.244.104.7   node2   <none>           <none>
```

```bash
[root@node2 ~]# cat /proc/sys/vm/swappiness
10
```

通过初始化容器和普通容器共享数据

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    app: myapp
  name: myapp
spec:
  volumes:
  - name: workdir # 定义一个workdir的存储卷
    emptyDir: {}
  containers:
  - image: nginx
    name: podx
    imagePullPolicy: IfNotPresent
    volumeMounts:
    - name: workdir
      mountPath: "/xx" #把workdir挂载到容器的/xx目录
    resources: {}
  initContainers:
  - image: busybox
    name: poda
    imagePullPolicy: IfNotPresent
    command: ["/bin/sh","-c","touch /work-dir/aa.txt"]
    volumeMounts:
    - name: workdir
      mountPath: "/work-dir" # 把workdir挂载到容器的/work-dir目录
    resources: {}
  dnsPolicy: ClusterFirst
  restartPolicy: Always
status: {}
```

pod名称为myapp, 在pod中创建一个名字为workdir的存储卷. 

poda是初始化容器,把存储卷workdir挂载到本容器的/work-dir目录。然后在挂载点/work-dir里创建aa.txt

普通容器podx会把存储卷workdir挂载到本容器的/xx里,访问/xx的时候实际上访问的就是存储卷workdir.

```bash
[root@master pod]# kubectl get pods -o wide
NAME    READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
myapp   1/1     Running   0          12s   10.244.166.135   node1   <none>           <none>
```

```bash
[root@master pod]# kubectl exec myapp -c podx -- ls /xx
aa.txt
```

删除pod

```bash
[root@master pod]# kubectl delete -f pod3.yaml
pod "pod3" deleted
[root@master pod]# kubectl delete -f pod4.yaml
pod "myapp" deleted
```

### 创建静态Pod

#### 在node上创建

静态pod 不是由master创建启动,在node上只要启动kubelet，就会自动创建pod

```bash
[root@node1 ~]# systemctl status kubelet -l
● kubelet.service - kubelet: The Kubernetes Node Agent
   Loaded: loaded (/usr/lib/systemd/system/kubelet.service; enabled; vendor preset: disabled)
  Drop-In: /usr/lib/systemd/system/kubelet.service.d
           └─10-kubeadm.conf
```

配置文件地址

```
/usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf
```

编辑文件,追加--pod-manifest-path=/etc/kubernetes/kubelet.d

```bash
# Note: This dropin only works with kubeadm and kubelet v1.11+
[Service]
Environment="KUBELET_KUBECONFIG_ARGS=--bootstrap-kubeconfig=/etc/kubernetes/bootstrap-kubelet.conf --kubeconfig=/etc/kubernetes/kubelet.conf --pod-manifest-path=/etc/kubernetes/kubelet.d"
Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"
# This is a file that "kubeadm init" and "kubeadm join" generates at runtime, populating the KUBELET_KUBEADM_ARGS variable dynamically
EnvironmentFile=-/var/lib/kubelet/kubeadm-flags.env
# This is a file that the user can use for overrides of the kubelet args as a last resort. Preferably, the user should use
# the .NodeRegistration.KubeletExtraArgs object in the configuration files instead. KUBELET_EXTRA_ARGS should be sourced from this file.
EnvironmentFile=-/etc/sysconfig/kubelet
ExecStart=
ExecStart=/usr/bin/kubelet $KUBELET_KUBECONFIG_ARGS $KUBELET_CONFIG_ARGS $KUBELET_KUBEADM_ARGS $KUBELET_EXTRA_ARGS

```

重启服务

```bash
[root@node1 ~]# systemctl daemon-reload
[root@node1 ~]# systemctl restart kubelet
[root@node1 pod]# mkdir -p /etc/kubernetes/kubelet.d
```

在node1上创建pod

vim /etc/kubernetes/kubelet.d/pod.yaml

```yaml
apiVersion: v1
kind: Pod
metadata:
  creationTimestamp: null
  labels:
    run: myrole
  namespace: default
  name: static-web
spec:
  containers:
  - image: nginx
    imagePullPolicy: IfNotPresent
    name: web   
```

在master上查看

```bash
[root@master pod]# kubectl get pods 
NAME               READY   STATUS    RESTARTS   AGE
static-web-node1   1/1     Running   1          57s
```

在node1上删除

```bash
[root@node1 pod]# rm -rf /etc/kubernetes/kubelet.d/pod.yaml 
```

在master上查看

```bash
[root@master pod]# kubectl get pods 
No resources found in default namespace.
```

#### 在master上创建

可以在master上看到 Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"

```bash
[root@master pod]# cat /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf
# Note: This dropin only works with kubeadm and kubelet v1.11+
[Service]
Environment="KUBELET_KUBECONFIG_ARGS=--bootstrap-kubeconfig=/etc/kubernetes/bootstrap-kubelet.conf --kubeconfig=/etc/kubernetes/kubelet.conf"
Environment="KUBELET_CONFIG_ARGS=--config=/var/lib/kubelet/config.yaml"
# This is a file that "kubeadm init" and "kubeadm join" generates at runtime, populating the KUBELET_KUBEADM_ARGS variable dynamically
EnvironmentFile=-/var/lib/kubelet/kubeadm-flags.env
# This is a file that the user can use for overrides of the kubelet args as a last resort. Preferably, the user should use
# the .NodeRegistration.KubeletExtraArgs object in the configuration files instead. KUBELET_EXTRA_ARGS should be sourced from this file.
EnvironmentFile=-/etc/sysconfig/kubelet
ExecStart=
ExecStart=/usr/bin/kubelet $KUBELET_KUBECONFIG_ARGS $KUBELET_CONFIG_ARGS $KUBELET_KUBEADM_ARGS $KUBELET_EXTRA_ARGS
```

```bash
[root@master pod]# grep static /var/lib/kubelet/config.yaml
staticPodPath: /etc/kubernetes/manifests
```

### 指定pod在指定的节点上运行

给节点添加标签,指定pod在特定的节点上运行

标签格式: key = value

#### 查看节点的标签

```bash
[root@master ~]# kubectl get nodes --show-labels
NAME     STATUS   ROLES                  AGE    VERSION   LABELS
master   Ready    control-plane,master   4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=master,kubernetes.io/os=linux,node-role.kubernetes.io/control-plane=,node-role.kubernetes.io/master=,node.kubernetes.io/exclude-from-external-load-balancers=
node1    Ready    <none>                 4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node1,kubernetes.io/os=linux
node2    Ready    <none>                 4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node2,kubernetes.io/os=linux
```

#### 查看特定节点的标签

```bash
[root@master ~]# kubectl get nodes node1 --show-labels
NAME    STATUS   ROLES    AGE    VERSION   LABELS
node1   Ready    <none>   4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node1,kubernetes.io/os=linux
```

#### 给节点设置标签

kubectl label node 节点名 key=value

```bash
[root@master ~]# kubectl label node node1 mytag=node1
node/node1 labeled
```

```bash
[root@master ~]# kubectl get nodes node1 --show-labels
NAME    STATUS   ROLES    AGE    VERSION   LABELS
node1   Ready    <none>   4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node1,kubernetes.io/os=linux,mytag=node1
```

#### 取消某个节点的标签

kubectl label node 节点名 key-

```bash
[root@master ~]# kubectl label node node1 mytag-
node/node1 labeled
[root@master ~]# kubectl get nodes node1 --show-labels
NAME    STATUS   ROLES    AGE    VERSION   LABELS
node1   Ready    <none>   4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node1,kubernetes.io/os=linux
```

#### 给所有节点设置标签

kubectl label node --all key=value

给nod1设置ROLES为NODE1,node2设置ROLES为NODE2

```bash
[root@master ~]# kubectl label nodes node1 node-role.kubernetes.io/node1=""
node/node1 labeled
[root@master ~]# kubectl get nodes node1 --show-labels
NAME    STATUS   ROLES   AGE    VERSION   LABELS
node1   Ready    node1   4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node1,kubernetes.io/os=linux,node-role.kubernetes.io/node1=
```

```bash
[root@master ~]# kubectl label nodes node2 node-role.kubernetes.io/node2=""
node/node2 labeled
[root@master ~]# kubectl get nodes node2 --show-labels
NAME    STATUS   ROLES   AGE    VERSION   LABELS
node2   Ready    node2   4d2h   v1.21.1   beta.kubernetes.io/arch=amd64,beta.kubernetes.io/os=linux,kubernetes.io/arch=amd64,kubernetes.io/hostname=node2,kubernetes.io/os=linux,node-role.kubernetes.io/node2=
```

```bash
[root@master ~]# kubectl get nodes
NAME     STATUS   ROLES                  AGE    VERSION
master   Ready    control-plane,master   4d2h   v1.21.1
node1    Ready    node1                  4d2h   v1.21.1
node2    Ready    node2                  4d2h   v1.21.1
```

#### 创建指定节点运行的pod

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  name: web1
  labels:
    role:  myrole
spec:
  nodeSelector:
    mytag:  node1
  containers:
    - name:  web
      image:  nginx
      imagePullPolicy:  IfNotPresent
```

```bash
[root@master pod]# kubectl apply -f podlabel.yaml
pod/web1 created
```

web1只会运行在含有标签为mytag=node1的节点上

```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
web1   1/1     Running   0          9s
```

#### 创建在特定节点上运行的pod

```yaml
[root@master pod]# cat podlabel.yaml 
apiVersion:  v1
kind:  Pod
metadata:
  name: web1
  labels:
    role:  myrole
spec:
  nodeSelector:
    mytag:  node1
  containers:
    - name:  web
      image:  nginx
      imagePullPolicy:  IfNotPresent
```

```bash
[root@master pod]# kubectl apply -f podlabel.yaml
pod/web1 created
```

```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
web1   1/1     Running   0          9s
```

```bash
[root@master pod]# kubectl get pods -o wide
NAME   READY   STATUS    RESTARTS   AGE     IP               NODE    NOMINATED NODE   READINESS GATES
web1   1/1     Running   0          8m12s   10.244.166.139   node1   <none>           <none>
```

#### Annotations设置

不管node还是pod,包括后面讲述的其他对象(比如deployment),都还有一个属性Annotations。这个属性可以理解为注释

```bash
[root@master pod]# kubectl describe nodes node1
Name:               node1
Roles:              node1
Labels:             beta.kubernetes.io/arch=amd64
                    beta.kubernetes.io/os=linux
                    kubernetes.io/arch=amd64
                    kubernetes.io/hostname=node1
                    kubernetes.io/os=linux
                    mytag=node1
                    node-role.kubernetes.io/node1=
Annotations:        kubeadm.alpha.kubernetes.io/cri-socket: /var/run/dockershim.sock
                    node.alpha.kubernetes.io/ttl: 0
                    projectcalico.org/IPv4Address: 192.168.122.202/24
                    projectcalico.org/IPv4IPIPTunnelAddr: 10.244.166.128
                    volumes.kubernetes.io/controller-managed-attach-detach: true
```

设置Annotations

```bash
[root@master pod]# kubectl annotate nodes node1 name=yinyaliang
node/node1 annotated
```

```bash
[root@master pod]# kubectl describe node node1
Name:               node1
Roles:              node1
Labels:             beta.kubernetes.io/arch=amd64
                    beta.kubernetes.io/os=linux
                    kubernetes.io/arch=amd64
                    kubernetes.io/hostname=node1
                    kubernetes.io/os=linux
                    mytag=node1
                    node-role.kubernetes.io/node1=
Annotations:        kubeadm.alpha.kubernetes.io/cri-socket: /var/run/dockershim.sock
                    name: yinyaliang
                    node.alpha.kubernetes.io/ttl: 0
                    projectcalico.org/IPv4Address: 192.168.122.202/24
                    projectcalico.org/IPv4IPIPTunnelAddr: 10.244.166.128
                    volumes.kubernetes.io/controller-managed-attach-detach: true
```

### 通过cordon及drain把节点设置为维护模式

#### cordon

如果某个节点不可用,可以对节点实施cordon或drain操作.这样节点会标记为SchedulingDisabled.新建的pod就会不再分配到这个节点

```bash
[root@master pod]# kubectl get nodes
NAME     STATUS   ROLES                  AGE    VERSION
master   Ready    control-plane,master   4d3h   v1.21.1
node1    Ready    node1                  4d2h   v1.21.1
node2    Ready    node2                  4d3h   v1.21.1
```

都为ready，说明节点都可以调度

```bash
[root@master pod]# kubectl create deployment nginx --image=nginx --dry-run=client -o yaml>d1.yaml
```

修改d1.yaml的replicas为3

```bash
[root@master pod]# kubectl apply -f d1.yaml 
deployment.apps/nginx created
```

```bash
[root@master pod]# kubectl get pods -o wide
NAME                     READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
nginx-6799fc88d8-9qrsp   1/1     Running   0          49s   10.244.104.10    node2   <none>           <none>
nginx-6799fc88d8-nvch7   1/1     Running   0          49s   10.244.104.9     node2   <none>           <none>
nginx-6799fc88d8-rljcr   1/1     Running   0          49s   10.244.104.8     node2   <none>           <none>
web1                     1/1     Running   0          15m   10.244.166.139   node1   <none>           <none>
```

三个都被分配到node2上,把node2标记不可用

```bash
[root@master pod]# kubectl cordon node2
node/node2 cordoned
```

再次查看

```bash
[root@master pod]# kubectl get nodes
NAME     STATUS                     ROLES                  AGE    VERSION
master   Ready                      control-plane,master   4d3h   v1.21.1
node1    Ready                      node1                  4d2h   v1.21.1
node2    Ready,SchedulingDisabled   node2                  4d3h   v1.21.1
```

扩展deployment为6个副本

```bash
[root@master pod]# kubectl apply -f d1.yaml
deployment.apps/nginx configured
```

或者

```bash
kubectl scale deployment nginx --replicas=6
```

可以看到新建节点都在node1上

```bash
[root@master pod]# kubectl get pods -o wide
NAME                     READY   STATUS    RESTARTS   AGE     IP               NODE    NOMINATED NODE   READINESS GATES
nginx-6799fc88d8-6cxhg   1/1     Running   0          56s     10.244.166.142   node1   <none>           <none>
nginx-6799fc88d8-9qrsp   1/1     Running   0          3m53s   10.244.104.10    node2   <none>           <none>
nginx-6799fc88d8-hfxch   1/1     Running   0          56s     10.244.166.140   node1   <none>           <none>
nginx-6799fc88d8-nvch7   1/1     Running   0          3m53s   10.244.104.9     node2   <none>           <none>
nginx-6799fc88d8-rljcr   1/1     Running   0          3m53s   10.244.104.8     node2   <none>           <none>
nginx-6799fc88d8-skhmd   1/1     Running   0          56s     10.244.166.141   node1   <none>           <none>
web1                     1/1     Running   0          18m     10.244.166.139   node1   <none>           <none>
```

从node2上删除一个节点测试

```bash
[root@master pod]# kubectl delete pod nginx-6799fc88d8-9qrsp
pod "nginx-6799fc88d8-9qrsp" deleted
```

```bash
[root@master pod]# kubectl get pods -o wide
NAME                     READY   STATUS    RESTARTS   AGE     IP               NODE    NOMINATED NODE   READINESS GATES
nginx-6799fc88d8-6cxhg   1/1     Running   0          2m21s   10.244.166.142   node1   <none>           <none>
nginx-6799fc88d8-hfxch   1/1     Running   0          2m21s   10.244.166.140   node1   <none>           <none>
nginx-6799fc88d8-kkwps   1/1     Running   0          22s     10.244.166.143   node1   <none>           <none>
nginx-6799fc88d8-nvch7   1/1     Running   0          5m18s   10.244.104.9     node2   <none>           <none>
nginx-6799fc88d8-rljcr   1/1     Running   0          5m18s   10.244.104.8     node2   <none>           <none>
nginx-6799fc88d8-skhmd   1/1     Running   0          2m21s   10.244.166.141   node1   <none>           <none>
web1                     1/1     Running   0          20m     10.244.166.139   node1   <none>           <none>
```

新节点也在node1上了

#### drain 

对节点的drain操作和cordon是一样的,但是drain比crodon多一个驱逐的效果 evicted,我们把nginx的deployment的副本设置为4

```bash
[root@master pod]# kubectl scale deploy nginx --replicas=4
deployment.apps/nginx scaled
```

```bash
[root@master pod]# kubectl get pods -o wide
NAME                     READY   STATUS    RESTARTS   AGE     IP               NODE    NOMINATED NODE   READINESS GATES
nginx-6799fc88d8-hfxch   1/1     Running   0          4m45s   10.244.166.140   node1   <none>           <none>
nginx-6799fc88d8-nvch7   1/1     Running   0          7m42s   10.244.104.9     node2   <none>           <none>
nginx-6799fc88d8-rljcr   1/1     Running   0          7m42s   10.244.104.8     node2   <none>           <none>
nginx-6799fc88d8-skhmd   1/1     Running   0          4m45s   10.244.166.141   node1   <none>           <none>
web1                     1/1     Running   0          22m     10.244.166.139   node1   <none>           <none>
```

对node2进行drain操作

```bash
[root@master pod]# kubectl drain node2
node/node2 already cordoned
error: unable to drain node "node2", aborting command...

There are pending nodes to be drained:
 node2
error: cannot delete DaemonSet-managed Pods (use --ignore-daemonsets to ignore): kube-system/calico-node-54njj, kube-system/kube-proxy-jgsxd
```

报错可以使用--ignore-daemonsets

取消node2的cordon操作

```bash
[root@master pod]# kubectl uncordon node2
node/node2 uncordoned
```

在对node2做drain操作

```bash
[root@master pod]# kubectl drain node2 --ignore-daemonsets --delete-local-data
Flag --delete-local-data has been deprecated, This option is deprecated and will be deleted. Use --delete-emptydir-data.
node/node2 cordoned
WARNING: ignoring DaemonSet-managed Pods: kube-system/calico-node-54njj, kube-system/kube-proxy-jgsxd
evicting pod default/nginx-6799fc88d8-rljcr
evicting pod default/nginx-6799fc88d8-nvch7
pod/nginx-6799fc88d8-nvch7 evicted
pod/nginx-6799fc88d8-rljcr evicted
node/node2 evicted
```

```bash
[root@master pod]# kubectl get pods -o wide
NAME                     READY   STATUS    RESTARTS   AGE     IP               NODE    NOMINATED NODE   READINESS GATES
nginx-6799fc88d8-2l9lt   1/1     Running   0          2m50s   10.244.166.144   node1   <none>           <none>
nginx-6799fc88d8-bhl7w   1/1     Running   0          2m50s   10.244.166.145   node1   <none>           <none>
nginx-6799fc88d8-hfxch   1/1     Running   0          11m     10.244.166.140   node1   <none>           <none>
nginx-6799fc88d8-skhmd   1/1     Running   0          11m     10.244.166.141   node1   <none>           <none>
web1                     1/1     Running   0          28m     10.244.166.139   node1   <none>           <none>
```

取消drain操作

```bash
[root@master pod]# kubectl uncordon node2
node/node2 uncordoned
```

### 配置并查看节点的污点

给节点设置及删除taint,设置operator的值为Equal,以及设置operator的值为Exists

如果我们给某节点设置了taint的话,只有那些设置了tolerations(容忍污点)的pod才能运行到此节点上,所以之前的调度master不会运行pod

```bash
[root@master pod]# kubectl describe nodes node1 | grep -E '(Roles|Taints)'
Roles:              node1
Taints:             <none>
[root@master pod]# kubectl describe nodes master | grep -E '(Roles|Taints)'
Roles:              control-plane,master
Taints:             node-role.kubernetes.io/master:NoSchedule
```

#### 给节点设置污点

```bash
kubectl taint nodes 节点名 key=value:effect   这里effect一般是NoSchedule
```

所有节点

```bash
kubectl taint node --all key=value:NoSchedule
```

这里的value可以不写

```bash
kubectl taint nodes 节点名 key=:NoSchedule
```

删除

```bash
kubectl taint nodes 节点名 key-
```

为node1设置taint

```bash
[root@master pod]# kubectl taint nodes node1 node1=node1:NoSchedule
node/node1 tainted
```

```bash
[root@master pod]# kubectl describe nodes node1 | grep -E '(Roles|Taints)'
Roles:              node1
Taints:             node1=node1:NoSchedule
```

查看所有pod

```bash
[root@master pod]# kubectl get pods -o wide --no-headers
nginx-6799fc88d8-2l9lt   1/1   Running   0     14m   10.244.166.144   node1   <none>   <none>
nginx-6799fc88d8-bhl7w   1/1   Running   0     14m   10.244.166.145   node1   <none>   <none>
nginx-6799fc88d8-hfxch   1/1   Running   0     22m   10.244.166.140   node1   <none>   <none>
nginx-6799fc88d8-skhmd   1/1   Running   0     22m   10.244.166.141   node1   <none>   <none>
web1                     1/1   Running   0     40m   10.244.166.139   node1   <none>   <none>
```

可以看到设置taint对当前正在运行的pod是不起作用的

把deplyment nginx的副本设置为0再设置为4.

```bash
[root@master pod]# kubectl scale deploy nginx --replicas=0
deployment.apps/nginx scaled
[root@master pod]# kubectl scale deploy nginx --replicas=4
deployment.apps/nginx scaled
```

```bash
[root@master pod]# kubectl get pods -o wide --no-headers
nginx-6799fc88d8-jkfs5   0/1   ContainerCreating   0     28s   <none>           node2   <none>   <none>
nginx-6799fc88d8-khtnf   0/1   ContainerCreating   0     28s   <none>           node2   <none>   <none>
nginx-6799fc88d8-m9psk   1/1   Running             0     28s   10.244.104.11    node2   <none>   <none>
nginx-6799fc88d8-spqk8   0/1   ContainerCreating   0     28s   <none>           node2   <none>   <none>
web1                     1/1   Running             0     58m   10.244.166.139   node1   <none>   <none>
```

可以看到pod都在node2上运行了

删除nginx

```bash
[root@master pod]# kubectl delete deploy nginx
deployment.apps "nginx" deleted
```

如果需要pod在含有taint的节点上运行.则定义pod的时候需要指定toleration属性

```yaml
tolerations:
- key:  "key值"
  operator: "Equal"
  value: "value值"
  effect: "值"
```

这里的Equal需要和taint的值一样

Exists可以不指定value的值

#### 设置operator的值为Equal

```bash
[root@master pod]# kubectl describe nodes node1
Name:               node1
Roles:              node1
Labels:             beta.kubernetes.io/arch=amd64
                    beta.kubernetes.io/os=linux
                    kubernetes.io/arch=amd64
                    kubernetes.io/hostname=node1
                    kubernetes.io/os=linux
                    mytag=node1
                    node-role.kubernetes.io/node1=
Annotations:        kubeadm.alpha.kubernetes.io/cri-socket: /var/run/dockershim.sock
                    name: yinyaliang
                    node.alpha.kubernetes.io/ttl: 0
                    projectcalico.org/IPv4Address: 192.168.122.202/24
                    projectcalico.org/IPv4IPIPTunnelAddr: 10.244.166.128
                    volumes.kubernetes.io/controller-managed-attach-detach: true
CreationTimestamp:  Sun, 10 Jul 2022 20:41:42 +0800
Taints:             node1=node1:NoSchedule
```

目前是 node1有标签 有污点

创建pod的yaml文件

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  name:  web2
  labels:
    role:  myrole
spec:
  nodeSelector:
    mytag:  node1
  containers:
    - name:  web
      image:  nginx
      imagePullPolicy: IfNotPresent
```

```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
web2   0/1     Pending   0          6s
```

会停留在pending状态

删除后修改yaml，增加tolerations

```yaml
[root@master pod]# cat podtaint.yaml 
apiVersion:  v1
kind:  Pod
metadata:
  name:  web2
  labels:
    role:  myrole
spec:
  nodeSelector:
    mytag:  node1
  tolerations:
  - key:  "node1"
    operator: "Equal"
    value: "node1"
    effect: "NoSchedule"
  containers:
    - name:  web
      image:  nginx
      imagePullPolicy: IfNotPresent
```

```
[root@master pod]# kubectl get pods -o wide
NAME   READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
web2   1/1     Running   0          13s   10.244.166.146   node1   <none>           <none>
```

并不是节点设置了taint,pod设置了toleration，这个pod就一定会在此节点上运行. 这里用label来指定pod在node2上运行

删除pod

```bash
kubectl delete pods web2
```

删除node1上的taint

```bash
[root@master pod]# kubectl taint nodes node1 node1-
node/node1 untainted
```

给node1设置多个taint

```bash
[root@master pod]# kubectl taint nodes node1 key123=value123:NoSchedule
node/node1 tainted
[root@master pod]# kubectl taint nodes node1 keyxx=valuexx:NoSchedule
node/node1 tainted
[root@master pod]# kubectl taint nodes node1 node1=node1:NoSchedule
node/node1 tainted
```

```bash
[root@master pod]# kubectl describe nodes node1 | grep -E -A2 '(Roles|Taints)'
Roles:              node1
Labels:             beta.kubernetes.io/arch=amd64
                    beta.kubernetes.io/os=linux
--
Taints:             key123=value123:NoSchedule
                    keyxx=valuexx:NoSchedule
                    node1=node1:NoSchedule
```

在podtaint.yaml不修改的情况下再次创建

```bash
[root@master pod]# kubectl apply -f podtaint.yaml
pod/web2 created
```

```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
web2   0/1     Pending   0          14s
```

如果节点有多个污点则需要pod设置容忍所有的污点才可以在这个节点上运行

#### operator 的值等于Exists的情况

在设置节点taint的时候,如果value的值非空,在pod里的tolerations字段只能写Equal,不能写Exists

取消node1的taint，只保留node1=node1

```bash
[root@master pod]# kubectl taint nodes node1 key123-
node/node1 untainted
[root@master pod]# kubectl taint nodes node1 keyxx-
node/node1 untainted
```

```bash
[root@master pod]# kubectl describe nodes node1 | grep Taint
Taints:             node1=node1:NoSchedule
```

修改podtaint.yaml，配置operator的值为Exists

```bash
apiVersion:  v1
kind:  Pod
metadata:
  name:  web2
  labels:
    role:  myrole
spec:
  nodeSelector:
    mytag:  node1
  tolerations:
  - key:  "node1"
    operator: "Exists"
    value: "node1"
    effect: "NoSchedule"
  containers:
    - name:  web
      image:  nginx
      imagePullPolicy: IfNotPresent
```

创建Pod

```bash
[root@master pod]# kubectl apply -f podtaint.yaml
The Pod "web2" is invalid: 
* spec.tolerations[0].operator: Invalid value: core.Toleration{Key:"node1", Operator:"Exists", Value:"node1", Effect:"NoSchedule", TolerationSeconds:(*int64)(nil)}: value must be empty when `operator` is 'Exists'
* spec.tolerations: Forbidden: existing toleration can not be modified except its tolerationSeconds
```

如果operator选择的是Exists的话,是不能写value的

修改node1的taint的值

```bash
[root@master pod]# kubectl taint nodes node1 node1=:NoSchedule --overwrite
node/node1 modified
```

再修改podtaint.yaml的值

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  name:  web2
  labels:
    role:  myrole
spec:
  nodeSelector:
    mytag:  node1
  tolerations:
  - key:  "node1"
    operator: "Exists"
    effect: "NoSchedule"
  containers:
    - name:  web
      image:  nginx
      imagePullPolicy: IfNotPresent
```

创建pod

```bash
[root@master pod]# kubectl apply -f podtaint.yaml
pod/web2 created
```



```bash
[root@master pod]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
web2   1/1     Running   0          31s
```

清理

删除 web2

清理node1上的taint

```bash
[root@master pod]# kubectl delete pod web2
pod "web2" deleted
[root@master pod]# kubectl taint nodes node1 node1-
node/node1 untainted
```
