---
title: "Switch STP"
tags:
  - RS
toc: true
---

STP介绍

### 生成树协议功能:

> 以太网构建无环逻辑拓扑的网络协议
> 防止环路及其产生的广播风暴、多帧复用、MAC表不稳定
> 允许网络设计包含备份链接，保持冗余链路

### 三个步骤

> 选举一个根桥
> 在非根桥交换机选举根端口
> 在每条链路上选举指定端口

### 生成树术语

#### Bridge Priority Data Unit(BPDU):
包含桥ID,发送发的桥ID,到根桥的COST值,计时器等，所有的交换机会交换BPDU来选举根桥。桥ID最小的会变为根桥

#### Bridge ID(桥ID)
字节的字段，包含2个字节的桥优先级和6个字节的设备MAC 地址，在优先级一致的情况下会参考MAC地址

#### Bridge Priority(桥优先级)
默认值32768，范围:0-65535

```bash
spanning-tree vlan 1 priority priority
```

#### Root Bridge(根桥)
具有最低的Bridge id的交换机会成为根桥.网络中的流量都会基于根桥选路

#### Path Cost(路径开销)
到根桥可能会有多条路径，会依据cost选择最低的一条

| Speed       | Code        |
| ----------- | ----------- |
| 10Mbps      | 100         |
| 100Mbps     | 19          |
| 1Gbps       | 4           |
| 10Gbps      | 2           |

#### Designated port(指定端口)
环路中的每条链路选择一个端口作为指定端口，根桥的所有端口都是指定端口
> 最小的BID(发送者的)
> 到达根桥最低的路径开销
> 最低的发送者BID
> 最低的发送者端口ID

#### Root port(根端口)
非根桥上选一个端口作为根端口。是到达根桥开销最小的端口，每台设备有一个

### 根桥的选举过程
每台交换机假定自己是根桥，并向邻居发送BPDU，包含自身的BID，同时也会接收其它邻居的BPDU。每收到一个BPDU，交换机就会将其与自身的BID比较。 如果优于自身，交换机就会意识到自己不是根桥，否则仍会认为自身是根桥并持续发送BPDU，如果有新的更优的BID交换机加入到网络中，就会被选举为 新的根桥

### 生成树的类型

#### 802.1D
它是IEEE开发的一种生成树标准，每个拓扑只选择一个根桥接器。所有流量都在同一路径上流动(到根桥接器的最佳路径)，只支持单个Vlan或lan，它非常慢，因为它需要30s-50s秒来收敛。

> 优点
* 对CPU和内存要求低
> 缺点
* 不支持负载均衡 
* 到达根桥的最佳成本计算的路径可能不是到达网络的最佳路径

#### CST
整个网络只有一个生成树实例，支持多Vlan

#### Per VLAN Spanning Tree+(PVST+)
思科专有 ，兼容802.1D和CST,每个VLAN一个生成树
> 优点
* PVST+在为每个VLAN选择根桥接时，对网络性能提供了更多的优化
* 带宽消耗小于CST
* 最佳的负载均衡
> 缺点
* 50s收敛
* 消耗更多的CPU和内存资源

#### 802.1w Rapid Spanning Tree Protocol(RSTP)
IEEE开发的一种标准，具有比CST更快的收敛速度，在拓扑结构中寻找单一根桥。RSTP所需的桥接资源高于CST，但小于PVST+，收敛时间在5s-10s
> 端口状态
* discarding
* learning 
* forwarding

> 端口角色
* 替代端口(AP) 根端口的备份,5s内切换
* 备份端口(BP) 指定端口的备份，1s内切换

#### Rapid Per VLAN Spanning Tree +(RPVST+)
Cisco开发，提供了比PVST+更快的收敛速度，每个VLAN 基于802.1w的单独实例。比其它STP标准需要更多的CPU和内存。
和802.1d对比，
报文格式:
4bit的网桥优先级   12bit的扩展系统ID     48bit的MAC地址

#### 802.1s(Multiple Spanning Tree)

IEEE开发，可以对vlan进行分组，并对每个单独的组运行RSTP
> 优点
* 可以实现冗余
* 负载均衡
* 较少的CPU和内存负载

> 缺点
* 配置复杂

```bash
指定模式
(config)#spanning-tree mode mst          
配置参数
(config)#spanning-tree mst configuration  
(config-mst)#name name         非必需
(config-mst)#revision rev_num  非必需
(config-mst)#instance instance_number vlan range

(config)#spanning-tree mst instance_number root primary|secondary   
配置mst的primary和secondary roots
```

<img src="/assets/images/stp/stp1.png">

### STP的端口状态

| STP端口状态 | 接收BPDU    | 发送BPDU    |  学习MAC地址 |
| ----------- | ----------- | ----------- | -----------  |
| Bloking     |    √        |             |              |
| Listening   |    √        | √           |              |
| Learning    |    √        | √           | √            |
| Forwarding  |    √        | √           | √            |
| Disabled    |             |             |              |

### STP稳定机制

UplinkFast 接入层上行链路启用，加快收敛，上行链路收敛速度30-50s变为1s

```bash
(config)#spanning-tree uplinkfast
```

BackboneFast 分布层或者核心层交换机启用(根桥和备份根桥)，交换机要有冗余链路，加快收敛 30s左右

```bash
spanning-tree backbonefast
```

PortFast access端口启用加速收敛，1s收敛, 思科私有

```bash
(config-if)spanning-tree portfast
# 端口
(config)spanning-tree portfast default 
# 全局的access接口
(config-if)spnaning-tree portfast trunk
# 链接多个VLAN通信的服务器环境
(config-if)#switchport host
# 启用postfast并置为access模式
```

BPDU guard 收到BPDU，端口将处于err-disable状态(access状态的状态收到BPDU)

```bash
(config-if) spanning-tree bpduguard enable
# 端口
(config) spanning-tree portfast bpduguard default
# 全局
# err-disable自动恢复
(config)#errdisable recovery cause all
(config)#errdisable recovery interval 30-86400
```

BPDU filter 抑制端口上的BPDU，阻止向外发送BPDU并忽略收到的BPDU，配合Postfast

```bash
spanning-tree bpdufilter enable
# 接口
spanning-tree portfast bpdufilter default
```

ROOT guard  阻止外部交换机成为根桥,启用的端口强制变为指定端口，如果收到更优的BPDU，端口会进入root-inconsistent状态，不会转发流量 ,Root Guard应该配置在所有接入端口中，即接入终端的端口,异常状态会自动恢复

```bash
spanning-tree guard root
```

LOOP guard，单向链路下当非指定端口收不到BPDU时，阻止它成为指定端口，防止环路

<img src="/assets/images/stp/stp2.png">

* Loop Guard不能再启用了Root Guard的交换机上使用
* Loop GUard不能再启用了Port Fast或者Dynamic Vlan port上使用

```bash
spanning-tree guard loop
```

> UplinkFast 和 BackboneFast已经集成到RSTP中

#### UDLD(单向链路检测)

检查设备自身的单向链路，思科私有， UDLD一般和Loop Guard配合使用
* 普通模式 仅仅将端口标记为不确定
* 激进模式 将端口置于err-disable状态

```bash
(config)#udld(enable | aggressive)  # 所有光口启用
(config-if)#udld port [aggressive]  # 特定光口启用
udld reset # 重置udld关闭的端口
```

<img src="/assets/images/stp/stp3.png">

* 通常在所有的光纤互联端口开启
* 使用激进模式
* 全局开启UDLD

#### STP稳定推荐用法
PostFast 终端用户，配合BPDU Guard使用
根保护 所有指定端口和不链接根桥的端口
环路保护 所有根端口和非指定端口
UDLD所有交换机互联的链路上
