---
title: "zabbix discovery use prometheus data"
tags:
  - Monitor
toc: true
---
 
zabbix 使用prometheus数据格式实现自动发现


#### 数据格式
```
# HELP apisix_http_status HTTP status codes per service in APISIX
# TYPE apisix_http_status counter
apisix_http_status{code="200",route="ceshi-api",matched_uri="/*",matched_host="ceshi.camin.vip",service="ceshi-api",consumer="",node=""} 26489
apisix_http_status{code="200",route="ceshi-api",matched_uri="/*",matched_host="ceshi.camin.vip",service="ceshi-api",consumer="",node="10.1.9.3"} 624693
apisix_http_status{code="200",route="ceshi-api",matched_uri="/*",matched_host="ceshi.campre.dom",service="ceshi-api",consumer="",node="10.1.9.3"} 4820
apisix_http_status{code="200",route="ceshi.camin.vip",matched_uri="/*",matched_host="ceshi.camin.vip",service="ceshi-console",consumer="",node="10.1.9.1"} 8006
apisix_http_status{code="200",route="ceshi.camin.vip",matched_uri="/*",matched_host="ceshi.camin.vip",service="ceshi-console",consumer="",node="10.0.1.1"} 2376
```

#### 模板
```yaml
zabbix_export:
  version: '6.0'
  date: '2022-11-16T06:43:50Z'
  groups:
    -
      uuid: 5875dc458fab45f699bdaf705773c951
      name: 模板/服务
  templates:
    -
      uuid: 70715d4c9a5744a0a0550c7131c107f5
      template: service.apisix
      name: service.apisix
      groups:
        -
          name: 模板/服务
      items:
        -
          uuid: d265901f69d640889c4f2a84b4971ab8
          name: 'apisix metrics'
          type: HTTP_AGENT
          key: apisix.info
          trends: '0'
          value_type: TEXT
          url: '{HOST.IP}:9091/apisix/prometheus/metrics'
          tags:
            -
              tag: Application
              value: RAW
      discovery_rules:
        -
          uuid: cda308711c9f4ef8aef2c3f74d3bb2a3
          name: 'service apisix http code 2xx'
          type: DEPENDENT
          key: apisix.httpcode.2xx
          delay: '0'
          item_prototypes:
            -
              uuid: ff316b35fb62427492c1cf0ec435a401
              name: '{#NAME}{code={#CODE},route={#ROUTE},matched_uri={#MATCHED_URI},matched_host={#MATCHED_HOST},service={#SERVICE},consumer={#CONSUMER},node={#NODE}}'
              type: DEPENDENT
              key: 'apisix.httpcode.2xx[{#CODE},{#ROUTE},{#MATCHED_URI},{#MATCHED_HOST},{#SERVICE},{#CONSUMER},{#NODE}]'
              delay: '0'
              description: '{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
              preprocessing:
                -
                  type: PROMETHEUS_PATTERN
                  parameters:
                    - 'apisix_http_status{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
                    - value
                    - ''
                -
                  type: SIMPLE_CHANGE
                  parameters:
                    - ''
              master_item:
                key: apisix.info
              tags:
                -
                  tag: Application
                  value: APISIX-2XX
          master_item:
            key: apisix.info
          lld_macro_paths:
            -
              lld_macro: '{#CODE}'
              path: '$.labels[''code'']'
            -
              lld_macro: '{#CONSUMER}'
              path: '$.labels[''consumer'']'
            -
              lld_macro: '{#HELP}'
              path: $.help
            -
              lld_macro: '{#MATCHED_HOST}'
              path: '$.labels[''matched_host'']'
            -
              lld_macro: '{#MATCHED_URI}'
              path: '$.labels[''matched_uri'']'
            -
              lld_macro: '{#NAME}'
              path: $.name
            -
              lld_macro: '{#NODE}'
              path: '$.labels[''node'']'
            -
              lld_macro: '{#ROUTE}'
              path: '$.labels[''route'']'
            -
              lld_macro: '{#SERVICE}'
              path: '$.labels[''service'']'
          preprocessing:
            -
              type: PROMETHEUS_TO_JSON
              parameters:
                - 'apisix_http_status{code=~"2.*"}'
        -
          uuid: 6a079ccfcf1e4df188515f0951c6f5e1
          name: 'service apisix http code 3xx'
          type: DEPENDENT
          key: apisix.httpcode.3xx
          delay: '0'
          item_prototypes:
            -
              uuid: e2a5955d8e2746a7a45d7ff27f3feb13
              name: '{#NAME}{code={#CODE},route={#ROUTE},matched_uri={#MATCHED_URI},matched_host={#MATCHED_HOST},service={#SERVICE},consumer={#CONSUMER},node={#NODE}}'
              type: DEPENDENT
              key: 'apisix.httpcode.3xx[{#CODE},{#ROUTE},{#MATCHED_URI},{#MATCHED_HOST},{#SERVICE},{#CONSUMER},{#NODE}]'
              delay: '0'
              description: '{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
              preprocessing:
                -
                  type: PROMETHEUS_PATTERN
                  parameters:
                    - 'apisix_http_status{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
                    - value
                    - ''
                -
                  type: SIMPLE_CHANGE
                  parameters:
                    - ''
              master_item:
                key: apisix.info
              tags:
                -
                  tag: Application
                  value: APISIX-3XX
          master_item:
            key: apisix.info
          lld_macro_paths:
            -
              lld_macro: '{#CODE}'
              path: '$.labels[''code'']'
            -
              lld_macro: '{#CONSUMER}'
              path: '$.labels[''consumer'']'
            -
              lld_macro: '{#HELP}'
              path: $.help
            -
              lld_macro: '{#MATCHED_HOST}'
              path: '$.labels[''matched_host'']'
            -
              lld_macro: '{#MATCHED_URI}'
              path: '$.labels[''matched_uri'']'
            -
              lld_macro: '{#NAME}'
              path: $.name
            -
              lld_macro: '{#NODE}'
              path: '$.labels[''node'']'
            -
              lld_macro: '{#ROUTE}'
              path: '$.labels[''route'']'
            -
              lld_macro: '{#SERVICE}'
              path: '$.labels[''service'']'
          preprocessing:
            -
              type: PROMETHEUS_TO_JSON
              parameters:
                - 'apisix_http_status{code=~"3.*"}'
        -
          uuid: f5e8b61f49a14bb79a96c911145a73e8
          name: 'service apisix http code 4xx'
          type: DEPENDENT
          key: apisix.httpcode.4xx
          delay: '0'
          item_prototypes:
            -
              uuid: c2a0c5e646cd420e95124f558a80fb86
              name: '{#NAME}{code={#CODE},route={#ROUTE},matched_uri={#MATCHED_URI},matched_host={#MATCHED_HOST},service={#SERVICE},consumer={#CONSUMER},node={#NODE}}'
              type: DEPENDENT
              key: 'apisix.httpcode.4xx[{#CODE},{#ROUTE},{#MATCHED_URI},{#MATCHED_HOST},{#SERVICE},{#CONSUMER},{#NODE}]'
              delay: '0'
              description: '{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
              preprocessing:
                -
                  type: PROMETHEUS_PATTERN
                  parameters:
                    - 'apisix_http_status{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
                    - value
                    - ''
                -
                  type: SIMPLE_CHANGE
                  parameters:
                    - ''
              master_item:
                key: apisix.info
              tags:
                -
                  tag: Application
                  value: APISIX-4XX
              trigger_prototypes:
                -
                  uuid: 859ab9da74524cfaa20be1b0fd37e06f
                  expression: 'last(/service.apisix/apisix.httpcode.4xx[{#CODE},{#ROUTE},{#MATCHED_URI},{#MATCHED_HOST},{#SERVICE},{#CONSUMER},{#NODE}])>0'
                  name: '{#ROUTE} {#NODE} {#CODE} over 0'
                  priority: WARNING
          master_item:
            key: apisix.info
          lld_macro_paths:
            -
              lld_macro: '{#CODE}'
              path: '$.labels[''code'']'
            -
              lld_macro: '{#CONSUMER}'
              path: '$.labels[''consumer'']'
            -
              lld_macro: '{#HELP}'
              path: $.help
            -
              lld_macro: '{#MATCHED_HOST}'
              path: '$.labels[''matched_host'']'
            -
              lld_macro: '{#MATCHED_URI}'
              path: '$.labels[''matched_uri'']'
            -
              lld_macro: '{#NAME}'
              path: $.name
            -
              lld_macro: '{#NODE}'
              path: '$.labels[''node'']'
            -
              lld_macro: '{#ROUTE}'
              path: '$.labels[''route'']'
            -
              lld_macro: '{#SERVICE}'
              path: '$.labels[''service'']'
          preprocessing:
            -
              type: PROMETHEUS_TO_JSON
              parameters:
                - 'apisix_http_status{code=~"4.*"}'
        -
          uuid: ee04b62140fd470badfd521e22127e52
          name: 'service apisix http code 5xx'
          type: DEPENDENT
          key: apisix.httpcode.5xx
          delay: '0'
          item_prototypes:
            -
              uuid: ba0685038fd84ab5ae87fbe15b2d683f
              name: '{#NAME}{code={#CODE},route={#ROUTE},matched_uri={#MATCHED_URI},matched_host={#MATCHED_HOST},service={#SERVICE},consumer={#CONSUMER},node={#NODE}}'
              type: DEPENDENT
              key: 'apisix.httpcode.5xx[{#CODE},{#ROUTE},{#MATCHED_URI},{#MATCHED_HOST},{#SERVICE},{#CONSUMER},{#NODE}]'
              delay: '0'
              description: '{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
              preprocessing:
                -
                  type: PROMETHEUS_PATTERN
                  parameters:
                    - 'apisix_http_status{code="{#CODE}",route="{#ROUTE}",matched_uri="{#MATCHED_URI}",matched_host="{#MATCHED_HOST}",service="{#SERVICE}",consumer="{#CONSUMER}",node="{#NODE}"}'
                    - value
                    - ''
                -
                  type: SIMPLE_CHANGE
                  parameters:
                    - ''
              master_item:
                key: apisix.info
              tags:
                -
                  tag: Application
                  value: APISIX-5XX
              trigger_prototypes:
                -
                  uuid: 263014e968b34f17b21eb4926359c83c
                  expression: 'last(/service.apisix/apisix.httpcode.5xx[{#CODE},{#ROUTE},{#MATCHED_URI},{#MATCHED_HOST},{#SERVICE},{#CONSUMER},{#NODE}])>0'
                  name: '{#ROUTE} {#NODE} {#CODE} over 0'
                  priority: WARNING
          master_item:
            key: apisix.info
          lld_macro_paths:
            -
              lld_macro: '{#CODE}'
              path: '$.labels[''code'']'
            -
              lld_macro: '{#CONSUMER}'
              path: '$.labels[''consumer'']'
            -
              lld_macro: '{#HELP}'
              path: $.help
            -
              lld_macro: '{#MATCHED_HOST}'
              path: '$.labels[''matched_host'']'
            -
              lld_macro: '{#MATCHED_URI}'
              path: '$.labels[''matched_uri'']'
            -
              lld_macro: '{#NAME}'
              path: $.name
            -
              lld_macro: '{#NODE}'
              path: '$.labels[''node'']'
            -
              lld_macro: '{#ROUTE}'
              path: '$.labels[''route'']'
            -
              lld_macro: '{#SERVICE}'
              path: '$.labels[''service'']'
          preprocessing:
            -
              type: PROMETHEUS_TO_JSON
              parameters:
                - 'apisix_http_status{code=~"5.*"}'
```

#### 效果
<img src="/assets/images/zabbix/zabbix-metrics.png">
