---
title: "密码管理"
tags:
  - Kubernetes
toc: true
---

密码管理的几种方式

## 创建及删除secret

避免mysql类型的容器变量保存在yaml里不安全,可以使用secret,保存方式为

```
键=值 或者是 key=value
```

#### 创建secret

```bash
[root@master ~]# mkdir secret
[root@master ~]# cd secret/
```

创建一个新的命名空间

```bash
[root@master secret]# kubectl create ns nssec
namespace/nssec created
[root@master secret]# kubens nssec
Context "kubernetes-admin@kubernetes" modified.
Active namespace is "nssec".
```

#### 命令行

kubectl create secret generic 名字 --from-literal=k1=v1 --from-literal=k2=v2

```bash
# 创建一个名字为 mysecret1 的 secret
[root@master secret]# kubectl create secret generic mysecret1 --from-literal=xx=tom --from-literal=yy=redhat
secret/mysecret1 created
```

查看

```bash
[root@master secret]# kubectl get secrets
NAME                  TYPE                                  DATA   AGE
default-token-twgk8   kubernetes.io/service-account-token   3      2m56s
mysecret1             Opaque                                2      20s
```

secret有三种类型

```
1、 Opaque: base64编码格式的secret，用来存储密码、密钥,数据可以通过base64解码
2、 kubernetes.io/dockerconfigjson: 用来存储私有docker registry的认证信息
3、 kubernetes.io/sevice-account-token: 用来被serviceaccount引用
```

创建serviceaccount时, kubernets会默认创建对应的secret.pod如果使用了serviceaccout,对应的secret会自动挂在到Pod目录/run/secrets/kubernets.io/serviceaccount

查看mysecret1的具体属性

```bash
[root@master secret]# kubectl describe secrets mysecret1
Name:         mysecret1
Namespace:    nssec
Labels:       <none>
Annotations:  <none>

Type:  Opaque

Data
====
xx:  3 bytes
yy:  6 bytes
```

这里可以看到两个变量,分别是xx和yy,但具体是什么这里看不出来

```bash
[root@master secret]# kubectl describe secrets mysecret1
Name:         mysecret1
Namespace:    nssec
Labels:       <none>
Annotations:  <none>

Type:  Opaque

Data
====
xx:  3 bytes
yy:  6 bytes
[root@master secret]# kubectl get secret mysecret1 -o yaml
apiVersion: v1
data:
  xx: dG9t
  yy: cmVkaGF0
kind: Secret
metadata:
  creationTimestamp: "2022-07-19T15:38:45Z"
  name: mysecret1
  namespace: nssec
  resourceVersion: "98855"
  uid: 388779de-d3aa-4a9e-bfbf-7f7d63b1af9a
type: Opaque
```

上面data字段里就是mysecret1的键值对,需要base64解码才可以看到具体值

解码

```bash
[root@master secret]# echo "dG9t" | base64 --decode
tom[root@master secret]#  echo "cmVkaGF0" | base64 --decode
redhat[root@master secret]# 
```

#### 把文件创建为secret

文件名作为key，内容作为value. 

kubectl create secret generic mysecret2 --from-file=file1 --from-file=file2 

作用是把一个文件的内容写入secret里,通过卷的方式来引用这个secret,就可以把此文件写入pod里了

查看hosts

```bash
[root@master secret]# cat /etc/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 
```

创建secret

```bash
[root@master secret]# kubectl create secret generic mysecret2 --from-file=/etc/hosts
secret/mysecret2 created
```

查看

```bash
[root@master secret]# kubectl get secrets mysecret2 -o yaml
apiVersion: v1
data:
  hosts: MTI3LjAuMC4xICAgbG9jYWxob3N0IGxvY2FsaG9zdC5sb2NhbGRvbWFpbiBsb2NhbGhvc3Q0IGxvY2FsaG9zdDQubG9jYWxkb21haW40Cjo6MSAgICAgICAgIGxvY2FsaG9zdCBsb2NhbGhvc3QubG9jYWxkb21haW4gbG9jYWxob3N0NiBsb2NhbGhvc3Q2LmxvY2FsZG9tYWluNgoxOTIuMTY4LjEyMi4yMDAgbWFzdGVyCjE5Mi4xNjguMTIyLjIwMiBub2RlMSAKMTkyLjE2OC4xMjIuMjAzIG5vZGUyIAo=
kind: Secret
metadata:
  creationTimestamp: "2022-07-19T15:49:12Z"
  name: mysecret2
  namespace: nssec
  resourceVersion: "99732"
  uid: 1e095123-849f-4cde-b092-ac574252075c
type: Opaque
```

hosts代表文件，下面是内容

```bash
[root@master secret]# kubectl get secrets mysecret2 -o jsonpath='{.data.hosts}'
MTI3LjAuMC4xICAgbG9jYWxob3N0IGxvY2FsaG9zdC5sb2NhbGRvbWFpbiBsb2NhbGhvc3Q0IGxvY2FsaG9zdDQubG9jYWxkb21haW40Cjo6MSAgICAgICAgIGxvY2FsaG9zdCBsb2NhbGhvc3QubG9jYWxkb21haW4gbG9jYWxob3N0NiBsb2NhbGhvc3Q2LmxvY2FsZG9tYWluNgoxOTIuMTY4LjEyMi4yMDAgbWFzdGVyCjE5Mi4xNjguMTIyLjIwMiBub2RlMSAKMTkyLjE2OC4xMjIuMjAzIG5vZGUyIAo=
```

解码

```bash
[root@master secret]# kubectl get secrets mysecret2 -o jsonpath='{.data.hosts}' | base64 -d
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 
```

创建一个包含两个文件的secret mysecret3

```bash
[root@master secret]# kubectl create secret generic mysecret3 --from-file=/etc/hosts --from-file=/etc/issue
secret/mysecret3 created
```

获取mysecret3的键值对

```bash
[root@master secret]# kubectl get secrets mysecret3 -o yaml
apiVersion: v1
data:
  hosts: MTI3LjAuMC4xICAgbG9jYWxob3N0IGxvY2FsaG9zdC5sb2NhbGRvbWFpbiBsb2NhbGhvc3Q0IGxvY2FsaG9zdDQubG9jYWxkb21haW40Cjo6MSAgICAgICAgIGxvY2FsaG9zdCBsb2NhbGhvc3QubG9jYWxkb21haW4gbG9jYWxob3N0NiBsb2NhbGhvc3Q2LmxvY2FsZG9tYWluNgoxOTIuMTY4LjEyMi4yMDAgbWFzdGVyCjE5Mi4xNjguMTIyLjIwMiBub2RlMSAKMTkyLjE2OC4xMjIuMjAzIG5vZGUyIAo=
  issue: XFMKS2VybmVsIFxyIG9uIGFuIFxtCgo=
kind: Secret
metadata:
  creationTimestamp: "2022-07-19T15:51:57Z"
  name: mysecret3
  namespace: nssec
  resourceVersion: "99966"
  uid: f68c6996-7f6a-476f-b81c-85770498cda2
type: Opaque
```

这种方法一般用于给pod传递文件

#### 变量文件的方法

```
变量 1 = 值 1
变量 2 = 值 2
```

创建变量文件env.txt

```bash
[root@master secret]# cat env.txt 
xx=tom
yy=redhat
```

```bash
[root@master secret]# kubectl create secret generic mysecret4 --from-env-file=env.txt
secret/mysecret4 created
```

#### 通过yaml文件的方式

先求出base64的值

```bash
[root@master secret]# echo -n "tom" | base64
dG9t
[root@master secret]# echo -n "redhat" | base64
cmVkaGF0
```

创建yaml文件

```yaml
apiVersion:  v1
kind:  Secret
metadata:
  name:  mysecret5
type:  Opaque
data:
  xx:  dG9t
  redhat:  cmVkaGF0
```

创建secret

```bash
[root@master secret]# kubectl apply -f secret5.yaml 
secret/mysecret5 created
```

```bash
[root@master secret]# kubectl get secrets
NAME                  TYPE                                  DATA   AGE
default-token-twgk8   kubernetes.io/service-account-token   3      24m
mysecret1             Opaque                                2      21m
mysecret2             Opaque                                1      11m
mysecret3             Opaque                                2      8m19s
mysecret4             Opaque                                2      3m26s
mysecret5             Opaque                                2      20s
```

#### 删除secret

```bash
[root@master secret]# kubectl delete secrets mysecret5
secret "mysecret5" deleted
```

### 在pod里以变量和卷的方式引用secret

#### 以卷的方式

在pod的yaml文件里,创建一个类型为secret的卷，然后挂在到容器里某个制定的目录里。容器创建好后,会在容器的挂在目录里创建一个文件，此文件的文件名为secret里的key.文件内容对应key的value.以卷的方式引用secret的主要作用是往pod里传递文件

创建pod的yaml文件

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  creationTimestamp:  null
  labels:
    run:  pod1
  name:  pod1
spec:
  volumes:
  - name:  xx
    secret:
      secretName:  mysecret2
  containers:
  - image:  nginx
    imagePullPolicy:  IfNotPresent
    name:  pod1
    volumeMounts:
    - name:  xx
      mountPath: "/etc/test"
status:  {}
```

在pod1里吧xx这个卷挂在到/etc/test/目录里.容器里会有hosts文件

```bash
[root@master secret]# kubectl apply -f pod1.yaml 
pod/pod1 created
```

```bash
[root@master secret]# kubectl exec pod1 -- cat /etc/test/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 
```

删除pod

```bash
kubectl delete -f pod1.yaml
```

修改pod1.yaml

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  creationTimestamp:  null
  labels:
    run:  pod1
  name:  pod1
spec:
  volumes:
  - name:  xx
    secret:
      secretName:  mysecret3
  containers:
  - image:  nginx
    imagePullPolicy:  IfNotPresent
    name:  pod1
    volumeMounts:
    - name:  xx
      mountPath: "/etc/test/issue"
      subPath:  issue
status:  {}
```

mysecret3里有两个文件，如果只想使用一个,可以使用subPath来解决

```bash
[root@master secret]# kubectl apply -f pod1.yaml 
pod/pod1 created
[root@master secret]# kubectl exec pod1 -- ls /etc/test/
issue
```

如果修改服务的配置文件,比如nginx的配置文件,可以不需要重新编译镜像



#### 以变量的方式

```yaml
env:
- name:  变量名
  value:  值
```

如果是从secret引用值,这里写valueFrom

```yaml
env:
- name:  变量名
  valueFrom:
    secretKeyRef:
      name:  secretX
      key:  keyX
```

变量的值会使用secretX里的keyX这个键对应的值

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  creationTimestamp:  null
  labels:
    run:  pod2
  name:  pod2
spec:
  containers:
  - image:  mysql
    imagePullPolicy:  IfNotPresent
    name:  pod2
    env:
    - name:  MYSQL_ROOT_PASSWORD
      valueFrom: 
        secretKeyRef:
          name:  mysecret1
          key:  yy
```

```bash
[root@master secret]# kubectl apply -f pod2.yaml
pod/pod2 created
```

```bash
[root@master secret]# kubectl get pods -o wide
NAME   READY   STATUS    RESTARTS   AGE   IP              NODE    NOMINATED NODE   READINESS GATES
pod1   1/1     Running   0          11m   10.244.104.22   node2   <none>           <none>
pod2   1/1     Running   0          16s   10.244.104.23   node2   <none>           <none>
```

### 创建及删除configmap

主要作用: 

- 存储密码
- 往pod里传递文件
- 格式: 键=值

和secret的区别:

- 不使用base64编码

查看命令

kubectl get configmaps

创建方法

- 直接指定key和value
- 把一个文件内容作为value
- 直接写yaml

#### 命令行的方式

```bash
kubectl create cm 名字 --from-literal=key=v1 --from-literal=k2=v2 ...
```

创建一个my1的configmap

```bash
[root@master ~]# kubectl create configmap my1 --from-literal=xx=tom --from-literal=yy=redhat
configmap/my1 created
```

查看

```bash
[root@master ~]# kubectl get configmaps
NAME               DATA   AGE
kube-root-ca.crt   1      47h
my1                2      26s
[root@master ~]# kubectl describe configmaps my1
Name:         my1
Namespace:    nssec
Labels:       <none>
Annotations:  <none>

Data
====
xx:
----
tom
yy:
----
redhat
Events:  <none>
```

#### 文件方式

kubectl create configmap my2 --from-file=file1

```bash
kubectl create configmap my2 --from-file=/etc/hosts --from-file=/etc/issue
```

```bash
[root@master ~]# kubectl create configmap my2 --from-file=/etc/hosts --from-file=/etc/issue
configmap/my2 created
```

```bash
[root@master ~]# kubectl create configmap my2 --from-file=/etc/hosts --from-file=/etc/issue
configmap/my2 created
[root@master ~]# 
[root@master ~]# kubectl get cm
NAME               DATA   AGE
kube-root-ca.crt   1      47h
my1                2      2m37s
my2                2      16s
[root@master ~]# kubectl describe cm my2
Name:         my2
Namespace:    nssec
Labels:       <none>
Annotations:  <none>

Data
====
hosts:
----
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 

issue:
----
\S
Kernel \r on an \m


Events:  <none>
```

或者

```bash
[root@master ~]# kubectl describe cm my2
Name:         my2
Namespace:    nssec
Labels:       <none>
Annotations:  <none>

Data
====
hosts:
----
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 

issue:
----
\S
Kernel \r on an \m


Events:  <none>
[root@master ~]# kubectl get cm my2 -o yaml
apiVersion: v1
data:
  hosts: "127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4\n::1
    \        localhost localhost.localdomain localhost6 localhost6.localdomain6\n192.168.122.200
    master\n192.168.122.202 node1 \n192.168.122.203 node2 \n"
  issue: |+
    \S
    Kernel \r on an \m

kind: ConfigMap
metadata:
  creationTimestamp: "2022-07-21T15:06:23Z"
  name: my2
  namespace: nssec
  resourceVersion: "106264"
  uid: 68f8f1b3-f44e-4303-91c9-628e55904fb9
```

```bash
[root@master ~]# kubectl get cm my2 -o jsonpath='.{.data.hosts}'
.127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 
```

#### 使用configmap

以卷的方式

```yaml
apiVersion:  v1
kind:  Pod
metadata: 
  creationTimestamp:  null
  labels:
    run:  pod3
  name:  pod3
spec:
  volumes:
  - name:  xx
    configMap:
      name:  my2   # 关联my2的 configmap
  containers:
  - image:  nginx
    imagePullPolicy:  IfNotPresent
    name:  pod3
    resources:  {}
    volumeMounts:
    - name:  xx
      mountPath:  "/etc/test"
```

```bash
[root@master tmp]# kubectl apply -f pod.yaml 
pod/pod3 created
```

```bash
[root@master tmp]# kubectl exec pod3 -- ls /etc/test
hosts
issue
```

查看文件

```bash
[root@master tmp]# kubectl exec pod3 -- ls /etc/test
hosts
issue
[root@master tmp]# kubectl exec pod3 -- cat /etc/test/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 
```

如果只想挂载一个文件则使用subPath

#### 以变量的方式

创建pod的yaml文件

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  creationTimestamp:  null
  labels:
    run:  pod4
  name:  pod4
spec:
  containers:
  - image:  hub.c.163.com/library/mysql:latest
    imagePullPolicy:  IfNotPresent
    name:  pod4
    env:
    - name:  MYSQL_ROOT_PASSWORD
      valueFrom:
        configMapKeyRef:
          name:  my1
          key:  yy
```

```bash
[root@master tmp]# kubectl apply -f pod4.yaml 
pod/pod4 created
```

获取IP

```bash
[root@master tmp]# kubectl get pods -o wide
NAME   READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
pod1   1/1     Running   1          46h   10.244.104.25    node2   <none>           <none>
pod2   1/1     Running   1          46h   10.244.104.24    node2   <none>           <none>
pod3   1/1     Running   0          11m   10.244.166.152   node1   <none>           <none>
pod4   1/1     Running   0          23s   10.244.166.153   node1   <none>           <none>
```

检查

```bash
[root@node2 ~]# mysql -uroot -h10.244.166.153 -predhat
Welcome to the MariaDB monitor.  Commands end with ; or \g.
Your MySQL connection id is 4
Server version: 5.7.18 MySQL Community Server (GPL)

Copyright (c) 2000, 2018, Oracle, MariaDB Corporation Ab and others.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

MySQL [(none)]> 
```
