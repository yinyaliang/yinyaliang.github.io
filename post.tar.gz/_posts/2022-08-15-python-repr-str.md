---
title: "`Python中的 __repr__ __str__`"
tags:
  - Python
toc: true
---

Python 中特殊方法的一些理解笔记 

### \_\_repr\_\_
被内置函数repr用于把一个对象用"官方"的字符串形式表示出来(终端友好)
* 值传给eval()来返回一个对象的字符串表示形式
* 否则返回一个尖括号括起来的字符串，包含了对象类型的名称和附加的信息通常包括对象的名称和地址
* 一个类可以通过 __repr__方法来控制它的实例返回内容(也就是以上两点都通可以通过__repr__方法来定制)
* 返回 Unicode 字符串(str 类型) 

### \_\_str\_\_
被str(object) 和内置函数format()和print() 返回一个对象的'非正式'字符串形式(用户友好)
* 返回一个对象的字符串版本，如果对象没有提供，会返回空字符串，
* 对于字符串，会返回字符串本身，如果对象没有提供__str__方法，会使用__repr__方法(也就是repr(object))来提供返回值
* 返回 Unicode 字符串(str 类型)

### code
这是django query的源码部分,使用__repr__来返回一个对象和查询的数据切片:
```python
    def __repr__(self):
        data = list(self[:REPR_OUTPUT_SIZE + 1])
        if len(data) > REPR_OUTPUT_SIZE:
            data[-1] = "…(remaining elements truncated)…"
        return '<%s %r>' % (self.__class__.__name__, data)
```

注意:这里用到了%r,会返回数据的标准字符串形式，它和%s的区别看下面的例子:
```python
    In [58]: repr(datetime.datetime.now())
    Out[58]: 'datetime.datetime(2018, 9, 13, 15, 22, 22, 124128)'

    In [59]: str(datetime.datetime.now())
    Out[59]: '2018-09-13 15:22:26.310367'
```

再来看下__str__和__repr__的实现
```python
   In [68]: class example:
    ...:     def __str__(self):
    ...:         return 'str'
    ...:     def __repr__(self):
    ...:         return 'repr'
    ...:

    In [69]: a=example()

    In [70]: print(a)
    str

    In [71]: a
    Out[71]: repr

    In [74]: '{}'.format(a.__str__())
    Out[74]: 'str'

    In [75]: '{}'.format(a.__repr__())
    Out[75]: 'repr' 
```

如果对象没有__str__方法，会使用__repr__来代替
```python
In [76]: class example:
    ...:     def __repr__(self):
    ...:         return 'repr'
    ...:

In [77]: a=example()

In [78]: print(a)
repr

In [79]: '{}'.format(a.__str__())
Out[79]: 'repr'
```

如果我们只实现两个中的一个的话，只需要写__repr__就可以了

### 参考
    https://docs.python.org/3/reference/datamodel.html
    https://docs.python.org/3/library/functions.html#repr
    https://docs.python.org/3/library/stdtypes.html#str
    https://github.com/django/django/blob/master/django/db/models/query.py



