---
title: "探针"
tags:
  - Kubernetes
toc: true
---

probe

### 为pod配置liveness探针

deployment 只能保证pod的状态为running,内部服务状态无法保证

| deployment | 检测你出勤了没有 |
| ---------- | ---------------- |
| probe      | 检查你是否在工作 |

liveness 检查到某个pod运行有问题,就会重启，实际就是创建一个同名的Pod

#### command探测

容器内部执行命令,返回0 正常，0 异常

#### 创建目录

```bash
mkdir probe
cd probe
```

#### 创建namespace

```bash
[root@master probe]# kubectl create ns nsprobe
namespace/nsprobe created
[root@master probe]# kubens nsprobe
Context "kubernetes-admin@kubernetes" modified.
Active namespace is "nsprobe".
```

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  labels:
    test:  liveness
  name:  liveness-exec
spec:
  containers:
  - name:  liveness
    image:  busybox
    imagePullPolicy:  IfNotPresent
    args:
    -  /bin/sh
    -  -c
    -  touch /tmp/healthy; sleep 30 ; rm -rf /tmp/healthy; sleep 1000
    livenessProbe:
      exec:
        command:
        - cat
        - /tmp/healthy
      initialDelaySeconds:  5 # 启动的5s内不探测
      periodSeconds:  5 # 每5s探测一次
```

initialDelaySeconds: pod启动多少秒内不探测

periodSeconds: 探测间隔

successThreshold: 探测失败后,最少连续探测成功后多少次才被认定为成功,默认为1

failureThreshold: 探测失败后kubernetes的重拾次数 默认为3,最小值是1

#### 创建

```bash
[root@master probe]# kubectl apply -f liveness1.yaml 
pod/liveness-exec created
```

#### 查看

```bash
[root@master probe]# kubectl get pods
NAME            READY   STATUS    RESTARTS   AGE
liveness-exec   1/1     Running   2          2m53s
```

#### 检查/tmp/healthy是否存在

```
[root@master probe]# kubectl exec liveness-exec -- ls /tmp
[root@master probe]# kubectl get pods
NAME            READY   STATUS    RESTARTS   AGE
liveness-exec   1/1     Running   3          4m30s
```

这里healthy文件被删除了,pod被重建



#### liveness probe httpget探测方式

http是否可以访问,下面是通过80端口访问到/usr/shar/nginx/html/index.html

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  labels:
    test:  liveness
  name:  liveness-http
spec:
  containers:
  - name:  liveness
    image:  nginx
    imagePullPolicy:  IfNotPresent
    livenessProbe:
      failureThreshold:  3
      httpGet:
        path:  /index.html
        port:  80
        scheme:  HTTP
      initialDelaySeconds:  10
      periodSeconds:  10
      successThreshold:  1
```

```bash
[root@master probe]# kubectl apply -f liveness-http.yaml 
pod/liveness-http created
```

```bash
[root@master probe]# kubectl get pods
NAME            READY   STATUS             RESTARTS   AGE
liveness-exec   0/1     CrashLoopBackOff   7          14m
liveness-http   1/1     Running            0          87s
```

删除index.html

```bash
[root@master probe]# kubectl exec -it liveness-http -- bash
root@liveness-http:/# rm -rf /usr/share/nginx/html/
50x.html    index.html  
root@liveness-http:/# rm -rf /usr/share/nginx/html/index.html 
root@liveness-http:/# 
exit
```

查看

```bash
[root@master probe]# kubectl exec -it liveness-http -- ls /usr/share/nginx/html/
50x.html  index.html
```

index.html存在，证明pod已经重新拉起

#### liveness probe tcpsocket的探测方式

是否可以tcp三次握手

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  labels:
    test:  liveness
  name:  liveness-tcp
spec:
  containers:
  - name:  liveness
    image:  nginx
    imagePullPolicy:  IfNotPresent
    livenessProbe:
      failureThreshold:  3
      tcpSocket:
        port:  808
      initialDelaySeconds:  5
      periodSeconds:  5
```

nginx 端口是80,这里探测808 肯定失败

```bash
[root@master probe]# kubectl apply -f liveness-tcp.yaml 
pod/liveness-tcp created
```

```bash
[root@master probe]# kubectl get pods
NAME            READY   STATUS             RESTARTS   AGE
liveness-exec   0/1     CrashLoopBackOff   9          23m
liveness-http   1/1     Running            1          9m33s
liveness-tcp    1/1     Running            1          30s
```

可以看到完成了一次重启

#### 删除

```bash
[root@master probe]# kubectl delete pod liveness-exec
pod "liveness-exec" deleted
[root@master probe]# kubectl delete pod liveness-http
pod "liveness-http" deleted
[root@master probe]# kubectl delete pod liveness-tcp
pod "liveness-tcp" deleted
```



### 为pod配置readliness探针

livenss:  探测到pod有问题后,通过重启pod来解决问题

readliness:  探测到pod有问题之后不重启,只是svc接受到请求后,不再转发请求到这个pod

#### 创建

```yaml
apiVersion:  v1
kind:  Pod
metadata:
  labels:
    run:  app
  name:  pod1
spec:
  containers:
  - name:  c1
    image:  nginx
    imagePullPolicy:  IfNotPresent
    lifecycle:
      postStart:
        exec:
          command:  ["/bin/bash","-c","touch /tmp/healthy"]
    readinessProbe:
      exec:
        command:
        - cat
        - /tmp/healthy
```

```bash
[root@master probe]# kubectl apply -f readiness.yaml 
pod/pod1 created
[root@master probe]# sed 's/pod1/pod2/' readiness.yaml | kubectl apply -f -
pod/pod2 created
[root@master probe]# sed 's/pod1/pod3/' readiness.yaml | kubectl apply -f -
pod/pod3 created
```

```bash
[root@master probe]# kubectl get pods --show-labels
NAME   READY   STATUS    RESTARTS   AGE   LABELS
pod1   1/1     Running   0          58s   run=app
pod2   1/1     Running   0          20s   run=app
pod3   1/1     Running   0          15s   run=app
```

#### 创建svc

```bash
[root@master probe]# kubectl expose --name=readsvc pod pod1 --port=80 --selector=run=app
service/readsvc exposed
```

这里是为pod1创建svc,因为标签一样,所以readsvc会关联三个pod

#### 修改pod的 index.html

```bash
[root@master probe]# kubectl exec -ti pod1 -- bash
root@pod1:/# echo 111 > /usr/share/nginx/html/index.html 
```

```bash
[root@master probe]# kubectl exec -ti pod2 -- bash
root@pod2:/# echo 222 > /usr/share/nginx/html/index.html 
```

```bash
[root@master probe]# kubectl exec -ti pod3 -- bash
root@pod3:/# echo 333 > /usr/share/nginx/html/index.html
```

#### 获取svc的IP地址

```bash
[root@master probe]# kubectl get svc readsvc
NAME      TYPE        CLUSTER-IP     EXTERNAL-IP   PORT(S)   AGE
readsvc   ClusterIP   10.102.65.92   <none>        80/TCP    3m28s
```

#### 访问测试

```bash
[root@master probe]# curl -s 10.102.65.92
111
[root@master probe]# curl -s 10.102.65.92
333
[root@master probe]# curl -s 10.102.65.92
333
[root@master probe]# curl -s 10.102.65.92
222
```

#### 删除pod3里的/tml/healthy

```bash
[root@master probe]# kubectl exec -ti pod3 -- rm -rf /tmp/healthy
[root@master probe]# kubectl exec -ti pod3 -- ls -l /tmp/
total 0
```

#### 查看pod3的状态

```bash
[root@master probe]# kubectl describe pod pod3
Name:         pod3
Namespace:    nsprobe
Priority:     0
Node:         node1/192.168.122.202
Start Time:   Sat, 23 Jul 2022 13:21:42 +0800
Labels:       run=app
Annotations:  cni.projectcalico.org/containerID: be54cb3773b113867bbb9b53964166def9e455d175dbf2af134bf1801342b85a
              cni.projectcalico.org/podIP: 10.244.166.185/32
              cni.projectcalico.org/podIPs: 10.244.166.185/32
Status:       Running
IP:           10.244.166.185
IPs:
  IP:  10.244.166.185
Containers:
  c1:
    Container ID:   docker://1dfc5239cc2d026ef09d8a5edbde7e8647c0823d24387e201bce0806adf2eeee
    Image:          nginx
    Image ID:       docker-pullable://nginx@sha256:0d17b565c37bcbd895e9d92315a05c1c3c9a29f762b011a10c54a66cd53c9b31
    Port:           <none>
    Host Port:      <none>
    State:          Running
      Started:      Sat, 23 Jul 2022 13:21:43 +0800
    Ready:          False
    Restart Count:  0
    Readiness:      exec [cat /tmp/healthy] delay=0s timeout=1s period=10s #success=1 #failure=3
    Environment:    <none>
    Mounts:
      /var/run/secrets/kubernetes.io/serviceaccount from kube-api-access-db7dv (ro)
Conditions:
  Type              Status
  Initialized       True 
  Ready             False 
  ContainersReady   False 
  PodScheduled      True 
Volumes:
  kube-api-access-db7dv:
    Type:                    Projected (a volume that contains injected data from multiple sources)
    TokenExpirationSeconds:  3607
    ConfigMapName:           kube-root-ca.crt
    ConfigMapOptional:       <nil>
    DownwardAPI:             true
QoS Class:                   BestEffort
Node-Selectors:              <none>
Tolerations:                 node.kubernetes.io/not-ready:NoExecute op=Exists for 300s
                             node.kubernetes.io/unreachable:NoExecute op=Exists for 300s
Events:
  Type     Reason     Age               From               Message
  ----     ------     ----              ----               -------
  Normal   Scheduled  6m53s             default-scheduler  Successfully assigned nsprobe/pod3 to node1
  Normal   Pulled     6m50s             kubelet            Container image "nginx" already present on machine
  Normal   Created    6m50s             kubelet            Created container c1
  Normal   Started    6m49s             kubelet            Started container c1
  Warning  Unhealthy  0s (x4 over 30s)  kubelet            Readiness probe failed: cat: /tmp/healthy: No such file or directory
```

#### 再次访问readsvc

```bash
[root@master probe]# curl -s 10.102.65.92
111
[root@master probe]# curl -s 10.102.65.92
222
[root@master probe]# curl -s 10.102.65.92
111
```

可以看到请求不再转发给pod3了

#### 查看pod的状态

```bash
[root@master probe]# kubectl get pods
NAME   READY   STATUS    RESTARTS   AGE
pod1   1/1     Running   0          8m55s
pod2   1/1     Running   0          8m17s
pod3   0/1     Running   0          8m12s
```

虽然svc不再转发请求到pod3,但pod3的容器依然是正常运行的

#### 删除

```bash
[root@master probe]# kubectl delete svc readsvc
service "readsvc" deleted
[root@master probe]# kubectl delete pod pod{1,2,3} --force
warning: Immediate deletion does not wait for confirmation that the running resource has been terminated. The resource may continue to run on the cluster indefinitely.
pod "pod1" force deleted
pod "pod2" force deleted
pod "pod3" force deleted
```
