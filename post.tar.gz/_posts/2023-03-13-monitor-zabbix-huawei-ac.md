---
title: "华为AC的监控数据采集"
tags:
  - Monitor
toc: true
---
 
获取华为AC 用户数量 cpu 内存 供电等信息


```yaml
```
