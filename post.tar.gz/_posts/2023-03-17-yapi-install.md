---
title: "yapi安装"
tags:
  - Application
toc: true
---
 
centos 安装yapi

### 安装nodejs

```bash
curl -sL https://rpm.nodesource.com/setup_12.x | sudo -E bash -
yum install nodejs

node -v
```

#### 安装git

```bash
yun -y install git
```

#### 安装yapi

```bash
mkdir -p /data/app/yapi && cd /data/app/yapi
```

```bash
git clone https://github.com/YMFE/yapi.git vendors --depth=1
```

#### 修改配置

```bash
cp vendors/config_example.json ./config.json
vim ./config.json
```

```json
{
    "port": "8080",
    "adminAccount": "yaliang.yin@****.com",
    "timeout": 120000,
    "db": {
        "connectString": "mongodb://IP:PORT,IP:PORT,IP:PORT/yapi_ops?slaveOk=true",
        "user": "yapi_ops",
        "pass": "yapi_ops"
    },
    "mail": {
        "enable": true,
        "host": "smtp.163.com",
        "port": 465,
        "from": "***@163.com",
        "auth": {
            "user": "***@163.com",
            "pass": "*****"
        }
    },
    "ldapLogin": {
        "enable": true,
        "server": "ldap://****",
        "baseDn": "cn=YAPI,ou=System_User,dc=eeo-inc,dc=com",
        "bindPassword": "*****",
        "searchDn": "ou=Staff,ou=People,dc=eeo-inc,dc=com",
        "searchStandard": "cn"
    }
}
```

#### 安装依赖

```bash
# vendors 目录下
npm install -g cnpm --registry=https://registry.npm.taobao.org
```

#### 初始化

```
npm run install-server
```

```bash
# npm run install-server

> yapi-vendor@1.11.0 install-server /data/app/yapi/vendors
>  node server/install.js

log: mongodb load success...
初始化管理员账号成功,账号名："yaliang.yin@****.com"，密码："****"
```

#### 安装ykit

```bash
npm install --save-dev  --unsafe-perm ykit
```

#### 启动

```bash
  cd vendors
  ykit pack -m
  node server/app.js
```

#### 配置开机启动

```bash
cat > /lib/systemd/system/yapi.service << EOF
[Unit]
Description=yapi
After=network.target remote-fs.target nss-lookup.target

[Service]
Type=forking
ExecStart=/bin/bash -c 'nohup node /data/app/yapi/vendors/server/app.js >/dev/null 2>&1 &'
ExecReload=/bin/bash -c 'kill -9 $(ps -ef|grep app.js|grep -v grep|awk '{print $2}');nohup node /data/app/yapi/vendors/server/app.js >/dev/null 2>&1 &'
ExecStop=/bin/bash -c 'kill -9 $(ps -ef|grep app.js|grep -v grep|awk '{print $2}')'
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
```

```bash
# 服务重载
systemctl daemon-reload

# 设置开机自启动
systemctl enable yapi.service

# 启动服务：
systemctl start yapi.service

# 查看服务当前状态：
systemctl status yapi.service

# 重新启动服务：
systemctl restart yapi.service
```

#### 监控

```bash
# yapi systemctl status
```

访问[zabbix-lab](https://zbx-lab.eeo-inc.com/zabbix.php?name=&evaltype=0&tags%5B0%5D%5Btag%5D=&tags%5B0%5D%5Boperator%5D=0&tags%5B0%5D%5Bvalue%5D=&show_tags=3&tag_name_format=0&tag_priority=&show_details=1&filter_name=&filter_show_counter=0&filter_custom_time=0&sort=name&sortorder=ASC&action=latest.view&hostids%5B%5D=11708&subfilter_tags%5BApplication%5D%5B%5D=TIDB-PD&subfilter_tags%5BApplication%5D%5B%5D=YAPI)查看

访问[grafana](https://gfn-lab.eeo-inc.com/d/aVNhoQ-4k/yapi)查看

#### 报错处理

```bash
#报错
ERROR in Cannot find module 'node-sass'
#解决
npm install --save-dev  --unsafe-perm node-sass
```

```bash
#报错
Error: Cannot find module 'fs-extra'
#解决
npm install --save-dev  --unsafe-perm fs-extra
```

#### 参考

```bash
https://hellosean1025.github.io/yapi/devops/index.html
https://hellosean1025.github.io/yapi/documents/redev.html
https://github.com/YMFE/yapi/releases
```
