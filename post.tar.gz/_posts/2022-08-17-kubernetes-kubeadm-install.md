---
title: "使用kubeadm 安装Kubernetes"
tags:
  - Kubernetes
toc: true
---

介绍使用kubeadm部署集群

### 使用kubeadm 部署集群

#### master上的组件

| 名称               | 作用                                                 |
| ------------------ | ---------------------------------------------------- |
| kubectl            | 命令行工具，用户来创建、删除，都使用此工具           |
| api-server         | 接口,接收用户发送的请求                              |
| scheduler          | 调度器,当用户创建pod时,判断这个pod会调度到哪个worker |
| controller-manager | k8s的大管家,包括监测节点的状态,pod的数目             |

#### worker上的组件

| 名称       | 作用                                                         |
| ---------- | ------------------------------------------------------------ |
| kubelet    | 在包括master上的所有节点上运行,是一个代理,接受master分配的任务,并把节点的信息反馈给master上的api-server |
| kube-proxy | 在包括master在内的所有节点上运行,用于把发送给server的请求转发给后端的Pod,有iptables和ipvs两种模式. |
| calico网络 | 使得节点的pod能够互相通信,集群安装好后,一定要安装它          |

#### 安装集群

#### 建立主机

| 主机名 | IP地址          | 内存需求 | 操作系统 | 角色   |
| ------ | --------------- | -------- | -------- | ------ |
| master | 192.168.122.200 | 4GB      | centos 7 | master |
| node1  | 192.168.122.202 | 4GB      | centos 7 | node   |
| node2  | 192.168.122.203 | 4GB      | centos 7 | node   |

#### 初始化配置

```
virt-install --name k8smaster --ram 4096 --vcpus=4 --os-type=linux --accelerate --cdrom=/home/kvm/CentOS-7.5-x86_64-Minimal-1804.iso  --disk path=/home/kvm/k8smaster.qcow2,size=30,format=qcow2,bus=ide --bridge=virbr0 --vnc --vncport=60011 --vnclisten=0.0.0.0
```

```
virt-install --name k8snode1 --ram 4096 --vcpus=2 --os-type=linux --accelerate --cdrom=/home/kvm/CentOS-7.5-x86_64-Minimal-1804.iso  --disk path=/home/kvm/k8snode1.qcow2,size=30,format=qcow2,bus=ide --bridge=virbr0 --vnc --vncport=60012 --vnclisten=0.0.0.0
```

```
virt-install --name k8snode2 --ram 4096 --vcpus=2 --os-type=linux --accelerate --cdrom=/home/kvm/CentOS-7.5-x86_64-Minimal-1804.iso  --disk path=/home/kvm/k8snode2.qcow2,size=30,format=qcow2,bus=ide --bridge=virbr0 --vnc --vncport=60013 --vnclisten=0.0.0.0
```



```bash
# master node 关闭防火墙  
systemctl stop firewalld 
systemctl disable firewalld 
 
# master node 关闭selinux   
sed -i 's/enforcing/disabled/' /etc/selinux/config  # 永久 
setenforce 0  # 临时 
 
# master node 关闭swap 
swapoff -a  # 临时 
sed -ri 's/.*swap.*/#&/' /etc/fstab    # 永久 
 
# master node 时间同步 
yum install ntpdate -y 
ntpdate time.windows.com

# master node 安装vim wget
yum -y install vim wget 
 
#添加hosts 
cat >> /etc/hosts << EOF 
192.168.122.200 master
192.168.122.202 node1 
192.168.122.203 node2 
EOF 
 
# 将桥接的IPv4流量传递到iptables的链 
cat > /etc/sysctl.d/k8s.conf << EOF 
net.bridge.bridge-nf-call-ip6tables = 1 
net.bridge.bridge-nf-call-iptables = 1 
EOF 

sysctl --system  # 生效 
 
# master 设置 
hostnamectl set-hostname master
# node1 设置
hostnamectl set-hostname node1
# node2 设置
hostnamectl set-hostname node2

# 安装docker
bash <(wget -O- get.docker.com)

#启动并设置开机启动
systemctl daemon-reload
systemctl start docker
systemctl enable docker
systemctl status docker

#修改配置
cat > /etc/docker/daemon.json << EOF
{
  "registry-mirrors": ["https://b9pmyelo.mirror.aliyuncs.com"]
}
EOF

#重启
systemctl restart docker
```

```bash
mv /etc/yum.repos.d/* /tmp/
wget -P /etc/yum.repos.d/ ftp://ftp.rhce.cc/k8s/*
```

```bash
yum install -y kubelet-1.21.1-0 kubeadm-1.21.1-0 kubectl-1.21.1-0 --disableexcludes=kubernetes
```

```bash
systemctl restart kubelet
systemctl enable kubelet
```

此时的kubelet状态

```bash
Active: activating
```

#### 安装master

```bash
[root@master ~]# kubeadm config images list
I0710 19:43:05.808790   15767 version.go:254] remote version is much newer: v1.24.2; falling back to: stable-1.21
k8s.gcr.io/kube-apiserver:v1.21.14
k8s.gcr.io/kube-controller-manager:v1.21.14
k8s.gcr.io/kube-scheduler:v1.21.14
k8s.gcr.io/kube-proxy:v1.21.14
k8s.gcr.io/pause:3.4.1
k8s.gcr.io/etcd:3.4.13-0
k8s.gcr.io/coredns/coredns:v1.8.0
```

```bash
docker pull coredns/coredns:1.8.0
docker tag coredns/coredns:1.8.0 registry.aliyuncs.com/google_containers/coredns/coredns:v1.8.0
docker rmi coredns/coredns:1.8.0
```

```bash
kubeadm init --image-repository=registry.aliyuncs.com/google_containers --kubernetes-version=v1.21.1 --pod-network-cidr=10.244.0.0/16
```

--image-repository 使用阿里云镜像

--pod-network-cidr 制定pod网段

复制kubeconfig文件

```bash
mkdir -p $HOME/.kube
sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
sudo chown $(id -u):$(id -g) $HOME/.kube/config
```

把worker加入集群的命令

```bash
kubeadm join 192.168.122.200:6443 --token jtukiq.4perijhdbyzrtgiz \
        --discovery-token-ca-cert-hash sha256:82d9f6ab3f416feeb452f37fae396439a65173b51ed0dc23c2680ed4ad5f9cc6 
```

忘记这个命令可以使用

```bash
kubeadm token create --print-join-command
```

### 添加及删除worker

在node1和node2上分别执行

```bash
kubeadm join 192.168.122.200:6443 --token jtukiq.4perijhdbyzrtgiz \
        --discovery-token-ca-cert-hash sha256:82d9f6ab3f416feeb452f37fae396439a65173b51ed0dc23c2680ed4ad5f9cc6 
```

返回数据

```bash
[root@node1 ~]# kubeadm join 192.168.122.200:6443 --token jtukiq.4perijhdbyzrtgiz \
>         --discovery-token-ca-cert-hash sha256:82d9f6ab3f416feeb452f37fae396439a65173b51ed0dc23c2680ed4ad5f9cc6
[preflight] Running pre-flight checks
        [WARNING IsDockerSystemdCheck]: detected "cgroupfs" as the Docker cgroup driver. The recommended driver is "systemd". Please follow the guide at https://kubernetes.io/docs/setup/cri/
[preflight] Reading configuration from the cluster...
[preflight] FYI: You can look at this config file with 'kubectl -n kube-system get cm kubeadm-config -o yaml'
[kubelet-start] Writing kubelet configuration to file "/var/lib/kubelet/config.yaml"
[kubelet-start] Writing kubelet environment file with flags to file "/var/lib/kubelet/kubeadm-flags.env"
[kubelet-start] Starting the kubelet
[kubelet-start] Waiting for the kubelet to perform the TLS Bootstrap...

This node has joined the cluster:
* Certificate signing request was sent to apiserver and a response was received.
* The Kubelet was informed of the new secure connection details.

Run 'kubectl get nodes' on the control-plane to see this node join the cluster.

```

在master上查看node节点

```bash
[root@master ~]# kubectl get nodes
NAME     STATUS     ROLES                  AGE     VERSION
master   NotReady   control-plane,master   6m59s   v1.21.1
node1    NotReady   <none>                 14s     v1.21.1
node2    NotReady   <none>                 11s     v1.21.1
```

#### 安装calico

master上执行

```bash
cd /tmp
wget https://docs.projectcalico.org/v3.19/manifests/calico.yaml --no-check-certificate
```

修改

```yaml
            - name: CALICO_IPV4POOL_CIDR
              value: "192.168.0.0/16"
```

为

```yaml
            - name: CALICO_IPV4POOL_CIDR
              value: "10.244.0.0/16"
```

修改

```yaml
apiVersion: policy/v1beat1
```

为

```yaml
apiVersion: policy/v1
```



下载镜像

```
[root@master tmp]# grep image calico.yaml 
          image: docker.io/calico/cni:v3.19.4
          image: docker.io/calico/cni:v3.19.4
          image: docker.io/calico/pod2daemon-flexvol:v3.19.4
          image: docker.io/calico/node:v3.19.4
          image: docker.io/calico/kube-controllers:v3.19.4
```

```bash
for i in calico/cni:v3.19.4 calico/pod2daemon-flexvol:v3.19.4  calico/node:v3.19.4 calico/kube-controllers:v3.19.4 ;do docker pull $i;done
```

安装calico

```bash
kubectl apply -f calico.yaml
```

查看节点

```bash
[root@master tmp]# kubectl get nodes
NAME     STATUS   ROLES                  AGE   VERSION
master   Ready    control-plane,master   17m   v1.21.1
node1    Ready    <none>                 10m   v1.21.1
node2    Ready    <none>                 10m   v1.21.1
```

#### 设置tab补全

```bash
vim /etc/profile
source <(kubectl completion bash)
```

```
source /etc/profile
```

#### 删除节点

设置维护模式

```bash
kubectl drain node1 --delete-local-data --force --ignore-daemonsets
```

删除节点

```bash
[root@master ~]# kubectl delete node node1
node "node1" deleted
```

再次加入节点

在node1上执行

```bash
[root@node1 ~]# kubeadm reset
[reset] WARNING: Changes made to this host by 'kubeadm init' or 'kubeadm join' will be reverted.
[reset] Are you sure you want to proceed? [y/N]: y
[preflight] Running pre-flight checks
W0710 20:41:03.391549    4728 removeetcdmember.go:79] [reset] No kubeadm config, using etcd pod spec to get data directory
[reset] No etcd config found. Assuming external etcd
[reset] Please, manually reset etcd to prevent further issues
[reset] Stopping the kubelet service
[reset] Unmounting mounted directories in "/var/lib/kubelet"
[reset] Deleting contents of config directories: [/etc/kubernetes/manifests /etc/kubernetes/pki]
[reset] Deleting files: [/etc/kubernetes/admin.conf /etc/kubernetes/kubelet.conf /etc/kubernetes/bootstrap-kubelet.conf /etc/kubernetes/controller-manager.conf /etc/kubernetes/scheduler.conf]
[reset] Deleting contents of stateful directories: [/var/lib/kubelet /var/lib/dockershim /var/run/kubernetes /var/lib/cni]

The reset process does not clean CNI configuration. To do so, you must remove /etc/cni/net.d

The reset process does not reset or clean up iptables rules or IPVS tables.
If you wish to reset iptables, you must do so manually by using the "iptables" command.

If your cluster was setup to utilize IPVS, run ipvsadm --clear (or similar)
to reset your system's IPVS tables.

The reset process does not clean your kubeconfig files and you must remove them manually.
Please, check the contents of the $HOME/.kube/config file.
```

重新加入集群

```bash
[root@node1 ~]# kubeadm join 192.168.122.200:6443 --token jtukiq.4perijhdbyzrtgiz \
>         --discovery-token-ca-cert-hash sha256:82d9f6ab3f416feeb452f37fae396439a65173b51ed0dc23c2680ed4ad5f9cc6
```

出错处理

手动删除 /etc/kubernetes/pki/和/var/lib/kubelet/两个目录

#### 常用命令

查看集群信息

```bash
[root@master ~]# kubectl cluster-info
Kubernetes control plane is running at https://192.168.122.200:6443
CoreDNS is running at https://192.168.122.200:6443/api/v1/namespaces/kube-system/services/kube-dns:dns/proxy

To further debug and diagnose cluster problems, use 'kubectl cluster-info dump'.
```

查看版本

```bash
[root@master ~]# kubectl version
Client Version: version.Info{Major:"1", Minor:"21", GitVersion:"v1.21.1", GitCommit:"5e58841cce77d4bc13713ad2b91fa0d961e69192", GitTreeState:"clean", BuildDate:"2021-05-12T14:18:45Z", GoVersion:"go1.16.4", Compiler:"gc", Platform:"linux/amd64"}
Server Version: version.Info{Major:"1", Minor:"21", GitVersion:"v1.21.1", GitCommit:"5e58841cce77d4bc13713ad2b91fa0d961e69192", GitTreeState:"clean", BuildDate:"2021-05-12T14:12:29Z", GoVersion:"go1.16.4", Compiler:"gc", Platform:"linux/amd64"}
```

```bash
[root@master ~]# kubectl version --short
Client Version: v1.21.1
Server Version: v1.21.1
```

查看支持的api-version

```bash
[root@master ~]# kubectl api-versions
admissionregistration.k8s.io/v1
admissionregistration.k8s.io/v1beta1
apiextensions.k8s.io/v1
apiextensions.k8s.io/v1beta1
apiregistration.k8s.io/v1
apiregistration.k8s.io/v1beta1
apps/v1
authentication.k8s.io/v1
authentication.k8s.io/v1beta1
authorization.k8s.io/v1
authorization.k8s.io/v1beta1
autoscaling/v1
autoscaling/v2beta1
autoscaling/v2beta2
batch/v1
batch/v1beta1
certificates.k8s.io/v1
certificates.k8s.io/v1beta1
coordination.k8s.io/v1
coordination.k8s.io/v1beta1
crd.projectcalico.org/v1
discovery.k8s.io/v1
discovery.k8s.io/v1beta1
events.k8s.io/v1
events.k8s.io/v1beta1
extensions/v1beta1
flowcontrol.apiserver.k8s.io/v1beta1
networking.k8s.io/v1
networking.k8s.io/v1beta1
node.k8s.io/v1
node.k8s.io/v1beta1
policy/v1
policy/v1beta1
rbac.authorization.k8s.io/v1
rbac.authorization.k8s.io/v1beta1
scheduling.k8s.io/v1
scheduling.k8s.io/v1beta1
storage.k8s.io/v1
storage.k8s.io/v1beta1
v1
```



### 查看pod及节点的负载

如果需要查看kubernetes集群每个节点及每个pod的CPU负载、内存负载、需要安装metric-serer

所有节点安装

```bash
docker pull mirrorgooglecontainers/metrics-server-amd64:v0.3.6
```

```bash
docker tag mirrorgooglecontainers/metrics-server-amd64:v0.3.6 k8s.gcr.io/metrics-server-amd64:v0.3.6
```

```bash
docker rmi mirrorgooglecontainers/metrics-server-amd64:v0.3.6
```

master

```
cd /tmp
curl -Ls https://api.github.com/repos/kubernetes-sigs/metrics-server/tarball/v0.3.6 -o metrics-server-v0.3.6.tar.gz
```

```bash
tar zxvfp metrics-server-v0.3.6.tar.gz
```

```bash
cd kubernetes-sigs-metrics-server-d1f4f6f/deploy/1.8+/
```

修改

```bash
[root@node2 1.8+]# cat metrics-server-deployment.yaml 
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: metrics-server
  namespace: kube-system
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: metrics-server
  namespace: kube-system
  labels:
    k8s-app: metrics-server
spec:
  selector:
    matchLabels:
      k8s-app: metrics-server
  template:
    metadata:
      name: metrics-server
      labels:
        k8s-app: metrics-server
    spec:
      serviceAccountName: metrics-server
      volumes:
      # mount in tmp so we can safely use from-scratch images and/or read-only containers
      - name: tmp-dir
        emptyDir: {}
      containers:
      - name: metrics-server
        image: k8s.gcr.io/metrics-server-amd64:v0.3.6
        imagePullPolicy: IfNotPresent
        command:
        - /metrics-server
        - --metric-resolution=30s
        - --kubelet-insecure-tls
        - --kubelet-preferred-address-types=InternalIP
        volumeMounts:
```

运行当前目录

```bash
[root@master 1.8+]# kubectl apply -f .
clusterrole.rbac.authorization.k8s.io/system:aggregated-metrics-reader created
Warning: rbac.authorization.k8s.io/v1beta1 ClusterRoleBinding is deprecated in v1.17+, unavailable in v1.22+; use rbac.authorization.k8s.io/v1 ClusterRoleBinding
clusterrolebinding.rbac.authorization.k8s.io/metrics-server:system:auth-delegator created
Warning: rbac.authorization.k8s.io/v1beta1 RoleBinding is deprecated in v1.17+, unavailable in v1.22+; use rbac.authorization.k8s.io/v1 RoleBinding
rolebinding.rbac.authorization.k8s.io/metrics-server-auth-reader created
Warning: apiregistration.k8s.io/v1beta1 APIService is deprecated in v1.19+, unavailable in v1.22+; use apiregistration.k8s.io/v1 APIService
apiservice.apiregistration.k8s.io/v1beta1.metrics.k8s.io created
serviceaccount/metrics-server created
deployment.apps/metrics-server created
service/metrics-server created
clusterrole.rbac.authorization.k8s.io/system:metrics-server created
clusterrolebinding.rbac.authorization.k8s.io/system:metrics-server created
```

查看pod的状态

```bash
[root@master 1.8+]# kubectl get pods -n kube-system | grep metric
metrics-server-6b7f4dfdcb-xfpl4            1/1     Running   0          59s
```

查看节点负载

```bash
[root@master 1.8+]# kubectl top nodes --use-protocol-buffers
NAME     CPU(cores)   CPU%   MEMORY(bytes)   MEMORY%   
master   245m         6%     1270Mi          32%       
node1    88m          4%     579Mi           15%       
node2    106m         5%     638Mi           16%    
```

查看metrics-server的IP地址

```bash
[root@master 1.8+]# kubectl get pods -n kube-system -o wide 
NAME                                       READY   STATUS    RESTARTS   AGE    IP                NODE     NOMINATED NODE   READINESS GATES
calico-kube-controllers-7cc8dd57d9-mwx5q   1/1     Running   1          92m    10.244.104.2      node2    <none>           <none>
calico-node-54njj                          1/1     Running   1          92m    192.168.122.203   node2    <none>           <none>
calico-node-559jn                          1/1     Running   1          92m    192.168.122.200   master   <none>           <none>
calico-node-w6rwp                          1/1     Running   0          76m    192.168.122.202   node1    <none>           <none>
coredns-545d6fc579-j9f7q                   1/1     Running   1          109m   10.244.219.65     master   <none>           <none>
coredns-545d6fc579-t7st8                   1/1     Running   1          109m   10.244.219.66     master   <none>           <none>
etcd-master                                1/1     Running   1          109m   192.168.122.200   master   <none>           <none>
kube-apiserver-master                      1/1     Running   1          109m   192.168.122.200   master   <none>           <none>
kube-controller-manager-master             1/1     Running   1          109m   192.168.122.200   master   <none>           <none>
kube-proxy-j28gq                           1/1     Running   1          109m   192.168.122.200   master   <none>           <none>
kube-proxy-jgsxd                           1/1     Running   1          102m   192.168.122.203   node2    <none>           <none>
kube-proxy-qrf8c                           1/1     Running   0          76m    192.168.122.202   node1    <none>           <none>
kube-scheduler-master                      1/1     Running   1          109m   192.168.122.200   master   <none>           <none>
metrics-server-6b7f4dfdcb-xfpl4            1/1     Running   0          3m     10.244.166.129    node1    <none>           <none>
```



### 了解及管理命名空间

#### 管理命令空间

查看

```bash
[root@master 1.8+]# kubectl get ns
NAME              STATUS   AGE
default           Active   112m
kube-node-lease   Active   112m
kube-public       Active   112m
kube-system       Active   112m
```

- `default` 没有指明使用其它名字空间的对象所使用的默认名字空间
- `kube-system` Kubernetes 系统创建对象所使用的名字空间
- `kube-public` 这个名字空间是自动创建的，所有用户（包括未经过身份验证的用户）都可以读取它。 这个名字空间主要用于集群使用，以防某些资源在整个集群中应该是可见和可读的。 这个名字空间的公共方面只是一种约定，而不是要求。
- `kube-node-lease` 此名字空间用于与各个节点相关的 [租约（Lease）](https://kubernetes.io/docs/reference/kubernetes-api/cluster-resources/lease-v1/)对象。 节点租期允许 kubelet 发送[心跳](https://kubernetes.io/zh-cn/docs/concepts/architecture/nodes/#heartbeats)，由此控制面能够检测到节点故障

创建一个命名空间

```bash
[root@master tmp]# kubectl create ns ns1
namespace/ns1 created
```

```bash
[root@master tmp]# kubectl get ns
NAME              STATUS   AGE
default           Active   114m
kube-node-lease   Active   114m
kube-public       Active   114m
kube-system       Active   114m
ns1               Active   17s
```

删除命名空间

```bash
[root@master tmp]# kubectl delete ns ns1
namespace "ns1" deleted
```
