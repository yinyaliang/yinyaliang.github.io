---
title: "php 配置fcgi 获取监控数据"
tags:
  - Monitor
toc: true
---
 
规避Nginx,通过fcgi接口取值

### 安装

 在 centos上可以通过下面的方式安装

```bash
yum --enablerepo=epel install fcgi
```

FasdCGI在命令行访问需要通过配置环境变量,连接到一个FastCGI接口,需要有--bind和--conect参数:

```
cgi-fcgi -bind -connect 127.0.0.1:端口
```

### 配置

php-fpm的conf 需要配置 

```bash
pm.status_path = /status
listen = 61185
listen.allowed_clients = 127.0.0.1
```

### 测试

```bash
SCRIPT_NAME=/status SCRIPT_FILENAME=/status REQUEST_METHOD=GET QUERY_STRING=xml cgi-fcgi -bind -connect 127.0.0.1:61185
Expires: Thu, 01 Jan 1970 00:00:00 GMT
Cache-Control: no-cache, no-store, must-revalidate, max-age=0
Content-Type: text/xml

<?xml version="1.0" ?>
<status>
<pool>www</pool>
<process-manager>dynamic</process-manager>
<start-time>1661607804</start-time>
<start-since>135</start-since>
<accepted-conn>21</accepted-conn>
<listen-queue>0</listen-queue>
<max-listen-queue>0</max-listen-queue>
<listen-queue-len>128</listen-queue-len>
<idle-processes>5</idle-processes>
<active-processes>1</active-processes>
<total-processes>6</total-processes>
<max-active-processes>1</max-active-processes>
<max-children-reached>0</max-children-reached>
<slow-requests>0</slow-requests>
</status>
```

以上返回值表示正常获取到值,参数还可以支持 json,xml,html

### 参数说明


* pool – 套接字的池的名称，在php-fpm 配置中定义
* process manager: 进程管理器用来控制子进程数量的方法,可以通过pm来配置,有static, dynamic,ondemand
* start time: 服务启动时间相对应的日期,reload后会更新 
* start since: 服务运行时长 
* accepted conn: 连接池已接受的传入请求数,当一个连接被接受时，它会从监听队列中移除(实时显示)
* listen queue: 当前已启动但尚未接受的连接数。如果此值非零，则通常意味着所有可用的服务器进程当前都处于忙碌状态，并且没有可用于服务下一个请求的进程.通过pm.max_children调整 
* max listen queue: 服务启动后listen queue 的最大值 
* listen queue len: 排队的连接数的上限,通过listen.backlog 配置,这个值也会受到 net.core.somaxconn 的限制 
* idle processes: 处于“等待处理”状态的进程数量。当pm的值为dynamic的时候,这个值会在 pm.min_spare_servers 和 pm.max_spare_servers 值之间 
* active processes: 活跃进程数量,最小值为1 
* total processes: 空闲进程+活动进程的和。如果pm的值为static 的，这个数字显示 pm.max_children 的值
* max active processes: php-fpm 服务启动后，*active processes* 的历史最高值。不会超过 pm.max_children 
* max children reached: php-fpm 服务器启动后, 到达pm.max_children 的次数,只有pm为 dynamic才有效


### 排错

如果上面的命令返回空,将listen.allowed_clients的127.0.0.1放在第一位
