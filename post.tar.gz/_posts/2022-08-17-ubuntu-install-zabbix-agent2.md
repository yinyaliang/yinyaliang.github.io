#### 安装依赖

```bash
apt install gcc
apt install libpcre3 libpcre3-dev
apt-get install zlib1g-dev
apt install make
```

#### 安装golang

```
https://go.dev/doc/install

下载异常挂在代理:
go env -w GOPROXY=https://mirrors.aliyun.com/goproxy/,direct
```

#### 创建组和用户

```bash
groupadd -g 2210 zabbix
useradd -u 2210 zabbix -g zabbix
```

#### 创建目录及赋权

```bash
[ ! -d /data/scripts/oss/zabbix ] && mkdir -p /data/scripts/oss/zabbix
[ ! -d /data/logs/oss/zabbix ] && mkdir -p /data/logs/oss/zabbix
[ ! -d /data/config/oss/zabbix ] && mkdir -p /data/config/oss/zabbix
[ ! -d /data/run/oss/zabbix ] && mkdir -p /data/run/oss/zabbix
    
chown zabbix:zabbix /data/config/oss/zabbix/* -Rf
chown zabbix:zabbix /data/logs/oss/zabbix/* -Rf
chown zabbix:zabbix /data/scripts/oss/zabbix/* -Rf
chown zabbix:zabbix /data/run/oss/zabbix/* -Rf
    
chown zabbix: -R /data/logs/oss/zabbix/
chown zabbix: -R /data/run/oss/zabbix
```

#### 下载源文件

```bash
cd /tmp
wget https://cdn.zabbix.com/zabbix/sources/stable/6.0/zabbix-6.0.0.tar.gz
tar zxvf zabbix-6.0.0.tar.gz
cd zabbix-6.0.0/
```

#### 编译安装

```bash
./configure --prefix=/usr/local/zabbix-6.0.0 --enable-agent --enable-agent2 
make && make install 
```

#### 目录软链

```
unlink /usr/local/zabbix
ln -s /usr/local/zabbix-6.0.0 /usr/local/zabbix
ln -s /data/scripts/oss/zabbix /usr/local/zabbix/scripts
ln -s /usr/local/zabbix/sbin/zabbix_agentd /usr/local/bin/zabbix_agentd
ln -s /usr/local/zabbix/sbin/zabbix_agent2 /usr/local/bin/zabbix_agent2
    
cd /usr/local/zabbix
mv etc/* /data/config/oss/zabbix/
rm -rf /usr/local/zabbix/
ln -s /data/config/oss/zabbix/ /usr/local/zabbix/etc
```

#### Zabbix2 配置文件

```
PidFile=/data/run/oss/zabbix/zabbix_agent2.pid
LogFile=/data/logs/oss/zabbix/zabbix_agent2.log
Server=10.0.2.39,10.0.2.40
ListenPort=31350
ListenIP=10.252.4.114
ServerActive=10.0.2.39:31351;10.0.2.40:31351
Hostname=dev-aitraincv2 
Timeout=3
Include=/data/config/oss/zabbix/zabbix_agentd.conf.d/*.conf
ControlSocket=/data/run/oss/zabbix/agent.sock
```

systemd配置

```
cat > /etc/systemd/system/zabbix_agent2.service << EOF
[Unit]
Description=Zabbix Agent2
After=syslog.target
After=network.target

[Service]
#Type=forking
User=root
Group=root
Environment="CONFFILE=/data/config/oss/zabbix/zabbix_agent2.conf"
ExecStart=/usr/local/bin/zabbix_agent2 -c $CONFFILE 
PIDFile=/data/run/oss/zabbix/agent.sock
KillSignal=SIGQUIT

[Install]
WantedBy=multi-user.target
EOF
```

```
# 服务重载
systemctl daemon-reload
```

```
# 设置开机自启动
systemctl enable zabbix_agent2.service
```

```
# 启动服务：
systemctl start zabbix_agent2.service
```

```
# 查看服务当前状态：
systemctl status zabbix_agent2.service
```

```
# 重新启动服务：
systemctl restart zabbix_agent2.service
```
