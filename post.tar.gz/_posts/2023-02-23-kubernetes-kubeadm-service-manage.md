---
title: "服务管理"
tags:
  - Kubernetes
toc: true
---

## 创建及删除service

service 通过 kube-proxy 实现 服务转发到后端的pod.

```bash
[root@master ds]# mkdir svc && cd svc
```

#### 创建空间

```bash
[root@master svc]# kubectl create ns nssvc
namespace/nssvc created
[root@master svc]# kubens nssvc
Context "kubernetes-admin@kubernetes" modified.
Active namespace is "nssvc".
```

#### 创建一个deployment的yaml文件

```bash
[root@master svc]# kubectl create deployment web --image=nginx --dry-run=client -o yaml > web1.yaml
```

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  creationTimestamp: null
  labels:
    app1: web1
  name: web
spec:
  replicas: 1
  selector:
    matchLabels:
      app1: web1
  strategy: {}
  template:
    metadata:
      creationTimestamp: null
      labels:
        app1: web1
    spec:
      containers:
      - image: nginx
        name: nginx
        resources: {}
status: {}
   
```

- deployment 创建出来的pod都具有 app1=web1这个标签. template这里

- deployment通过app1=web1这个标签来定位pod . selector这里

- deployment自身的标签是app=web

  

  #### 创建

```bash
[root@master svc]# kubectl apply -f web1.yaml 
deployment.apps/web created
```

#### 查看

```bash
[root@master svc]# kubectl get deploy -o wide
NAME   READY   UP-TO-DATE   AVAILABLE   AGE   CONTAINERS   IMAGES   SELECTOR
web    1/1     1            1           43s   nginx        nginx    app1=web1
```

#### 创建svc

svc可以基于deployment来创建

​        kubectl expose deployment deploy的名字 > --name=服务名 --port=端口 --target-port=端口

  

也可以基于pod来创建

​         kubectl expose pod pod的名字 --name=服务名 --port=端口 --target-port=端口



--name 不指定默认使用deployment或者pod的名字

--port 指服务的端口,可以随意指定

--target-port 指后端运行的端口

```bash
[root@master svc]# kubectl expose deployment web --name=svc1 --port=80 --target-port=80
service/svc1 exposed
```

```bash
[root@master svc]# kubectl get svc -o wide
NAME   TYPE        CLUSTER-IP     EXTERNAL-IP   PORT(S)   AGE   SELECTOR
svc1   ClusterIP   10.106.29.73   <none>        80/TCP    18s   app1=web1
```

svc1通过app1=web1来定位pod,所以 这个svc虽然是基于depolyment来创建,其实定位的是此deployment所管理的pod

#### 查看

```bash
[root@master svc]# kubectl describe svc svc1
Name:              svc1
Namespace:         nssvc
Labels:            app=web
Annotations:       <none>
Selector:          app1=web1
Type:              ClusterIP
IP Family Policy:  SingleStack
IP Families:       IPv4
IP:                10.106.29.73
IPs:               10.106.29.73
Port:              <unset>  80/TCP
TargetPort:        80/TCP
Endpoints:         10.244.166.142:80
Session Affinity:  None
Events:            <none>
```

Endpoints是后端的IP

#### 扩展deployment

```bash
[root@master svc]# kubectl scale deploy web --replicas=3
deployment.apps/web scaled
```

```bash
[root@master svc]# kubectl get pods -o wide 
NAME                   READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
web-79974f444d-2g75d   1/1     Running   0          35s   10.244.166.144   node1   <none>           <none>
web-79974f444d-gzqz2   1/1     Running   0          35s   10.244.166.141   node1   <none>           <none>
web-79974f444d-xznvt   1/1     Running   0          10m   10.244.166.142   node1   <none>           <none>
```

#### 再次查看

```bash
[root@master svc]# kubectl describe svc svc1
Name:              svc1
Namespace:         nssvc
Labels:            app=web
Annotations:       <none>
Selector:          app1=web1
Type:              ClusterIP
IP Family Policy:  SingleStack
IP Families:       IPv4
IP:                10.106.29.73
IPs:               10.106.29.73
Port:              <unset>  80/TCP
TargetPort:        80/TCP
Endpoints:         10.244.166.141:80,10.244.166.142:80,10.244.166.144:80
Session Affinity:  None
Events:            <none>
```

#### 删除svc

- kubectl delete svc 名字
- kubectl delete -f svc的.yaml文件

```bash
[root@master svc]# kubectl delete svc svc1
service "svc1" deleted
```

#### pod多个标签

可以指定根据哪个标签来定位

kubectl expose pod web-xxx --name=scv1 --selector=app1=web1 --port=80 --target-port=80

### 验证负载均衡

#### 修改pod

```bash
[root@master svc]# kubectl exec -ti web-79974f444d-2g75d -- bash
root@web-79974f444d-2g75d:/# echo 111 > /usr/share/nginx/html/index.html 
```

```bash
[root@master svc]# kubectl exec -ti web-79974f444d-gzqz2 -- bash
root@web-79974f444d-gzqz2:/# echo 222 > /usr/share/nginx/html/index.html 
```

```bash
[root@master svc]# kubectl exec -ti web-79974f444d-xznvt -- bash
root@web-79974f444d-xznvt:/# echo 333 > /usr/share/nginx/html/index.html 
```

#### 创建svc

```bash
[root@master svc]# kubectl expose deployment web --name=svc1 --port=80 --target-port=80
service/svc1 exposed
```

#### 查看svc的IP

```bash
[root@master svc]# kubectl get svc
NAME   TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)   AGE
svc1   ClusterIP   10.103.10.106   <none>        80/TCP    18s
```

#### 测试

```bash
[root@master svc]# curl -s 10.103.10.106
111
[root@master svc]# curl -s 10.103.10.106
333
[root@master svc]# curl -s 10.103.10.106
333
[root@master svc]# curl -s 10.103.10.106
333
[root@master svc]# curl -s 10.103.10.106
222
```

#### 删除

```bash
[root@master svc]# kubectl delete svc svc1
service "svc1" deleted
```



#### yaml创建service

```bash
[root@master svc]# kubectl expose deployment web --name=svc1 --port=80 --target-port=80 --dry-run=client -o yaml > svc1.yaml
```

```bash
apiVersion: v1
kind: Service
metadata:
  creationTimestamp: null
  labels:
    app: web
  name: svc1
spec:
  ports:
  - port: 80
    protocol: TCP
    targetPort: 80
  selector:
    app1: web1
status:
  loadBalancer: {}
```

```bash
[root@master svc]# kubectl apply -f svc1.yaml 
service/svc1 created
[root@master svc]# kubectl get svc
NAME   TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)   AGE
svc1   ClusterIP   10.110.221.154   <none>        80/TCP    8s
```

```bash
[root@master svc]# kubectl delete deployment web
deployment.apps "web" deleted
[root@master svc]# kubectl delete svc svc1
service "svc1" deleted
```

### 服务发现

- 通过clusterIP发现svc
- 通过变量发现svc
- 通过dns发现svc

#### 环境准备

#### mysql

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: mysql
  labels:
    name: mysql
spec:
  containers:
  - image: mysql:8
    imagePullPolicy: IfNotPresent
    name: mysql
    env:
    - name: MYSQL_ROOT_PASSWORD
      value: redhat
    - name: MYSQL_USER
      value: tom
    - name: MYSQL_PASSWORD
      value: redhat
    - name: MYSQL_DATABASE
      value: blog
    ports:
    - name: mysql
      containerPort: 3306
```

```bash
[root@master svc]# kubectl get pods -o wide
NAME    READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
mysql   1/1     Running   0          32s   10.244.166.140   node1   <none>           <none>
```

为mysql创建svc

```bash
[root@master svc]# kubectl expose pod mysql --name=dbsvc --port=3306
service/dbsvc exposed
```

#### wordpress

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: wordpress
  labels:
    name: wordpress
spec:
  containers:
  - image: wordpress:latest
    imagePullPolicy: IfNotPresent
    name: wordpress
    env:
      - name: WORDPRESS_DB_USE
        value: root
      - name: WORDPRESS_DB_PASSWORD
        value: redhat
      - name: WORDPRESS_DB_NAME
        value: blog
      - name: WORDPRESS_DB_HOST
        value: 
    ports:
    - name: wordpress
      containerPort: 80
```

mysql的主机地址没有填写

#### 通过clusterip的方式访问

获取mysql的svc ip地址

```bash
[root@master svc]# kubectl get svc
NAME    TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)    AGE
dbsvc   ClusterIP   10.106.124.116   <none>        3306/TCP   50m
```

 修改wordpress的地址

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: wordpress
  labels:
    name: wordpress
spec:
  containers:
  - image: wordpress:latest
    imagePullPolicy: IfNotPresent
    name: wordpress
    env:
      - name: WORDPRESS_DB_USE
        value: root
      - name: WORDPRESS_DB_PASSWORD
        value: redhat
      - name: WORDPRESS_DB_NAME
        value: blog
      - name: WORDPRESS_DB_HOST
        value: 10.106.124.116
    ports:
    - name: wordpress
      containerPort: 80
```

 创建wordpress

```bash
[root@master svc]# kubectl apply -f pod-wordpress.yaml 
pod/wordpress created
```

 查看状态

```bash
[root@master svc]# kubectl get pods -o wide
NAME        READY   STATUS    RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
mysql       1/1     Running   0          79m   10.244.166.140   node1   <none>           <none>
wordpress   1/1     Running   0          21m   10.244.166.147   node1   <none>           <none>
```

 测试

````
firefox &
````

#### 通过变量

同一个命名空间内,如果先存在了A服务,则在创建B pod的时候,B pod会自动学习到A服务的变量，标记服务IP和端口的格式如下

```
A 服务名_SERVICE_HOST
B 服务名_SERVICE_PORT
```

**服务名要大写**

在B pod的yaml文件里要引用关于A的变量时候,用$(变量名)

```bash
root@wordpress:/var/www/html# env | grep DB
DBSVC_PORT=tcp://10.106.124.116:3306
DBSVC_PORT_3306_TCP_ADDR=10.106.124.116
DBSVC_PORT_3306_TCP=tcp://10.106.124.116:3306
DBSVC_PORT_3306_TCP_PORT=3306
WORDPRESS_DB_USE=root
WORDPRESS_DB_HOST=10.106.124.116
DBSVC_SERVICE_PORT=3306
WORDPRESS_DB_PASSWORD=redhat
DBSVC_SERVICE_HOST=10.106.124.116
WORDPRESS_DB_NAME=blod
DBSVC_PORT_3306_TCP_PROTO=tcp
```

所以在wordpress的yaml文件中，可以直接使用变量的方式获取dbsvc的IP

删除wordpress的pod

```bash
[root@master svc]# kubectl delete pod wordpress --force
warning: Immediate deletion does not wait for confirmation that the running resource has been terminated. The resource may continue to run on the cluster indefinitely.
pod "wordpress" force deleted
```

创建

```bash
[root@master svc]# kubectl apply -f pod-wordpress.yaml 
pod/wordpress created
```

删除

```bash
[root@master svc]# kubectl delete pod wordpress
pod "wordpress" deleted
```

#### 通过DNS

kubernetes安装后 有一个coredns的deplyment

```bash
[root@master svc]# kubectl get pods -n kube-system| grep dns
coredns-545d6fc579-j9f7q                   1/1     Running   7          12d
coredns-545d6fc579-t7st8                   1/1     Running   7          12d
```

```bash
[root@master svc]# kubectl get svc -n kube-system
NAME             TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)                  AGE
kube-dns         ClusterIP   10.96.0.10       <none>        53/UDP,53/TCP,9153/TCP   12d
```

在k8s中,只要创建了服务,都会自动到coreDNS里去注册,这样coreDNS会知道每个服务的IP地址

同一个命名空间,可以通过服务名来访问

临时创建一个pod测试

```bash
[root@master svc]# kubectl run busybox --rm -ti --image=busybox sh
If you don't see a command prompt, try pressing enter.
/ # ping dbsvc
PING dbsvc (10.106.124.116): 56 data bytes
```

可以看到已经解析了

如果访问其它命名空间的服务使用

```bash
服务名.命名空间
```

修改wordpress的配置

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: wordpress
  labels:
    name: wordpress
spec:
  containers:
  - image: wordpress:latest
    imagePullPolicy: IfNotPresent
    name: wordpress
    env:
      - name: WORDPRESS_DB_USE
        value: root
      - name: WORDPRESS_DB_PASSWORD
        value: redhat
      - name: WORDPRESS_DB_NAME
        value: blog
      - name: WORDPRESS_DB_HOST
        value: dbsvc
    ports:
    - name: wordpress
      containerPort: 80
```

```bash
[root@master svc]# kubectl apply -f pod-wordpress.yaml 
pod/wordpress created
```

查看

```bash
[root@master svc]# kubectl get pods -o wide 
NAME        READY   STATUS    RESTARTS   AGE    IP               NODE    NOMINATED NODE   READINESS GATES
mysql       1/1     Running   0          104m   10.244.166.140   node1   <none>           <none>
wordpress   1/1     Running   0          31s    10.244.166.149   node1   <none>           <none>
```



### 通过NodePort发布服务

把服务的端口映射到物理机器(kubernetes集群中所有节点)的某端口,以后访问服务器该端口的时候,请求就会转发到该svc上

```bash
[root@master svc]# kubectl get pods
NAME        READY   STATUS    RESTARTS   AGE
mysql       1/1     Running   0          121m
wordpress   1/1     Running   0          17m
```

#### 为此pod创建类型为NodePort类型的service,名字为blog

```bash
[root@master svc]# kubectl expose pod wordpress --name=blog --port=80 --type=NodePort 
service/blog exposed
```

查看服务

```bash
[root@master svc]# kubectl get svc
NAME    TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)        AGE
blog    NodePort    10.110.246.12    <none>        80:31285/TCP   5m19s
dbsvc   ClusterIP   10.106.124.116   <none>        3306/TCP       126m
```

```bash
[root@master svc]# kubectl get node -o wide
NAME     STATUS   ROLES                  AGE   VERSION   INTERNAL-IP       EXTERNAL-IP   OS-IMAGE                KERNEL-VERSION          CONTAINER-RUNTIME
master   Ready    control-plane,master   12d   v1.21.1   192.168.122.200   <none>        CentOS Linux 7 (Core)   3.10.0-862.el7.x86_64   docker://20.10.17
node1    Ready    node1                  12d   v1.21.1   192.168.122.202   <none>        CentOS Linux 7 (Core)   3.10.0-862.el7.x86_64   docker://20.10.17
node2    Ready    node2                  12d   v1.21.1   192.168.122.203   <none>        CentOS Linux 7 (Core)   3.10.0-862.el7.x86_64   docker://20.10.17
```

通过任一node的IP+ 31285端口都可以访问这个服务

```
http://192.168.122.202:31285/
```

删除以上pod和svc

```bash
[root@master svc]# kubectl delete pod mysql
pod "mysql" deleted
[root@master svc]# kubectl delete pod wordpress -force
error: the path "orce" does not exist
[root@master svc]# kubectl delete pod wordpress --force
warning: Immediate deletion does not wait for confirmation that the running resource has been terminated. The resource may continue to run on the cluster indefinitely.
pod "wordpress" force deleted
[root@master svc]# kubectl get svc
NAME    TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)        AGE
blog    NodePort    10.110.246.12    <none>        80:31285/TCP   32m
dbsvc   ClusterIP   10.106.124.116   <none>        3306/TCP       153m
[root@master svc]# kubectl delete svc blog
service "blog" deleted
[root@master svc]# kubectl delete svc dbsvc
service "dbsvc" deleted
```



### 通过loadbalancer

#### 创建命名空间

```bash
[root@master ~]# kubectl create ns metallb-system
namespace/metallb-system created
```

#### 创建secret

```bash
[root@master ~]# kubectl create secret generic -n metallb-system memberlist --from-literal=secretkey="$(openssl rand -base64 128)"
secret/memberlist created
```

#### 下载部署metallb

```bash
wget https://raw.githubusercontent.com/metallb/metallb/v0.9.5/manifests/metallb.yaml
```

```yaml
imagePullPolicy: IfNotPresent
```

#### 安装

```bash
[root@master ~]# kubectl apply -f metallb.yaml 
Warning: policy/v1beta1 PodSecurityPolicy is deprecated in v1.21+, unavailable in v1.25+
podsecuritypolicy.policy/controller configured
podsecuritypolicy.policy/speaker configured
serviceaccount/controller unchanged
serviceaccount/speaker unchanged
clusterrole.rbac.authorization.k8s.io/metallb-system:controller unchanged
clusterrole.rbac.authorization.k8s.io/metallb-system:speaker unchanged
role.rbac.authorization.k8s.io/config-watcher unchanged
role.rbac.authorization.k8s.io/pod-lister unchanged
clusterrolebinding.rbac.authorization.k8s.io/metallb-system:controller unchanged
clusterrolebinding.rbac.authorization.k8s.io/metallb-system:speaker unchanged
rolebinding.rbac.authorization.k8s.io/config-watcher unchanged
rolebinding.rbac.authorization.k8s.io/pod-lister unchanged
daemonset.apps/speaker unchanged
deployment.apps/controller unchanged
```

#### 查看运行状态

```bash
[root@master ~]# kubectl get pods -n metallb-system
NAME                         READY   STATUS    RESTARTS   AGE
controller-b4df945f8-d9kc4   1/1     Running   0          2m17s
speaker-dwwhj                1/1     Running   0          2m17s
speaker-gnlkz                1/1     Running   0          2m17s
speaker-jdv9v                1/1     Running   0          2m17s
```

#### 创建地址池

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: metallb-system
  name: config
data:
  config: |
    address-pools:
    - name: default
      protocol: layer2
      addresses:
      - 192.168.122.200-192.168.122.205  # 虚拟机使用桥接网卡地址网段
```

```bash
[root@master ~]# kubectl apply -f pool1.yaml 
configmap/config created
```

#### 测试

```bash
kubectl run pod1 --image=nginx --image-pull-policy=IfNotPresent
```

```bash
[root@master ~]# kubectl expose --name=svc10 pod pod1 --port=80 --type=LoadBalancer
service/svc10 exposed
```

```bash
[root@master ~]# kubectl get svc
NAME    TYPE           CLUSTER-IP       EXTERNAL-IP       PORT(S)        AGE
svc1    ClusterIP      10.107.76.165    <none>            80/TCP         2d3h
svc10   LoadBalancer   10.100.124.221   192.168.122.202   80:30113/TCP   4s
svc2    ClusterIP      10.107.147.148   <none>            80/TCP         2d3h
svc3    ClusterIP      10.111.192.216   <none>            80/TCP         2d3h
```

访问192.168.122.202则成功

#### 删除

```

```







### 创建ingress并发布服务

nodeport 会在服务增多的情况下导致映射端口过多

#### 搭建ingress-nginx服务器

- 本质通过nginx的反向代理来实现.然后在用户所在的命名空间写ingress规则，这些规则会嵌入 ingres-nginx控制器里
- 用户在自己的命名空间里定义ingress规则

​     www1.rhce.cc 转发到svc1

​     www2.rhce.cc 转发到svc2

​      www3.rhce.cc 转发到svc3

   我们把www1.rhce.cc 和  www2.rhce.cc 都解析为ingress-nginx控制器所在的IP，以后客户端访问www1.rhce.cc的时候访问的就是ingress-nginx控制器，根据规则,控制器会把请求转发到svc1

#### 部署nginx ingress 控制器

   参考:  https://kubernetes.github.io/ingress-nginx/deploy/#bare-metal-clusters

   镜像: https://hub.docker.com/r/anjia0532/google-containers.ingress-nginx.controller/tags

```bash
kubectl apply -f https://raw.githubusercontent.com/kubernetes/ingress-nginx/controller-v1.3.0/deploy/static/provider/baremetal/deploy.yaml
```

查看命名空间

```bash
[root@master svc]# kubectl get ns
NAME              STATUS   AGE
default           Active   14d
ingress-nginx     Active   31s
kube-node-lease   Active   14d
kube-public       Active   14d
kube-system       Active   14d
nsdeploy          Active   2d21h
nsds              Active   44h
nsjob             Active   30h
nsprobe           Active   44h
nssec             Active   4d21h
nssvc             Active   29h
nsvolume          Active   6d20h
```

查看deployment

```bash
[root@master svc]# kubectl get deploy -n ingress-nginx
NAME                       READY   UP-TO-DATE   AVAILABLE   AGE
ingress-nginx-controller   0/1     1            0           46s
```

查看pod节点

```bash

[root@master svc]# kubectl get pods -n ingress-nginx -o wide 
NAME                                        READY   STATUS              RESTARTS   AGE   IP               NODE    NOMINATED NODE   READINESS GATES
ingress-nginx-admission-create-t265f        0/1     ErrImagePull        0          61s   10.244.166.157   node1   <none>           <none>
ingress-nginx-admission-patch-72c7w         0/1     ImagePullBackOff    0          61s   10.244.166.158   node1   <none>           <none>
ingress-nginx-controller-787f856bb4-2qd46   0/1     ContainerCreating   0          61s   <none>           node1   <none>           <none>
```

这里发现ErrImagePull报错:

修改yaml文件

```yaml
apiVersion: v1
kind: Namespace
metadata:
  labels:
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
  name: ingress-nginx
---
apiVersion: v1
automountServiceAccountToken: true
kind: ServiceAccount
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx
  namespace: ingress-nginx
---
apiVersion: v1
kind: ServiceAccount
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx
  namespace: ingress-nginx
rules:
- apiGroups:
  - ""
  resources:
  - namespaces
  verbs:
  - get
- apiGroups:
  - ""
  resources:
  - configmaps
  - pods
  - secrets
  - endpoints
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - services
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses/status
  verbs:
  - update
- apiGroups:
  - networking.k8s.io
  resources:
  - ingressclasses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resourceNames:
  - ingress-controller-leader
  resources:
  - configmaps
  verbs:
  - get
  - update
- apiGroups:
  - ""
  resources:
  - configmaps
  verbs:
  - create
- apiGroups:
  - coordination.k8s.io
  resourceNames:
  - ingress-controller-leader
  resources:
  - leases
  verbs:
  - get
  - update
- apiGroups:
  - coordination.k8s.io
  resources:
  - leases
  verbs:
  - create
- apiGroups:
  - ""
  resources:
  - events
  verbs:
  - create
  - patch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: Role
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission
  namespace: ingress-nginx
rules:
- apiGroups:
  - ""
  resources:
  - secrets
  verbs:
  - get
  - create
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  labels:
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx
rules:
- apiGroups:
  - ""
  resources:
  - configmaps
  - endpoints
  - nodes
  - pods
  - secrets
  - namespaces
  verbs:
  - list
  - watch
- apiGroups:
  - coordination.k8s.io
  resources:
  - leases
  verbs:
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - nodes
  verbs:
  - get
- apiGroups:
  - ""
  resources:
  - services
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses
  verbs:
  - get
  - list
  - watch
- apiGroups:
  - ""
  resources:
  - events
  verbs:
  - create
  - patch
- apiGroups:
  - networking.k8s.io
  resources:
  - ingresses/status
  verbs:
  - update
- apiGroups:
  - networking.k8s.io
  resources:
  - ingressclasses
  verbs:
  - get
  - list
  - watch
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission
rules:
- apiGroups:
  - admissionregistration.k8s.io
  resources:
  - validatingwebhookconfigurations
  verbs:
  - get
  - update
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx
  namespace: ingress-nginx
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: ingress-nginx
subjects:
- kind: ServiceAccount
  name: ingress-nginx
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission
  namespace: ingress-nginx
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: ingress-nginx-admission
subjects:
- kind: ServiceAccount
  name: ingress-nginx-admission
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  labels:
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: ingress-nginx
subjects:
- kind: ServiceAccount
  name: ingress-nginx
  namespace: ingress-nginx
---
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: ingress-nginx-admission
subjects:
- kind: ServiceAccount
  name: ingress-nginx-admission
  namespace: ingress-nginx
---
apiVersion: v1
data:
  allow-snippet-annotations: "true"
kind: ConfigMap
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-controller
  namespace: ingress-nginx
---
apiVersion: v1
kind: Service
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-controller
  namespace: ingress-nginx
spec:
  ports:
  - appProtocol: http
    name: http
    port: 80
    protocol: TCP
    targetPort: http
  - appProtocol: https
    name: https
    port: 443
    protocol: TCP
    targetPort: https
  selector:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
  # type: NodePort
  type: LoadBalancer #这里改成LoadBalancer，获取外部IP
---
apiVersion: v1
kind: Service
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-controller-admission
  namespace: ingress-nginx
spec:
  ports:
  - appProtocol: https
    name: https-webhook
    port: 443
    targetPort: webhook
  selector:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
  type: ClusterIP
---
apiVersion: apps/v1
kind: Deployment
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-controller
  namespace: ingress-nginx
spec:
  minReadySeconds: 0
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      app.kubernetes.io/component: controller
      app.kubernetes.io/instance: ingress-nginx
      app.kubernetes.io/name: ingress-nginx
  template:
    metadata:
      labels:
        app.kubernetes.io/component: controller
        app.kubernetes.io/instance: ingress-nginx
        app.kubernetes.io/name: ingress-nginx
    spec:
      containers:
      - args:
        - /nginx-ingress-controller
        - --election-id=ingress-controller-leader
        - --controller-class=k8s.io/ingress-nginx
        - --ingress-class=nginx
        - --configmap=$(POD_NAMESPACE)/ingress-nginx-controller
        - --validating-webhook=:8443
        - --validating-webhook-certificate=/usr/local/certificates/cert
        - --validating-webhook-key=/usr/local/certificates/key
        env:
        - name: POD_NAME
          valueFrom:
            fieldRef:
              fieldPath: metadata.name
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        - name: LD_PRELOAD
          value: /usr/local/lib/libmimalloc.so
        # image: registry.k8s.io/ingress-nginx/controller:v1.3.0@sha256:d1707ca76d3b044ab8a28277a2466a02100ee9f58a86af1535a3edf9323ea1b5
        image: anjia0532/google-containers.ingress-nginx.controller:v1.3.0
        imagePullPolicy: IfNotPresent
        lifecycle:
          preStop:
            exec:
              command:
              - /wait-shutdown
        livenessProbe:
          failureThreshold: 5
          httpGet:
            path: /healthz
            port: 10254
            scheme: HTTP
          initialDelaySeconds: 10
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 1
        name: controller
        ports:
        - containerPort: 80
          name: http
          protocol: TCP
        - containerPort: 443
          name: https
          protocol: TCP
        - containerPort: 8443
          name: webhook
          protocol: TCP
        readinessProbe:
          failureThreshold: 3
          httpGet:
            path: /healthz
            port: 10254
            scheme: HTTP
          initialDelaySeconds: 10
          periodSeconds: 10
          successThreshold: 1
          timeoutSeconds: 1
        resources:
          requests:
            cpu: 100m
            memory: 90Mi
        securityContext:
          allowPrivilegeEscalation: true
          capabilities:
            add:
            - NET_BIND_SERVICE
            drop:
            - ALL
          runAsUser: 101
        volumeMounts:
        - mountPath: /usr/local/certificates/
          name: webhook-cert
          readOnly: true
      dnsPolicy: ClusterFirst
      nodeSelector:
        kubernetes.io/os: linux
      serviceAccountName: ingress-nginx
      terminationGracePeriodSeconds: 300
      volumes:
      - name: webhook-cert
        secret:
          secretName: ingress-nginx-admission
---
apiVersion: batch/v1
kind: Job
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission-create
  namespace: ingress-nginx
spec:
  template:
    metadata:
      labels:
        app.kubernetes.io/component: admission-webhook
        app.kubernetes.io/instance: ingress-nginx
        app.kubernetes.io/name: ingress-nginx
        app.kubernetes.io/part-of: ingress-nginx
        app.kubernetes.io/version: 1.3.0
      name: ingress-nginx-admission-create
    spec:
      containers:
      - args:
        - create
        - --host=ingress-nginx-controller-admission,ingress-nginx-controller-admission.$(POD_NAMESPACE).svc
        - --namespace=$(POD_NAMESPACE)
        - --secret-name=ingress-nginx-admission
        env:
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        # image: registry.k8s.io/ingress-nginx/kube-webhook-certgen:v1.1.1@sha256:64d8c73dca984af206adf9d6d7e46aa550362b1d7a01f3a0a91b20cc67868660
        image: anjia0532/google-containers.ingress-nginx.kube-webhook-certgen:v1.1.1
        imagePullPolicy: IfNotPresent
        name: create
        securityContext:
          allowPrivilegeEscalation: false
      nodeSelector:
        kubernetes.io/os: linux
      restartPolicy: OnFailure
      securityContext:
        fsGroup: 2000
        runAsNonRoot: true
        runAsUser: 2000
      serviceAccountName: ingress-nginx-admission
---
apiVersion: batch/v1
kind: Job
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission-patch
  namespace: ingress-nginx
spec:
  template:
    metadata:
      labels:
        app.kubernetes.io/component: admission-webhook
        app.kubernetes.io/instance: ingress-nginx
        app.kubernetes.io/name: ingress-nginx
        app.kubernetes.io/part-of: ingress-nginx
        app.kubernetes.io/version: 1.3.0
      name: ingress-nginx-admission-patch
    spec:
      containers:
      - args:
        - patch
        - --webhook-name=ingress-nginx-admission
        - --namespace=$(POD_NAMESPACE)
        - --patch-mutating=false
        - --secret-name=ingress-nginx-admission
        - --patch-failure-policy=Fail
        env:
        - name: POD_NAMESPACE
          valueFrom:
            fieldRef:
              fieldPath: metadata.namespace
        # image: registry.k8s.io/ingress-nginx/kube-webhook-certgen:v1.1.1@sha256:64d8c73dca984af206adf9d6d7e46aa550362b1d7a01f3a0a91b20cc67868660
        image: anjia0532/google-containers.ingress-nginx.kube-webhook-certgen:v1.1.1
        imagePullPolicy: IfNotPresent
        name: patch
        securityContext:
          allowPrivilegeEscalation: false
      nodeSelector:
        kubernetes.io/os: linux
      restartPolicy: OnFailure
      securityContext:
        fsGroup: 2000
        runAsNonRoot: true
        runAsUser: 2000
      serviceAccountName: ingress-nginx-admission
---
apiVersion: networking.k8s.io/v1
kind: IngressClass
metadata:
  labels:
    app.kubernetes.io/component: controller
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: nginx
spec:
  controller: k8s.io/ingress-nginx
---
apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingWebhookConfiguration
metadata:
  labels:
    app.kubernetes.io/component: admission-webhook
    app.kubernetes.io/instance: ingress-nginx
    app.kubernetes.io/name: ingress-nginx
    app.kubernetes.io/part-of: ingress-nginx
    app.kubernetes.io/version: 1.3.0
  name: ingress-nginx-admission
webhooks:
- admissionReviewVersions:
  - v1
  clientConfig:
    service:
      name: ingress-nginx-controller-admission
      namespace: ingress-nginx
      path: /networking/v1/ingresses
  failurePolicy: Fail
  matchPolicy: Equivalent
  name: validate.nginx.ingress.kubernetes.io
  rules:
  - apiGroups:
    - networking.k8s.io
    apiVersions:
    - v1
    operations:
    - CREATE
    - UPDATE
    resources:
    - ingresses
  sideEffects: None
```

重新安装查看

```bash
[root@master svc]# kubectl get pods -n ingress-nginx -o wide
NAME                                        READY   STATUS      RESTARTS   AGE     IP               NODE    NOMINATED NODE   READINESS GATES
ingress-nginx-admission-create-ftxdq        0/1     Completed   0          2m13s   10.244.166.173   node1   <none>           <none>
ingress-nginx-admission-patch-8c76s         0/1     Completed   3          2m13s   10.244.166.174   node1   <none>           <none>
ingress-nginx-controller-6d86674cfd-wdqts   0/1     Running     0          2m13s   10.244.166.170   node1   <none>           <none>
```

修改node1和node2的hosts

```bash
10.244.166.170 www1.rhce.cc www1
10.244.166.170 www2.rhce.cc www2
```

#### 环境准备

3个pod

```bash
[root@master svc]# kubectl run nginx1 --image=nginx --image-pull-policy=IfNotPresent
pod/nginx1 created
[root@master svc]# kubectl run nginx2 --image=nginx --image-pull-policy=IfNotPresent
pod/nginx2 created
[root@master svc]# kubectl run nginx3 --image=nginx --image-pull-policy=IfNotPresent
pod/nginx3 created
```

3个svc

```bash
[root@master svc]# kubectl expose pod nginx1 --name=svc1 --port=80
service/svc1 exposed
[root@master svc]# kubectl expose pod nginx2 --name=svc2 --port=80
service/svc2 exposed
[root@master svc]# kubectl expose pod nginx3 --name=svc3 --port=80
service/svc3 exposed
```

查看svc

```bash
[root@master svc]# kubectl get svc
NAME   TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)   AGE
svc1   ClusterIP   10.107.76.165    <none>        80/TCP    24s
svc2   ClusterIP   10.107.147.148   <none>        80/TCP    19s
svc3   ClusterIP   10.111.192.216   <none>        80/TCP    15s
```

修改nginx的html文件

```bash
[root@master svc]# kubectl exec -it nginx1 -- bash
root@nginx1:/# echo 111 > /usr/share/nginx/html/index.html 
```

```bash
[root@master svc]# kubectl exec -it nginx2 -- bash
root@nginx2:/# echo 222 > /usr/share/nginx/html/index.html
```

```bash
[root@master svc]# kubectl exec -ti nginx3 -- bash
root@nginx3:/# mkdir /usr/share/nginx/html/cka
root@nginx3:/# echo 333 > /usr/share/nginx/html/cka/index.html
```

#### 定义ingress规则

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: mying
  annotations:
    kubernetes.io/ingress.class: nginx
spec:
  rules:
  - host: www1.rhce.cc
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: svc1
            port:
              number: 80
      - path: /cka
        pathType: Prefix
        backend:
          service:
            name: svc3
            port:
              number: 80
  - host: www2.rhce.cc
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: svc2
            port:
              number: 80
```

```bash
[root@master svc]# kubectl apply -f ingress.yaml 
ingress.networking.k8s.io/mying created
```

查看ingress

```bash
[root@master ~]# kubectl get ing
NAME    CLASS    HOSTS                       ADDRESS           PORTS   AGE
mying   <none>   www1.rhce.cc,www2.rhce.cc   192.168.122.202   80      25h
```

这里不显示ADDRESS

测试

```bash
[root@node1 ~]# curl www1.rhce.cc/cka/
333
[root@node1 ~]# curl www1.rhce.cc
111
[root@node1 ~]# curl www2.rhce.cc
222
```
