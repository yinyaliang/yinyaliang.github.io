---
title: "常用命令"
tags:
  - Docker
toc: true
---

Mysql 命令记录

#### 删除none的images
```bash
docker images  | grep '<none>' | awk '{print $3}' | xargs  docker image rm -f {}
```

#### 更新k8s的configmap
```bash
kubectl create configmap osptest --from-file=test.yaml -o yaml -n osp-test --dry-run | kubectl apply -f -
```

#### 拉取指定远程分支到本地
新建仓库
```bash
$ mkdir gitrepo
$ cd giterpo
$ git init
```
拉取远程指定分支
```bash
$ git remote add origin https://github.com/zjZSTU/zjzstu.github.com.git
$ git fetch origin dev
```
新建本地分支并关联到指定远程分支
```bash
$ git checkout -b dev origin/dev
```
