---
title: "leetcode-golang-easy-01"
tags:
  - leetcode
toc: true
---

### 1 两数之和

```golang
/*
 * @lc app=leetcode.cn id=1 lang=golang
 *
 * [1] 两数之和
 */

// @lc code=start
func twoSum(nums []int, target int) []int {          // nums 是是一个整数数组,target是目标值
	numMap := make(map[int]int)                  // 储存没个数字的补数
	for i, num := range nums {                   // 循环nums,i为num索引
		com := target - num                  // com + num = target
		if index, ok := numMap[com]; ok {    // 判断numMap中是否存在 com值,index为com索引
			return []int{index, i}       // 返回com索引(index),num索引(i)
		}
		numMap[num] = i                      // 存储num和它的索引
	}
	return []int{}                               
}

// @lc code=end

```

### 2 回文数

```golang
/*
 * @lc app=leetcode.cn id=9 lang=golang
 *
 * [9] 回文数
 */

// @lc code=start
func isPalindrome(x int) bool {
	if x < 0 {
		return false                       // 负数不可能是回文数
	}


	var r int                           
	for i := x; i != 0; i /= 10 {               
		r = r*10 + i%10                   // 将x的每一位数取出来，加到r的末尾
	}
	return r == x
}

// @lc code=end
```

### 3 罗马数字转整数

```golang
/*
 * @lc app=leetcode.cn id=13 lang=golang
 *
 * [13] 罗马数字转整数
 */

// @lc code=start
func romanToInt(s string) int {
	mapSymbol := map[byte]int{               //  映射集合
		'I': 1,
		'V': 5,
		'X': 10,
		'L': 50,
		'C': 100,
		'D': 500,
		'M': 1000,
	}

	var result int
	prev := 0

	for i := len(s) - 1; i >= 0; i-- {         
		curr := mapSymbol[s[i]]          // 获取当前数字
		if curr < prev {                 // 当前值小于前值,表示的是一个减法，就从结果中减去当前整数
			result -= curr
		} else {
			result += curr           // 表示的是一个加法，就将当前整数加到结果中
		}
		prev = curr
	}
	return result
}

// @lc code=end
```

### 4 最长公共前缀
```golang
/*
 * @lc app=leetcode.cn id=14 lang=golang
 *
 * [14] 最长公共前缀
 */

// @lc code=start

func longestCommonPrefix(strs []string) string {
	if len(strs) == 0 {
		return ""                                    //空strs返回空字符串           
	}
	prefix := strs[0]                                    // 取strs第一个字符串作为前缀匹配
	for i := 1; i < len(strs); i++ {
		for !strings.HasPrefix(strs[i], prefix) {  
			prefix = prefix[:len(prefix)-1]      // 依次对比剩余字符串,如未匹配则减少一位
			if len(prefix) == 0 {
				return ""
			}
		}
	}
	return prefix
}

// @lc code=end
```

### 5 有效的括号
```golang
/*
 * @lc app=leetcode.cn id=20 lang=golang
 *
 * [20] 有效的括号
 */

// @lc code=start
func isValid(s string) bool {
	stack := []rune{}

	for _, c := range s {
		if c == '(' || c == '{' || c == '[' {
			stack = append(stack, c)                                // 入栈 
		} else if c == ')' {
			if len(stack) == 0 || stack[len(stack)-1] != '(' {
				return false
			}
			stack = stack[:len(stack)-1]                            // 出栈
		} else if c == '}' {
			if len(stack) == 0 || stack[len(stack)-1] != '{' {
				return false
			}
			stack = stack[:len(stack)-1]
		} else if c == ']' {
			if len(stack) == 0 || stack[len(stack)-1] != '[' {
				return false
			}
			stack = stack[:len(stack)-1]
		}
	}
	return len(stack) == 0
}

// @lc code=end

```

### 6 合并两个有序链表
```golang
/*
 * @lc app=leetcode.cn id=21 lang=golang
 *
 * [21] 合并两个有序链表
 */

// @lc code=start
/**
 * Definition for singly-linked list.
 * type ListNode struct {
 *     Val int
 *     Next *ListNode
 * }
 */
func mergeTwoLists(list1 *ListNode, list2 *ListNode) *ListNode {
	linklist := &ListNode{}
	cur := linklist

	for list1 != nil && list2 != nil {
		if list1.Val <= list2.Val {
			cur.Next = list1
			list1 = list1.Next
		} else {
			cur.Next = list2
			list2 = list2.Next
		}
		cur = cur.Next
	}

	if list1 != nil {
		cur.Next = list1
	}

	if list2 != nil {
		cur.Next = list2
	}
	return linklist.Next
}

// @lc code=end
```

### 7 删除有序数组中的重复项
```golang
/*
 * @lc app=leetcode.cn id=26 lang=golang
 *
 * [26] 删除有序数组中的重复项
 */

// @lc code=start
func removeDuplicates(nums []int) int {
	i := 0
	for j := 1; j < len(nums); j++ {
		if nums[i] != nums[j] {
			i++
			nums[i] = nums[j]
		}
	}
	return i + 1
}

// @lc code=end
```

### 8 移除元素
```golang
func removeElement(nums []int, val int) int {
	if len(nums) == 0 {
		return 0
	}

	i, j := 0, len(nums)-1
	for i <= j {
		if nums[i] == val {
			nums[i], nums[j] = nums[j], nums[i]
			j--
		} else {
			i++
		}
	}
	return i
}
```

### 9 搜索插入位置
```golang
/*
 * @lc app=leetcode.cn id=35 lang=golang
 *
 * [35] 搜索插入位置
 */

// @lc code=start
func searchInsert(nums []int, target int) int {
	left, right := 0, len(nums)-1
	for left <= right {
		mid := (right + left) / 2
		if nums[mid] == target {
			return mid
		} else if nums[mid] < target {
			left = mid + 1
		} else {
			right = mid - 1
		}
	}
	return left
}

// @lc code=end
```


### 10 最后一个单词的长度
```golang
/*
 * @lc app=leetcode.cn id=58 lang=golang
 *
 * [58] 最后一个单词的长度
 */

// @lc code=start
func lengthOfLastWord(s string) int {
	end := len(s) - 1
	for s[end] == ' ' && end >= 0 {
		end--
	}
	if end < 0 {
		return 0
	}
	start := end
	for start >= 0 && s[start] != ' ' {
		start--
	}
	return end - start
}

// @lc code=end
```

### 11 加一
```golang
/*
 * @lc app=leetcode.cn id=66 lang=golang
 *
 * [66] 加一
 */

// @lc code=start
func plusOne(digits []int) []int {
	dLen := len(digits)
	for i := dLen - 1; i >= 0; i-- {
		digits[i]++
		digits[i] %= 10
		if digits[i] != 0 {
			return digits
		}
	}
	return append([]int{1}, digits...)
}

// @lc code=end
```

### 12 二进制求和
```golang
/*
 * @lc app=leetcode.cn id=67 lang=golang
 *
 * [67] 二进制求和
 */

// @lc code=start
func addBinary(a string, b string) string {
	aLen, bLen := len(a)-1, len(b)-1
	carry := 0
	res := ""
	for aLen >= 0 || bLen >= 0 {
		x, y := 0, 0
		if aLen >= 0 {
			x = int(a[aLen] - '0')
			aLen--
		}
		if bLen >= 0 {
			y = int(b[bLen] - '0')
			bLen--
		}
		sum := x + y + carry
		res = strconv.Itoa(sum%2) + res // 对 2 取模就是当前位的值
		carry = sum / 2                 // 对 2 取整就是进位的值
	}
	if carry == 1 {
		res = "1" + res
	}
	return res
}

// @lc code=end
```

### 13 x 的平方根
```golang
/*
 * @lc app=leetcode.cn id=69 lang=golang
 *
 * [69] x 的平方根
 */

// @lc code=start
func mySqrt(x int) int {
	if x <= 1 {
		return x
	}
	left, right := 1, x
	for left <= right {
		mid := left + (right-left)/2
		if mid*mid == x {
			return mid
		} else if mid*mid > x {
			right = mid - 1
		} else {
			left = mid + 1
		}
	}
	return right
}

// @lc code=end
```

### 14 爬楼梯
```golang
/*
 * @lc app=leetcode.cn id=70 lang=golang
 *
 * [70] 爬楼梯
 */

// @lc code=start
func climbStairs(n int) int {
	if n <= 2 {
		return n
	}
	f1, f2 := 1, 2
	for i := 3; i <= n; i++ {
		f3 := f1 + f2 //f(n) = f(n-1) + f(n-2)
		f1 = f2       //f(n-2)
		f2 = f3       //f(n-1)
	}
	return f2
}

// @lc code=end
```

### 15 删除排序链表中的重复元素
```golang
/*
 * @lc app=leetcode.cn id=83 lang=golang
 *
 * [83] 删除排序链表中的重复元素
 */

// @lc code=start
/**
 * Definition for singly-linked list.
 * type ListNode struct {
 *     Val int
 *     Next *ListNode
 * }
 */
func deleteDuplicates(head *ListNode) *ListNode {
	cur := head
	for cur != nil && cur.Next != nil {
		if cur.Val == cur.Next.Val {
			cur.Next = cur.Next.Next
		} else {
			cur = cur.Next
		}
	}
	return head
}

// @lc code=end
```

### 16 合并两个有序数组
```golang
/*
 * @lc app=leetcode.cn id=88 lang=golang
 *
 * [88] 合并两个有序数组
 */

// @lc code=start
func merge(nums1 []int, m int, nums2 []int, n int) {
	ms, ns := m-1, n-1
	totalLen := m + n - 1
	for ms >= 0 && ns >= 0 {
		if nums1[ms] > nums2[ns] {
			nums1[totalLen] = nums1[ms]
			ms--
		} else {
			nums1[totalLen] = nums2[ns]
			ns--
		}
		totalLen--
	}
	for ns >= 0 {
		nums1[totalLen] = nums2[ns]
		totalLen--
		ns--
	}
}

// @lc code=end
```

### 17 二叉树的中序遍历
```golang
/*
 * @lc app=leetcode.cn id=94 lang=golang
 *
 * [94] 二叉树的中序遍历
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */
func inorderTraversal(root *TreeNode) []int {
	//左子树 -> 根节点 -> 右子树
	res := make([]int, 0)
	if root == nil {
		return res
	}
	res = append(res, inorderTraversal(root.Left)...)
	res = append(res, root.Val)
	res = append(res, inorderTraversal(root.Right)...)
	return res
}

// @lc code=end
```

### 18 相同的树
```golang
/*
 * @lc app=leetcode.cn id=100 lang=golang
 *
 * [100] 相同的树
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */
func isSameTree(p *TreeNode, q *TreeNode) bool {
	if p == nil && q == nil {
		return true
	}
	if p == nil || q == nil {
		return false
	}
	if p.Val != q.Val {
		return false
	}
	return isSameTree(p.Left, q.Left) && isSameTree(p.Right, q.Right)
}

// @lc code=end
```

### 19 对称二叉树
```golang
/*
 * @lc app=leetcode.cn id=101 lang=golang
 *
 * [101] 对称二叉树
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */

func isMirror(left *TreeNode, right *TreeNode) bool {
	if left == nil && right == nil {
		return true
	}
	if left == nil || right == nil {
		return false
	}
	if left.Val != right.Val {
		return false
	}
	return isMirror(left.Left, right.Right) && isMirror(left.Right, right.Left)
}

func isSymmetric(root *TreeNode) bool {
	return isMirror(root, root)

}

// @lc code=end
```

### 20 二叉树的最大深度
```golang
/*
 * @lc app=leetcode.cn id=104 lang=golang
 *
 * [104] 二叉树的最大深度
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */

func max(x, y int) int {
	if x > y {
		return x
	}
	return y
}

func maxDepth(root *TreeNode) int {
	if root == nil {
		return 0
	}
	leftDepth := maxDepth(root.Left)
	rightDepth := maxDepth(root.Right)
	return max(leftDepth, rightDepth) + 1
}

// @lc code=end
```

### 21 将有序数组转换为二叉搜索树
```golang
/*
 * @lc app=leetcode.cn id=108 lang=golang
 *
 * [108] 将有序数组转换为二叉搜索树
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */
func sortedArrayToBST(nums []int) *TreeNode {
	if len(nums) == 0 {
		return nil
	}
	mid := len(nums) / 2
	root := &TreeNode{Val: nums[mid]}           //根节点是数组的中间元素
	root.Left = sortedArrayToBST(nums[:mid])    //左边的元素作为左子树
	root.Right = sortedArrayToBST(nums[mid+1:]) //右边的元素作为右子树
	return root
}

// @lc code=end
```

### 22 平衡二叉树
```golang
/*
 * @lc app=leetcode.cn id=110 lang=golang
 *
 * [110] 平衡二叉树
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */

func abs(a int) int {
	if a < 0 {
		return -a
	}
	return a
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func maxDepth(root *TreeNode) int {
	if root == nil {
		return 0
	}
	return max(maxDepth(root.Left), maxDepth(root.Right)) + 1
}

func isBalanced(root *TreeNode) bool {
	if root == nil {
		return true
	}
	leftDepth := maxDepth(root.Left)
	rightDepth := maxDepth(root.Right)
	if abs(leftDepth-rightDepth) > 1 {
		return false
	}
	return isBalanced(root.Left) && isBalanced(root.Right)

}

// @lc code=end
```

### 23 二叉树的最小深度
```golang
/*
 * @lc app=leetcode.cn id=111 lang=golang
 *
 * [111] 二叉树的最小深度
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func minDepth(root *TreeNode) int {
	if root == nil {
		return 0
	}
	leftDepth := minDepth(root.Left)
	rightDepth := minDepth(root.Right)

	if leftDepth == 0 || rightDepth == 0 {
		return leftDepth + rightDepth + 1
	}
	return 1 + min(leftDepth, rightDepth)
}

// @lc code=end
```

### 24 路径总和
```golang
/*
 * @lc app=leetcode.cn id=112 lang=golang
 *
 * [112] 路径总和
 */

// @lc code=start
/**
 * Definition for a binary tree node.
 * type TreeNode struct {
 *     Val int
 *     Left *TreeNode
 *     Right *TreeNode
 * }
 */
func hasPathSum(root *TreeNode, targetSum int) bool {
	if root == nil {
		return false
	}
	if root.Val == targetSum && root.Left == nil && root.Right == nil {
		return true
	}
	targetSum -= root.Val
	return hasPathSum(root.Left, targetSum) || hasPathSum(root.Right, targetSum)

}

// @lc code=end
```
