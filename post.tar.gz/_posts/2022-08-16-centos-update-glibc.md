---
title: "`Centos 更新Glibc `"
tags:
  - Linux
toc: true
---

写CBPF需要更新系统的Glibc

#### 安装centos-release-scl
```
yum install centos-release-scl
```

#### 安装7版本的devtoolset
```
yum install devtoolset-7-gcc*
```

#### 激活
```
scl enable devtoolset-7 bash
```

#### 查看gcc版本
```
gcc -v
```

#### 下载安装包
```
cd /tmp
wget https://ftp.gnu.org/gnu/glibc/glibc-2.23.tar.gz
tar xf glibc-2.23.tar.gz
cd glibc-2.23/
mkdir glibc-build
cd glibc-build 
```

#### 安装
```
../configure --prefix=/usr
make
make install
```

#### 验证
```
ldd --version
ldd (GNU libc) 2.23

Copyright (C) 2016 Free Software Foundation, Inc.

This is free software; see the source for copying conditions.  There is NO

warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

Written by Roland McGrath and Ulrich Drepper.
```

#### 排错
1、
```
setenv.c:279:6: error: suggest explicit braces to avoid ambiguous ‘else’ [-Werror=dangling-else]
   if (ep != NULL)
```
```
增加{}
```

2、
```
../sysdeps/ieee754/dbl-64/e_pow.c:469:13: error: ‘<<’ in boolean context, did you mean ‘<’ ? [-Werror=int-in-bool-context]
       if (n << (k - 20))
           ~~^~~~~~~~~~~
../sysdeps/ieee754/dbl-64/e_pow.c:471:17: error: ‘<<’ in boolean context, did you mean ‘<’ ? [-Werror=int-in-bool-context]
       return (n << (k - 21)) ? -1 : 1;
              ~~~^~~~~~~~~~~~
../sysdeps/ieee754/dbl-64/e_pow.c:477:9: error: ‘<<’ in boolean context, did you mean ‘<’ ? [-Werror=int-in-bool-context]
   if (m << (k + 12))
       ~~^~~~~~~~~~~
../sysdeps/ieee754/dbl-64/e_pow.c:479:13: error: ‘<<’ in boolean context, did you mean ‘<’ ? [-Werror=int-in-bool-context]
   return (m << (k + 11)) ? -1 : 1;
```
```
 if (n << (k - 20)!=0)

 (n << (k - 21)!=0) ? -1 : 1;

 (m << (k + 12)!=0)

 (m << (k + 11)!=0) ? -1 : 1;
```

3、
```
rpc_parse.c: In function ‘get_prog_declaration’:
rpc_parse.c:543:23: error: ‘%d’ directive writing between 1 and 10 bytes into a region of size 7 [-Werror=format-overflow=]
     sprintf (name, "%s%d", ARGNAME, num); /* default name of argument */
                       ^~
rpc_parse.c:543:20: note: directive argument in the range [1, 2147483647]
     sprintf (name, "%s%d", ARGNAME, num); /* default name of argument */
                    ^~~~~~
rpc_parse.c:543:5: note: ‘sprintf’ output between 5 and 14 bytes into a destination of size 10
     sprintf (name, "%s%d", ARGNAME, num); /* default name of argument */
```
```
sprintf (name, "%s%d", ARGNAME, (short)num)
```

4、
```
nis_call.c:682:6: error: suggest explicit braces to avoid ambiguous ‘else’ [-Werror=dangling-else]
   if (*loc != NULL)
```
```
if (*loc != NULL)
{ 
  for (i = 1; i < 16; ++i)
    if (nis_server_cache[i] == NULL)
  {
    loc = &nis_server_cache[i];
    break;
  }
    else if ((*loc)->uses > nis_server_cache[i]->uses
         || ((*loc)->uses == nis_server_cache[i]->uses
         && (*loc)->expires > nis_server_cache[i]->expires))
  loc = &nis_server_cache[i];
}
```

5、
```
nss_nisplus/nisplus-alias.c:300:12: error: argument 1 null where non-null expected [-Werror=nonnull]
   char buf[strlen (name) + 9 + tablename_len];
```
```
char buf[tablename_len + 9];
snprintf (buf, sizeof (buf), "[name=],%s", tablename_val);
```

6、
```
gawk '/\.gnu\.glibc-stub\./ { \
	  sub(/\.gnu\.glibc-stub\./, "", $2); \
	  stubs[$2] = 1; } \
	END { for (s in stubs) print "#define __stub_" s }' > /tmp/glibc-2.23/glibc-build/math/stubsT
gawk: error while loading shared libraries: /lib64/libm.so.6: invalid ELF header
make[2]: *** [/tmp/glibc-2.23/glibc-build/math/stubs] Error 127
```
```
cd /lib64
unlink libm.so.6
ln -s libm-2.23.so libm.so.6
```
