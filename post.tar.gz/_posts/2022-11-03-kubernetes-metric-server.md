---
title: "k8s安装metric server"
tags:
  - Kubernetes
toc: true
---

k8s安装metric server

### kubernetes 安装metric server

#### k8s版本
```bash
# kubectl version
Client Version: version.Info{Major:"1", Minor:"20", GitVersion:"v1.20.15", GitCommit:"8f1e5bf0b9729a899b8df86249b56e2c74aebc55", GitTreeState:"clean", BuildDate:"2022-01-19T17:27:39Z", GoVersion:"go1.15.15", Compiler:"gc", Platform:"linux/amd64"}
Server Version: version.Info{Major:"1", Minor:"20", GitVersion:"v1.20.15", GitCommit:"8f1e5bf0b9729a899b8df86249b56e2c74aebc55", GitTreeState:"clean", BuildDate:"2022-01-19T17:23:01Z", GoVersion:"go1.15.15", Compiler:"gc", Platform:"linux/amd64"}
```

#### 作用

- 基于 CPU/内存的水平自动缩放
- 自动调整/建议容器所需的资源

#### 安装metric server 的条件

- kube-apiserver 必须[启用聚合层](https://kubernetes.io/docs/tasks/access-kubernetes-api/configure-aggregation-layer/)。
- 节点必须启用 Webhook[身份验证和授权](https://kubernetes.io/docs/reference/access-authn-authz/kubelet-authn-authz/)。
- Kubelet 证书需要由集群证书颁发机构签名（或通过传递`--kubelet-insecure-tls`给 Metrics Server 来禁用证书验证）
- 容器运行时必须实现[容器度量 RPC](https://github.com/kubernetes/community/blob/master/contributors/devel/sig-node/cri-container-stats.md)（或具有[cAdvisor](https://github.com/google/cadvisor)支持）
- 网络应支持以下通信：
  - 控制平面到 Metrics Server。控制平面节点需要到达 Metrics Server 的 pod IP 和端口 10250（或节点 IP 和自定义端口，如果`hostNetwork`启用）
  - Metrics Server 到所有节点上的 Kubelet。Metrics 服务器需要到达节点地址和 Kubelet 端口。地址和端口在 Kubelet 中配置并作为 Node 对象的一部分发布。字段中的地址`.status.addresses`和端口`.status.daemonEndpoints.kubeletEndpoint.port`（默认为 10250）。Metrics Server 将根据`kubelet-preferred-address-types`命令行标志提供的列表（`InternalIP,ExternalIP,Hostname`清单中的默认值）选择第一个节点地址。

#### 使用聚合层扩展 Kubernete API

为了将原来的 API server 应用给拆分开，方便用户开发自己的 API server 集成进来，而不用直接修改 Kubernetes 官方仓库的代码，这样一来也能将 API server 解耦，用户可以通过附加的 API 扩展 Kubernetes， 而不局限于 Kubernetes 核心 API 提供的功能。 

开启API的聚合参数

```yaml
--requestheader-allowed-names=kubernetes \\
--requestheader-extra-headers-prefix=X-Remote-Extra- \\
--requestheader-group-headers=X-Remote-Group \\
--requestheader-username-headers=X-Remote-User \\
--enable-aggregator-routing=true \\
--proxy-client-cert-file=/opt/kubernetes/ssl/server.pem \\
--proxy-client-key-file=/opt/kubernetes/ssl/server-key.pem \\
```

**kubeadm安装的集群不需配置[参考](http://yinyaliang.site/kubernetes-kubeadm-install/)**

#### 安装

```
wget https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
```

修改配置

```yaml
      - args:
        - --cert-dir=/tmp
        - --secure-port=4443
        - --kubelet-preferred-address-types=InternalIP   #修改
        - --kubelet-insecure-tls                         #增加
        - --kubelet-use-node-status-port
        - --metric-resolution=15s
```

查看

```bash
 kubectl get pods -n kube-system | grep metric
```

测试

```bash
# kubectl top nodes --sort-by=cpu 
NAME          CPU(cores)   CPU%   MEMORY(bytes)   MEMORY%   
oif-omdhkm1   276m         13%    1457Mi          37%       
oif-omdhkm3   264m         13%    1347Mi          35%       
oif-omdhkm2   239m         11%    1257Mi          32%       
oif-omdhkp1   219m         2%     916Mi           3%        
oif-omdhkp3   202m         2%     910Mi           3%        
oif-omdhkp2   199m         2%     885Mi           3%        
oif-omdhkd1   123m         3%     1144Mi          14%  
```

```bash
# kubectl top pod --sort-by=cpu -n osp-test
NAME                              CPU(cores)   MEMORY(bytes)   
osp-test-api-6fcf98987c-qbr29     1m           18Mi            
osp-test-admin-5d9587c668-m8kw2   0m           4Mi 
```

#### 参考

```
https://github.com/kubernetes-sigs/metrics-server
```



