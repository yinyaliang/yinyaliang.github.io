---
title: "CISCO VPN配置备忘"
tags:
  - RS
toc: true
---

IPSEC, GRE OVER IPSEC, IP SEC REMOTEACCESS, DMVPN 配置

#### IPSEC
```bash
# R2
# IKE第一阶段
# 配置策略 第一个和第二个报文
crypto isakmp policy 10     #策略优先级
encr aes 256                #加密算法 
hash sha                    #hash算法默认SHA
authentication pre-share    #认证方式 预共享密钥
group 5                     #迪菲.赫尔曼算法的g和P的大小 建议1 2 5
lifetime 3600

# 第三和第四报文会自动计算
# 指定第五和第六个报文  进行身份认证
crypto isakmp key 6 CCIE address 13.1.1.3 #对端的IP地址

# ike第二阶段
# 匹配阶段二的感兴趣流，IPSEC中传输的流量需要在nat中deny
access-list 101 permit ip 192.168.1.0 0.0.0.255  192.168.2.0 0.0.0.255

# 设置转换集MYSET 最好和封装的加密算法一致
crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode tunnel

# 使用Map调用
crypto map MYMAP 10 ipsec-isakmp
set peer 13.1.1.3
set transform-set MYSET
match address 101


int Ethernet0/1
crypto map MYMAP


# R3
crypto isakmp policy 10
encr aes 256
hash sha
authentication pre-share
group 5
lifetime 3600
crypto isakmp key 6 CCIE address 12.1.1.2
crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode tunnel
crypto map MYMAP 10 ipsec-isakmp
set peer 12.1.1.2
set transform-set MYSET
match address 101

int e0/2
crypto map MYMAP

access-list 101 permit ip 192.168.2.0 0.0.0.255  192.168.1.0 0.0.0.255

```bash
show crypto isakmp sa
show run | s cry
show crypto session
```

#### GRE OVER IPSEC
```bash
R2
int tun0
tunnel source 12.1.1.2
tunnel des 13.1.1.3
ip address 10.1.1.2 255.255.255.0

router ospf 1
net 192.168.1.0 0.0.0.255 area 0
net 10.1.1.2 0.0.0.0 area 0

crypto isakmp policy 10
encr aes 256
authentication pre-share
group 5
lifetime 3600

crypto isakmp key 6 CCIE address 0.0.0.0

crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode transport

crypto ipsec profile CCIE-PROFILE
set transform-set MYSET

int tun0
tunnel protection ipsec profile CCIE-PROFILE

# R3
int tun0
tunnel source 13.1.1.3
tunnel des 12.1.1.2 
ip address 10.1.1.3 255.255.255.0

router ospf 1
net 192.168.2.0 0.0.0.255 area 0
net 10.1.1.3 0.0.0.0 area 0

crypto isakmp policy 10
encr aes 256
authentication pre-share
group 5
lifetime 3600

crypto isakmp key 6 CCIE address 0.0.0.0

crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode transport

crypto ipsec profile CCIE-PROFILE
set transform-set MYSET

int tun0
tunnel protection ipsec profile CCIE-PROFILE
```


```bash
show crypto isakmp sa
show run | s cry
show crypto session
```

#### IP Sec RemoteAccess
```bash
# R2
crypto isakmp policy 10
encr aes 256
authentication pre-share
group 5
lifetime 3600
crypto isakmp key 6 CCIE address 0.0.0.0
crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode tunnel

crypto dynamic TEST 10
set transform-set MYSET

crypto map MYMAP 10 ipsec-isakmp dynamic TEST

int Ethernet0/1
crypto map MYMAP


# R5
crypto isakmp policy 10
encr aes 256
authentication pre-share
group 5
lifetime 3600
crypto isakmp key 6 CCIE address 12.1.1.2
crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode tunnel

crypto map MYMAP 10 ipsec-isakmp
set peer 12.1.1.2
set transform-set MYSET
match address 101

int e0/0
crypto map MYMAP

access-list 101 permit ip 192.168.2.0 0.0.0.255  192.168.1.0 0.0.0.255
```

#### DMVPN
```bash
# R2
# 配置TUNNEL  source也可以是IP地址
int tunnel0
tunnel source e0/0   
tunnel mode gre multipoint  
ip address 10.1.1.2 255.255.255.0
# 在tunnel 0下 配置NHRP，总部使用动态方式
ip nhrp map multicast dynamic
ip nhrp network-id 234


# 动态路由协议上的坑
# 1、配置动态路由协议 OSPF,不可以将tunnel的接口通告，否则会有邻居翻滚应为默认是P2P类型
# 解决办法
int tun 0
ip ospf network point-to-multipoint
router ospf 1
router-id 2.2.2.2
net 10.2.2.2 0.0.0.0 area 0
net 10.1.1.0 0.0.0.255 area 0
# 目前从10.1.1.3的去往10.1.1.4的路由的下一条还是10.1.1.2，。需要配置NHRP重定向
int tunnel 0
ip nhrp redirect


# 2、配置EIGRP
router eigrp 234
net 10.0.0.0
# 关闭总部的水平分割
int tunnel 0
no ip split-horizon eigrp 234
# 使分部的下一跳地址不是自己
int tunnel 0
no ip next-hop-self eigrp 234

# 3、配置BGP
# 1个AS，核心要使用路由反射器

# 配置IPSec
crypto isakmp policy 10     
encr aes 256                
hash sha                   
authentication pre-share    
group 5                     
lifetime 3600
crypto isakmp key 6 CCIE address 0.0.0.0
crypto ipsec transform-set MYSET esp-aes 256 esp-sha-hmac
mode transport

crypto ipsec profile MYPROFILE
set transform-set MYSET
int tunnel 0
tunnel protection ipsec profile MYPROFILE
```
