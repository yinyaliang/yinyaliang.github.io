---
title: "Netlink 简介"
tags:
  - Linux
toc: true
---
 
netlink 简介

### netlink

```c
// net/netlink  位置
af_netlink.c
af_netlink.h
genetlink.c
diag.c
```

```c
// 优点
// 不需要轮询
// 内核可以向用户空间发送异步消息
// 支持组播
```

#### 创建netlink套接字

```
用户空间: sock(AF_NETLINK,SOCK_RAW|SOCK_CLEXEC,NETLINK_ROUTE) -> netlink_create() -> _netlink_create()
内核空间: netlink_kernel_create() -> _netlink_create()
```

#### 库文件

```
https://netfilter.org/projects/libmnl/
```

#### sockaddr_nl

```c
// include/uapi/linux/netlink.h
struct sockaddr_nl{
	__kernel_sa_family_t	nl_family;    /*AF_NETLINK*/
	unsigned short 			nl_pad;		  /*为零*/
	__u32 					nl_pid;       /*端口号*/
	__u32 					nl_groups;    /*组播组掩码*/
}
```

nl_pid 内核套接字,为0。 用户态程序设置为程序PID

#### netlink消息报头

```c
// include/uapi/linux/netlink.h
struct nlmsghdr {
	__u32		nlmsg_len;
	__u16		nlmsg_type;
	__u16		nlmsg_flags;
	__u32		nlmsg_seq;
	__u32		nlmsg_pid;
	__u8		nlmsg_data[];
};
```

```c
//nlmsg_type
#define NLMSG_NOOP			0x1		/* Nothing.		*/
#define NLMSG_ERROR			0x2		/* Error		*/
#define NLMSG_DONE			0x3		/* End of a dump	*/
#define NLMSG_OVERRUN		0x4		/* Data lost		*/
```

```c
// nlmsg_flags

#define NLM_F_REQUEST			0x01	/* It is request message. 	*/
#define NLM_F_MULTI				0x02	/* Multipart message, terminated by NLMSG_DONE */
#define NLM_F_ACK				0x04	/* Reply with ack, with zero or error code */
#define NLM_F_ECHO				0x08	/* Receive resulting notifications */
#define NLM_F_DUMP_INTR			0x10	/* Dump was inconsistent due to sequence change */
#define NLM_F_DUMP_FILTERED		0x20	/* Dump was filtered as requested */

/* Modifiers to GET request */
#define NLM_F_ROOT				0x100	/* specify tree	root	*/
#define NLM_F_MATCH				0x200	/* return all matching	*/
#define NLM_F_ATOMIC			0x400	/* atomic GET		*/
#define NLM_F_DUMP				(NLM_F_ROOT|NLM_F_MATCH)

/* Modifiers to NEW request */
#define NLM_F_REPLACE			0x100	/* Override existing		*/
#define NLM_F_EXCL				0x200	/* Do not touch, if it exists	*/
#define NLM_F_CREATE			0x400	/* Create, if it does not exist	*/
#define NLM_F_APPEND			0x800	/* Add to end of list		*/

/* Modifiers to DELETE request */
#define NLM_F_NONREC			0x100	/* Do not delete recursively	*/
#define NLM_F_BULK				0x200	/* Delete multiple objects	*/

/* Flags for ACK message */
#define NLM_F_CAPPED			0x100	/* request was capped */
#define NLM_F_ACK_TLVS			0x200	/* extended ACK TVLs were included */
```

### ip route

#### ip route add 添加顺序

- 用户态通过 netlink 协议，发送消息 RTM_NEWROUTE，
- 内核态由rtnetlink_rcv() 处理。
- 通过调用net/ipv4/fib_frontend.c的inet_rtm_newroute()完成。
- 再使用方法fib_table_insert()插入转发数据库(FIB)
- 通知订阅了RTM_NEWROUTE消息的侦听(使用rtmsg_fib()方法)
- 创建一条netlinki消息，通过rtnl_notify()发送，通知加入了RTNLGRP_IPV4_ROUTE组播组的所有侦听者

```c
ip route add -> rtnetlink_rcv() -> inet_rtm_newroute() -> fib_table_insert() -> rtmsg_fib() -> rtnl_notify()
```

#### ip route del 删除顺序

```
ip route del -> rtnetlink_rcv() -> inet_rtm_delroute() -> fib_table_delete() -> rtmsg_fib() -> rtnl_notify()
```

#### ip monitor route

通过Netlink，加入RTNLGRP_IPV4_ROUTE组播组。通过rtnl_notify()发送的消息会被ip monitor接收

### netlink 消息

```
0                                         31
        netlink消息报头(nlmsghdr)
        通用netlink消息报头(genlmsghdr)
        用户特定的消息报头(可选)
        通用netlink消息有效载荷(可选)
```

```c
// include/uapi/linux/genetlink.h
struct genlmsghdr {
    __u8 cmd;                     // 通用消息类型
    __u8 version;                 // 版本控制
    __u16 reserved;               // 保留
}
```

```c
sk_buff *genlmsg_new(size_t payload,gfp_t flags)
```

实现了为netlink消息分配缓冲区，这个是nlmsg_new()的包装器

```
genlmsg_new（） -> 调用genlmsg_put() 创建netlink报头 
```

```c
// include/net/genetlink.h
genlmsg_unicast() // 单播 是nlmsg_unicast() 包装器
genlmsg_multicast() // 发送消息到默认网络命名空间(namespace) net_init
genlmsg_multicast_allns()  // 发送到所有网络命名空间(namespace)
```

用户态创建netlink套接字

```
socket(AF_NETLINK,SOCK_RAM,NETLINK_GENERIC) -> 内核 netlink_create()
```

#### 监视接口

http://yinyaliang.site/monitor-tcp-state/
