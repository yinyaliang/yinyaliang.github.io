---
title: " 解决Zabbix 关于 TCP状态监控取值占用CPU高BUG的解决方案"
tags:
  - Monitor
toc: true
---

修复zabbix CPU占用高的bug


#### 故障现象

<img src="/assets/images/zabbix/01.png">

#### 现象分析

```bash
perf stat -d ./zabbix_agent2 -t net.tcp.socket.count[,,,,established]
net.tcp.socket.count[,,,,established]         [s|3208] Performance counter stats for './zabbix_agent2 -t net.tcp.socket.count[,,,,established]':          1,389.13 msec task-clock                #    0.598 CPUs utilized          
             2,602      context-switches          #    0.002 M/sec                  
                 5      cpu-migrations            #    0.004 K/sec                  
             2,576      page-faults               #    0.002 M/sec                  
   <not supported>      cycles                                                      
   <not supported>      instructions                                                
   <not supported>      branches                                                    
   <not supported>      branch-misses                                               
   <not supported>      L1-dcache-loads                                             
   <not supported>      L1-dcache-load-misses                                       
   <not supported>      LLC-loads                                                   
   <not supported>      LLC-load-misses                                                    2.323596300 seconds time elapsed       1.171183000 seconds user
       0.217171000 seconds sys
```

<img src="/assets/images/zabbix/02.png">


#### 解决代码
```go
package eeoss
import (
    "encoding/json"
    "fmt"
    "syscall"
    "zabbix.com/pkg/plugin"
    "github.com/vishvananda/netlink/nl"
)
// Plugin -
type Plugin struct {
    plugin.Base
}
var impl Plugin
func (p *Plugin) Export(key string, params []string, ctx plugin.ContextProvider) (result interface{}, err error) {
    switch key {
    case "tcp.count":
        return tcpmMain()
    default:
        return nil, plugin.UnsupportedMetricError
    }
}
func init() {
    plugin.RegisterMetrics(&impl, "Eeotcp",
        "tcp.count", "Count tcp state.",
    )
}
func tcp_state_count() (tcpStateCount map[string]int, err error) {
    tcpStateCount = make(map[string]int, 0)
    // Create a new netlink request
    socket_fd := nl.NewNetlinkRequest(nl.SOCK_DIAG_BY_FAMILY, syscall.NLM_F_DUMP)
    {
        // returns a new NetlinkMessage InetDiagReqV2
        // https://github.com/torvalds/linux/blob/v4.0/include/uapi/linux/inet_diag.h#L37
        msg := NewInetDiagReqV2(
            syscall.AF_INET,
            syscall.IPPROTO_TCP,
            AllTCPStates)
        msg.Ext |= (1 << (INET_DIAG_INFO - 1))
        socket_fd.AddData(msg)
    }
    // return [][]byte
    res, err := socket_fd.Execute(syscall.NETLINK_INET_DIAG, 0)
    if err != nil {
        return nil, err
    }
    for _, data := range res {
        state := TcpStateNames[ParseInetDiagMsg(data).State]
        if _, ok := tcpStateCount[state]; ok {
            tcpStateCount[state] += 1
        } else {
            tcpStateCount[state] = 1
        }
    }
    return tcpStateCount, nil
}
func tcpmMain() (interface{}, error) {
    ret, err := tcp_state_count()
    if err != nil {
        fmt.Println(err)
    }
    jsonArray, err := json.Marshal(ret)
    if nil != err {
        return nil, fmt.Errorf("Cannot create JSON array: %s", err)
    }
    return string(jsonArray), nil
}
```

```go
package eeoss
import (
    "fmt"
    "syscall"
    "unsafe"
)
// https://pkg.go.dev/github.com/elastic/gosigar/sys/linux
const (
    AllTCPStates = ^uint32(0)
)
// https://github.com/torvalds/linux/blob/5924bbecd0267d87c24110cbe2041b5075173a25/include/net/tcp_states.h#L16
const (
    TCP_ESTABLISHED = iota + 1
    TCP_SYN_SENT
    TCP_SYN_RECV
    TCP_FIN_WAIT1
    TCP_FIN_WAIT2
    TCP_TIME_WAIT
    TCP_CLOSE
    TCP_CLOSE_WAIT
    TCP_LAST_ACK
    TCP_LISTEN
    TCP_CLOSING /* Now a valid state */
)
var TcpStateNames = map[uint8]string{
    TCP_ESTABLISHED: "ESTAB",
    TCP_SYN_SENT:    "SYN-SENT",
    TCP_SYN_RECV:    "SYN-RECV",
    TCP_FIN_WAIT1:   "FIN-WAIT-1",
    TCP_FIN_WAIT2:   "FIN-WAIT-2",
    TCP_TIME_WAIT:   "TIME-WAIT",
    TCP_CLOSE:       "UNCONN",
    TCP_CLOSE_WAIT:  "CLOSE-WAIT",
    TCP_LAST_ACK:    "LAST-ACK",
    TCP_LISTEN:      "LISTEN",
    TCP_CLOSING:     "CLOSING",
}
// Extensions that can be used in the InetDiagReqV2 request to ask for
// additional data.
// https://github.com/torvalds/linux/blob/v4.0/include/uapi/linux/inet_diag.h#L103
const (
    INET_DIAG_NONE    = 0
    INET_DIAG_MEMINFO = 1 << iota
    INET_DIAG_INFO
    INET_DIAG_VEGASINFO
    INET_DIAG_CONG
    INET_DIAG_TOS
    INET_DIAG_TCLASS
    INET_DIAG_SKMEMINFO
    INET_DIAG_SHUTDOWN
    INET_DIAG_DCTCPINFO
    INET_DIAG_PROTOCOL /* response attribute only */
    INET_DIAG_SKV6ONLY
    INET_DIAG_LOCALS
    INET_DIAG_PEERS
    INET_DIAG_PAD
    INET_DIAG_MARK
)
// V2 Request
var SizeofInetDiagReqV2 = int(unsafe.Sizeof(InetDiagReqV2{}))
// InetDiagReqV2 (inet_diag_req_v2) is used to request diagnostic data.
// https://github.com/torvalds/linux/blob/v4.0/include/uapi/linux/inet_diag.h#L37
type InetDiagReqV2 struct {
    Family   uint8
    Protocol uint8
    Ext      uint8
    Pad      uint8
    States   uint32
    ID       InetDiagSockID
}
// InetDiagSockID (inet_diag_sockid) contains the socket identity.
// https://github.com/torvalds/linux/blob/v4.0/include/uapi/linux/inet_diag.h#L13
type InetDiagSockID struct {
    SPort  [2]byte    // Source port (big-endian).
    DPort  [2]byte    // Destination port (big-endian).
    Src    [4][4]byte // Source IP
    Dst    [4][4]byte // Destination IP
    If     uint32
    Cookie [2]uint32
}
// InetDiagMsg (inet_diag_msg) is the base info structure. It contains socket
// identity (addrs/ports/cookie) and the information shown by netstat.
// https://github.com/torvalds/linux/blob/v4.0/include/uapi/linux/inet_diag.h#L86
type InetDiagMsg struct {
    Family  uint8 // Address family.
    State   uint8 // TCP State
    Timer   uint8
    Retrans uint8
    ID InetDiagSockID
    Expires uint32
    RQueue  uint32 // Recv-Q
    WQueue  uint32 // Send-Q
    UID     uint32 // UID
    Inode   uint32 // Inode of socket.
}
var FamilyNames = map[uint8]string{
    syscall.AF_INET:  "tcp",
    syscall.AF_INET6: "tcp6",
}
func (req *InetDiagReqV2) Serialize() []byte {
    return (*(*[56]byte)(unsafe.Pointer(req)))[:]
}
func (req *InetDiagReqV2) Len() int {
    return SizeofInetDiagReqV2
}
func NewInetDiagReqV2(family, protocol uint8, states uint32) *InetDiagReqV2 {
    return &InetDiagReqV2{
        Family:   family,
        Protocol: protocol,
        States:   states,
    }
}
func (msg *InetDiagMsg) String() string {
    return fmt.Sprintf("%s", TcpStateNames[msg.State])
}
func ParseInetDiagMsg(data []byte) *InetDiagMsg {
    return (*InetDiagMsg)(unsafe.Pointer(&data[0]))
}
```

#### 测试结果
```bash
# time ./zabbix_agent2 -t net.tcp.socket.count[,,,,established]
net.tcp.socket.count[,,,,established]         [s|3783]
real    0m2.814s
user    0m2.055s
sys     0m0.413s
```

```bash
# zabbix_agent2 -t tcp.count
tcp.count                                     [s|{"CLOSE-WAIT":530,"ESTAB":3797,"FIN-WAIT-2":527,"LISTEN":4,"SYN-SENT":2,"TIME-WAIT":176}]
```
