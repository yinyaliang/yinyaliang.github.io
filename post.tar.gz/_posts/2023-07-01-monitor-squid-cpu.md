---
title: "squid snmp方式和squitclient方式获取数值差异的原因"
tags:
  - Monitor
toc: true
---
 
snmp方式和squitclient方式获取数值差异的原因


#### 起因

    观察发现snmp方式获取cpu平稳,无明显波动,squidclient方式获取数据波动大

#### 官方回复
```
SNMP cacheCpuUsage is the average CPU usage of the process handling the SNMP query. The averaging is done over the entire process lifetime[1]. This measurement is not SMP-aware.

mgr:info "CPU Usage, 5 minute avg" is the average CPU usage of all Squid kid processes combined. Very roughly speaking, the averaging is done over the last five minutes[2]. This measurement is SMP-aware.

In both cases, "average usage over time T" means "CPU usage time divided by T".

In the current code, the two reported numbers will virtually always be different.

----

Code references for developers:

[1]: SNMP: Grep for PERF_SYS_CPUUSAGE which boils down to
Math::doublePercent(rusage_cputime(&rusage),
    tvSubDsec(squid_start, current_time)),

[2]: mgr:info: Grep for statCPUUsage.5 which boils down to
Math::doublePercent(CountHist[0].cputime - CountHist[minutes].cputime,
    tvSubDsec(CountHist[minutes].timestamp, CountHist[0].timestamp));
```

#### 结论

    1、SNMP cacheCpuUsage测量整个进程的平均CPU使用率，计算结果不考虑SMP
    2、mgr:info "CPU Usage, 5 minute avg"测量Squid进程以及子进程合并后的平均CPU使用率，计算内容考虑了SMP
