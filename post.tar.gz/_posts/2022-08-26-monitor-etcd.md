---
title: "etcd集群监控"
tags:
  - Monitor
toc: true
---
 
etcd集群监控

### 系统
Centos 7

### 测试接口

```bash
curl --cert /opt/etcd/ssl/server.pem --key /opt/etcd/ssl/server-key.pem https://10.0.2.45:2379/metrics --insecure
```

### prometheus 配置

添加 etcd主机组 prometheus.yml
```yaml
  - job_name: "etcd cluster"
    scheme: https
    static_configs:
      - targets: ["10.0.2.44:2379","10.0.2.45:2379","10.0.2.46:2379"]
    tls_config:
      insecure_skip_verify: true
      cert_file: "/data/config/oss/prometheus/etcd_ca/server.pem"
      key_file: "/data/config/oss/prometheus/etcd_ca/server-key.pem"
```



